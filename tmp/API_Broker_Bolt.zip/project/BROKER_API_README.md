# 🌐 Multi-Broker Trading API

## 🎯 Visión General

API unificada para operar en **múltiples brokers simultáneamente** con una sola interfaz. Soporta **Forex, Acciones, ETFs, Crypto, Opciones, Futuros y CFDs**.

### ✨ Características Principales

- 🏦 **Multi-Broker**: Conecta con Alpaca, OANDA, Interactive Brokers y más
- 🔄 **Órdenes Simultáneas**: Ejecuta la misma orden en múltiples brokers
- 🔐 **Seguridad**: Cifrado AES-128 para credenciales, RLS en base de datos
- 📊 **Market Data**: Cotizaciones en tiempo real y datos históricos
- 💼 **Portfolio Management**: Balance, posiciones, PnL, exposure
- 🎯 **Risk Management**: Stop loss, take profit, trailing stops
- 📝 **Auditoría**: Logs completos para compliance
- 🌍 **Multi-Asset**: Stocks, Forex, Crypto, Options, Futures, CFDs

---

## 📚 Documentación

- **[Quick Start Guide](./TRADING_QUICKSTART.md)** - Comienza en 5 minutos
- **[API Documentation](./TRADING_API_DOCS.md)** - Documentación completa
- **[Interactive Docs](http://localhost:8000/docs)** - Swagger UI (después de iniciar)

---

## 🚀 Instalación Rápida

```bash
# 1. Instalar dependencias
pip install -r requirements.txt

# 2. Configurar environment
cp .env.example .env

# 3. Generar clave de cifrado
python generate_encryption_key.py

# 4. Iniciar servidor
python run.py
```

**Listo!** API disponible en: http://localhost:8000

---

## 🏦 Brokers Soportados

### ✅ Actualmente Implementados (7 Brokers)

| Broker                  | Stocks | Forex | Crypto | Options | Futures | CFDs |
|-------------------------|--------|-------|--------|---------|---------|------|
| **Alpaca**              | ✅     | ❌    | ✅     | ❌      | ❌      | ❌   |
| **OANDA**               | ❌     | ✅    | ❌     | ❌      | ❌      | ✅   |
| **Interactive Brokers** | ✅     | ✅    | ❌     | ✅      | ✅      | ❌   |
| **IG Markets**          | ✅     | ✅    | ❌     | ✅      | ✅      | ✅   |
| **FOREX.com**           | ❌     | ✅    | ✅     | ❌      | ❌      | ✅   |
| **FXCM**                | ❌     | ✅    | ❌     | ❌      | ❌      | ✅   |
| **Pepperstone**         | ✅     | ✅    | ✅     | ❌      | ❌      | ✅   |

### 🔜 Próximamente

- Saxo Bank
- Dukascopy
- AvaTrade
- Plus500
- XTB

---

## 🎯 Casos de Uso

### 1. Diversificación de Brokers

Ejecuta la misma estrategia en múltiples brokers para:
- Reducir riesgo de contraparte
- Aprovechar diferentes spreads
- Backup en caso de downtime de un broker

```python
# Orden simultánea en 3 brokers
POST /api/trading/orders/multi
{
  "connection_ids": ["alpaca-uuid", "oanda-uuid", "ib-uuid"],
  "symbol": "EUR/USD",
  "side": "buy",
  "quantity": 10000
}
```

### 2. Arbitraje Multi-Broker

Monitorea precios en diferentes brokers:

```python
# Obtener cotizaciones de múltiples brokers
GET /api/trading/quotes/EUR_USD?connection_id=alpaca-uuid
GET /api/trading/quotes/EUR_USD?connection_id=oanda-uuid
```

### 3. Gestión Centralizada de Portfolio

Un solo dashboard para ver todas tus cuentas:

```python
# Ver balance consolidado
GET /api/trading/account?connection_id=broker1-uuid
GET /api/trading/account?connection_id=broker2-uuid
```

---

## 🔐 Seguridad

### Cifrado de Credenciales

- **AES-128 (Fernet)** para credenciales en base de datos
- Las credenciales **nunca** se exponen en logs
- Clave de cifrado separada en variables de entorno

### Row Level Security (RLS)

Todas las tablas tienen políticas de seguridad:
- Solo puedes ver tus propias conexiones
- Solo puedes ver tus propias órdenes
- Solo puedes ver tus propias posiciones

### Audit Logs

Toda operación de trading se registra:
- Órdenes colocadas, modificadas, canceladas
- Cambios de configuración
- Accesos a datos sensibles

---

## 📊 Arquitectura

### Patrón Adapter

```
┌─────────────────┐
│   FastAPI App   │
└────────┬────────┘
         │
    ┌────┴────┐
    │ Trading │
    │ Service │
    └────┬────┘
         │
    ┌────┴────────────────────┐
    │   Broker Factory        │
    └────┬────────────────────┘
         │
    ┌────┴──────┬──────┬──────┐
    │           │      │      │
┌───▼───┐  ┌───▼───┐ ┌▼──────┐
│Alpaca │  │OANDA  │ │  IB   │
│Adapter│  │Adapter│ │Adapter│
└───┬───┘  └───┬───┘ └┬──────┘
    │          │      │
┌───▼───┐  ┌───▼───┐ ┌▼──────┐
│Alpaca │  │OANDA  │ │  IB   │
│  API  │  │  API  │ │  API  │
└───────┘  └───────┘ └───────┘
```

### Base de Datos (Supabase/PostgreSQL)

- `brokers` - Catálogo de brokers soportados
- `user_broker_connections` - Conexiones de usuarios
- `orders` - Órdenes unificadas
- `positions` - Posiciones abiertas
- `account_snapshots` - Snapshots de cuentas
- `trades` - Ejecuciones
- `audit_logs` - Logs de auditoría

---

## 🛠 Tecnologías

- **FastAPI** - Framework web async
- **Supabase** - Base de datos PostgreSQL con RLS
- **Cryptography** - Cifrado de credenciales
- **httpx** - Cliente HTTP async
- **Pydantic** - Validación de datos
- **Python 3.10+**

---

## 📖 Ejemplos de Código

### Python Client

```python
import requests

BASE_URL = "http://localhost:8000/api"

# Conectar con Alpaca
connection = requests.post(f"{BASE_URL}/brokers/connections", json={
    "broker_id": "alpaca-broker-uuid",
    "connection_name": "My Alpaca",
    "environment": "demo",
    "credentials": {
        "api_key": "your-key",
        "api_secret": "your-secret"
    }
}).json()

# Colocar orden
order = requests.post(f"{BASE_URL}/trading/orders", json={
    "connection_id": connection['id'],
    "symbol": "AAPL",
    "asset_type": "stock",
    "side": "buy",
    "order_type": "limit",
    "quantity": 100,
    "limit_price": 150.00
}).json()

print(f"Order ID: {order['id']}")
```

### JavaScript/TypeScript Client

```javascript
const BASE_URL = 'http://localhost:8000/api';

// Conectar con OANDA
const response = await fetch(`${BASE_URL}/brokers/connections`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    broker_id: 'oanda-broker-uuid',
    connection_name: 'OANDA Forex',
    environment: 'demo',
    credentials: {
      api_key: 'your-token',
      account_id: 'your-account'
    }
  })
});

const connection = await response.json();

// Colocar orden en forex
const orderResponse = await fetch(`${BASE_URL}/trading/orders`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    connection_id: connection.id,
    symbol: 'EUR/USD',
    asset_type: 'forex',
    side: 'buy',
    order_type: 'market',
    quantity: 10000,
    stop_loss_price: 1.0850,
    take_profit_price: 1.0950
  })
});

const order = await orderResponse.json();
console.log('Order placed:', order.id);
```

---

## 🔧 Configuración Avanzada

### Variables de Entorno

```env
# Trading Configuration
ENCRYPTION_KEY=your-generated-key
JWT_SECRET_KEY=your-jwt-secret
RATE_LIMIT_PER_MINUTE=100

# Supabase
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
```

### Generar Clave de Cifrado

```bash
python generate_encryption_key.py
```

O manualmente:
```python
from cryptography.fernet import Fernet
print(Fernet.generate_key().decode())
```

---

## 📈 Roadmap

### v2.1 (Próximo)
- [ ] WebSocket streaming para precios en tiempo real
- [ ] Sistema 2FA/MFA completo
- [ ] Dashboard de analytics (PnL, exposure, métricas)

### v2.2
- [ ] Backtesting engine
- [ ] Alertas y notificaciones
- [ ] Copy trading

### v3.0
- [ ] Agregar 7 brokers adicionales
- [ ] Machine Learning para análisis de mercado
- [ ] Mobile app

---

## 🐛 Troubleshooting

### La API no inicia

```bash
# Verificar dependencias
pip install -r requirements.txt

# Verificar Supabase
curl $SUPABASE_URL/rest/v1/
```

### Error de cifrado

```bash
# Regenerar clave
python generate_encryption_key.py
```

### Broker no conecta

1. Verifica credenciales
2. Verifica ambiente (demo/live)
3. Para IB, inicia IB Gateway primero

---

## 📞 Soporte

- **Docs**: [TRADING_API_DOCS.md](./TRADING_API_DOCS.md)
- **Quick Start**: [TRADING_QUICKSTART.md](./TRADING_QUICKSTART.md)
- **Issues**: GitHub Issues
- **API Docs**: http://localhost:8000/docs

---

## 📄 Licencia

[Tu licencia aquí]

---

## 🙏 Contribuciones

Las contribuciones son bienvenidas! Por favor:

1. Fork el proyecto
2. Crea una rama para tu feature
3. Commit tus cambios
4. Push a la rama
5. Abre un Pull Request

---

## ⭐ Star el Proyecto

Si este proyecto te fue útil, dale una ⭐ en GitHub!

---

**Happy Trading! 📈💰**
