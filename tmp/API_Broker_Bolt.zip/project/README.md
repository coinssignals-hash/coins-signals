# Trading News API - Backend para Traders de Forex

API backend completa desarrollada con FastAPI para proporcionar noticias económicas analizadas con IA, específicamente diseñada para traders de forex y divisas.

## Características Principales

### 🤖 Análisis con Inteligencia Artificial
- Resúmenes detallados generados por OpenAI GPT-4
- Puntos clave extraídos automáticamente
- Conclusiones específicas para traders con sesgo de mercado
- Análisis de sentimiento por divisa (bullish/bearish/neutral)

### 📊 Datos Históricos para Gráficos
- 12 meses de datos históricos por divisa
- Valores de impacto calculados
- Descripciones de eventos relevantes
- Listos para visualización en charts

### 🔄 Procesamiento Automático
- Scraping automático cada 30 minutos
- Análisis con IA en segundo plano
- Generación automática de datos históricos
- Scheduler integrado con APScheduler

### 🌍 Fuentes Confiables
- 15+ fuentes de noticias económicas pre-configuradas
- Reuters, Bloomberg, Financial Times, CNBC, WSJ
- Forex Factory, FXStreet, DailyFX
- Trading Economics y más

### 💱 8 Divisas Principales
- EUR (Euro)
- USD (Dólar Estadounidense)
- GBP (Libra Esterlina)
- JPY (Yen Japonés)
- AUD (Dólar Australiano)
- CAD (Dólar Canadiense)
- CHF (Franco Suizo)
- NZD (Dólar Neozelandés)

## Arquitectura del Proyecto

```
project/
├── app/
│   ├── __init__.py
│   ├── main.py                      # Aplicación FastAPI principal
│   ├── api/
│   │   ├── __init__.py
│   │   ├── news_endpoints.py        # GET /api/v1/news/*
│   │   └── admin_endpoints.py       # POST /api/v1/admin/*
│   ├── core/
│   │   ├── __init__.py
│   │   └── config.py                # Configuración y settings
│   ├── db/
│   │   ├── __init__.py
│   │   └── supabase_client.py       # Cliente de base de datos
│   ├── schemas/
│   │   ├── __init__.py
│   │   └── news_schemas.py          # Modelos Pydantic
│   └── services/
│       ├── __init__.py
│       ├── scraper_service.py       # Web scraping
│       ├── ai_analysis_service.py   # Análisis con OpenAI
│       ├── historical_service.py    # Datos históricos
│       └── utils.py                 # Funciones auxiliares
├── scripts/
│   ├── __init__.py
│   └── init_sources.py              # Inicializar fuentes
├── requirements.txt                 # Dependencias Python
├── run.py                          # Script de ejecución
├── Dockerfile                      # Para Docker
├── docker-compose.yml              # Desarrollo con Docker
├── .env.example                    # Plantilla de variables
├── .gitignore                      # Archivos ignorados
├── README.md                       # Este archivo
├── QUICKSTART.md                   # Guía de inicio rápido
└── EXAMPLES.md                     # Ejemplos de JSON
```

## Instalación

### Requisitos Previos

- Python 3.9 o superior
- Cuenta en Supabase (gratuita)
- API Key de OpenAI
- pip y venv

### Paso 1: Clonar/Descargar el Proyecto

```bash
cd trading-news-api
```

### Paso 2: Crear Entorno Virtual

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Mac/Linux
python3 -m venv venv
source venv/bin/activate
```

### Paso 3: Instalar Dependencias

```bash
pip install -r requirements.txt
```

### Paso 4: Configurar Variables de Entorno

```bash
cp .env.example .env
```

Edita el archivo `.env` con tus credenciales:

```env
SUPABASE_URL=https://tu-proyecto.supabase.co
SUPABASE_KEY=tu-anon-key
SUPABASE_SERVICE_ROLE_KEY=tu-service-role-key
OPENAI_API_KEY=sk-proj-tu-api-key
```

### Paso 5: Aplicar Migraciones de Base de Datos

Las migraciones se aplican automáticamente al crear el proyecto Supabase. Verifica que las siguientes tablas existan:

- `news_sources`
- `news_articles`
- `news_analysis`
- `currency_impact`
- `historical_analysis`

### Paso 6: Inicializar Fuentes de Noticias

```bash
python scripts/init_sources.py
```

### Paso 7: Ejecutar el Servidor

```bash
python run.py
```

O directamente con uvicorn:

```bash
uvicorn app.main:app --reload
```

## Endpoints de la API

### 📰 Endpoints Públicos (Para App Móvil)

#### GET `/api/v1/news/list`

Listado paginado de noticias con filtros.

**Parámetros:**
- `page`: Número de página (default: 1)
- `page_size`: Artículos por página (default: 20, max: 100)
- `currency`: Filtrar por divisa (opcional)
- `category`: Filtrar por categoría (opcional)

**Respuesta:**
```json
{
  "news": [...],
  "total": 127,
  "page": 1,
  "page_size": 20
}
```

#### GET `/api/v1/news/{article_id}`

Detalle completo de una noticia con análisis IA.

**Respuesta:**
```json
{
  "id": "uuid",
  "title": "...",
  "ai_summary": "...",
  "key_points": [...],
  "trader_conclusion": "...",
  "currency_impacts": [...],
  "historical_data": [...]
}
```

#### GET `/api/v1/news/currencies`

Lista de divisas soportadas.

**Respuesta:**
```json
["EUR", "USD", "AUD", "CAD", "GBP", "JPY", "CHF", "NZD"]
```

#### GET `/api/v1/news/categories`

Categorías económicas disponibles.

**Respuesta:**
```json
["Interest Rates", "Employment", "GDP", ...]
```

### 🔧 Endpoints Administrativos

#### POST `/api/v1/admin/sources`

Añadir nueva fuente de noticias.

**Body:**
```json
{
  "name": "Reuters Business",
  "url": "https://www.reuters.com/business/",
  "scrape_frequency_minutes": 30
}
```

#### GET `/api/v1/admin/sources`

Listar todas las fuentes configuradas.

#### POST `/api/v1/admin/scrape`

Ejecutar scraping manual en segundo plano.

#### POST `/api/v1/admin/analyze`

Ejecutar análisis con IA manual.

#### POST `/api/v1/admin/historical`

Generar datos históricos manualmente.

#### GET `/api/v1/admin/stats`

Estadísticas del sistema.

**Respuesta:**
```json
{
  "status": "success",
  "data": {
    "total_sources": 15,
    "total_articles": 453,
    "relevant_articles": 287,
    "analyzed_articles": 265,
    "pending_analysis": 22
  }
}
```

### 🏥 Health Check

#### GET `/health`

Verificar estado del servidor.

**Respuesta:**
```json
{
  "status": "healthy",
  "scheduler": true
}
```

## Esquema de Base de Datos (Supabase PostgreSQL)

### Tabla: `news_sources`
```sql
- id (uuid, PK)
- name (text)
- url (text, unique)
- is_active (boolean)
- scrape_frequency_minutes (int)
- last_scraped_at (timestamptz)
- created_at (timestamptz)
```

### Tabla: `news_articles`
```sql
- id (uuid, PK)
- source_id (uuid, FK → news_sources)
- analysis_id (uuid, FK → news_analysis, nullable)
- title (text)
- content (text)
- url (text)
- image_url (text, nullable)
- published_at (timestamptz)
- is_relevant (boolean)
- economic_category (text)
- affected_currencies (text[])
- created_at (timestamptz)
```

### Tabla: `news_analysis`
```sql
- id (uuid, PK)
- article_id (uuid, FK → news_articles)
- ai_summary (text)
- key_points (text[])
- trader_conclusion (text)
- created_at (timestamptz)
```

### Tabla: `currency_impact`
```sql
- id (uuid, PK)
- article_id (uuid, FK → news_articles)
- currency_code (text)
- positive_percent (float)
- negative_percent (float)
- neutral_percent (float)
- overall_sentiment (text)
- created_at (timestamptz)
```

### Tabla: `historical_analysis`
```sql
- id (uuid, PK)
- article_id (uuid, FK → news_articles)
- currency_code (text)
- date (text)
- impact_value (float)
- event_description (text)
- created_at (timestamptz)
```

## Procesamiento Automático

El sistema ejecuta automáticamente cada 30 minutos:

1. **Scraping**: Extrae noticias de todas las fuentes activas
2. **Filtrado**: Identifica noticias relevantes para forex
3. **Análisis IA**: Genera resúmenes y conclusiones con GPT-4
4. **Datos Históricos**: Crea 12 meses de datos para gráficos
5. **Almacenamiento**: Guarda todo en Supabase PostgreSQL

## Flujo de Datos

```
┌─────────────┐
│  Fuentes    │
│  de Web     │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│  Scraping   │
│  Service    │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│  Filtrado   │
│  Relevancia │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│  Análisis   │
│  OpenAI     │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│  Datos      │
│  Históricos │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│  Supabase   │
│  PostgreSQL │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│  REST API   │
│  FastAPI    │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│  App Móvil  │
│  (Cliente)  │
└─────────────┘
```

## Tecnologías Utilizadas

### Backend
- **FastAPI** - Framework web moderno y rápido
- **Uvicorn** - Servidor ASGI de alto rendimiento
- **Pydantic** - Validación de datos con tipos

### Base de Datos
- **Supabase** - PostgreSQL como servicio
- **PostgREST** - API REST automática

### Inteligencia Artificial
- **OpenAI GPT-4** - Análisis y generación de texto

### Web Scraping
- **BeautifulSoup4** - Parseo de HTML
- **lxml** - Parser XML/HTML rápido
- **Requests** - Cliente HTTP

### Tareas Programadas
- **APScheduler** - Scheduler de tareas en background

### Utilidades
- **python-dateutil** - Manipulación de fechas
- **pytz** - Zonas horarias
- **loguru** - Logging mejorado

## Configuración Avanzada

### Cambiar Intervalo de Scraping

En `.env`:
```env
SCRAPING_INTERVAL_MINUTES=15
```

### Cambiar Modelo de OpenAI

En `.env`:
```env
OPENAI_MODEL=gpt-4-turbo-preview
```

### Cambiar Puerto del Servidor

En `.env`:
```env
API_PORT=8080
```

### Ajustar Nivel de Logging

En `.env`:
```env
LOG_LEVEL=DEBUG
```

Opciones: `DEBUG`, `INFO`, `WARNING`, `ERROR`, `CRITICAL`

## Despliegue en Producción

### Opción 1: Railway

```bash
# Instalar Railway CLI
npm install -g @railway/cli

# Login
railway login

# Inicializar proyecto
railway init

# Deploy
railway up
```

### Opción 2: Docker

```bash
# Build
docker build -t trading-news-api .

# Run
docker run -p 8000:8000 --env-file .env trading-news-api
```

### Opción 3: Docker Compose

```bash
docker-compose up -d
```

### Opción 4: Google Cloud Run

```bash
# Build
gcloud builds submit --tag gcr.io/PROJECT_ID/trading-news-api

# Deploy
gcloud run deploy trading-news-api \
  --image gcr.io/PROJECT_ID/trading-news-api \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated
```

## Solución de Problemas

### Error: "Supabase connection failed"

**Causa**: Credenciales incorrectas o proyecto inactivo

**Solución**:
1. Verifica que copiaste correctamente las credenciales en `.env`
2. Asegúrate que el proyecto Supabase está activo
3. Comprueba que tienes los 3 valores: URL, ANON_KEY y SERVICE_ROLE_KEY

### Error: "OpenAI API error"

**Causa**: API key inválida o sin créditos

**Solución**:
1. Verifica tu API key en https://platform.openai.com/api-keys
2. Comprueba que tienes créditos disponibles
3. Asegúrate que la key empieza con `sk-`

### Error: "No news generated"

**Causa**: Las fuentes web bloquearon el scraping

**Solución**:
1. Es normal en algunos sitios web
2. Espera al siguiente ciclo automático (30 min)
3. Prueba añadir fuentes alternativas

### Error: "Module not found"

**Causa**: Dependencias no instaladas

**Solución**:
```bash
pip install -r requirements.txt
```

### Logs sin Errores pero sin Noticias

**Posibles causas**:
1. Scraping exitoso pero sin noticias relevantes
2. Filtrado muy estricto

**Solución**:
1. Revisa logs con `LOG_LEVEL=DEBUG`
2. Ejecuta manualmente: `POST /api/v1/admin/scrape`
3. Verifica estadísticas: `GET /api/v1/admin/stats`

## Mejores Prácticas

### Seguridad

1. **NUNCA** commitear el archivo `.env` al repositorio
2. Usar variables de entorno en producción
3. Rotar las API keys regularmente
4. Limitar acceso a endpoints `/admin/*`

### Rendimiento

1. Usar paginación en listados grandes
2. Cachear respuestas frecuentes
3. Limitar el `page_size` a 100
4. Monitorear uso de créditos OpenAI

### Mantenimiento

1. Revisar logs regularmente
2. Monitorear estadísticas con `/admin/stats`
3. Actualizar fuentes de noticias periódicamente
4. Backup de base de datos Supabase

## Costos Aproximados

### Supabase (Tier Gratuito)
- ✅ 500 MB de base de datos
- ✅ 5 GB de ancho de banda
- ✅ 2 GB de almacenamiento
- ✅ Suficiente para desarrollo y producción pequeña

### OpenAI (Pago por uso)
- GPT-4 Turbo: ~$0.01 por análisis
- ~300 análisis con $5
- ~$50/mes para 5000 artículos/mes

### Hosting (Opciones gratuitas)
- Railway: 500 horas/mes gratis
- Render: Plan gratuito disponible
- Google Cloud Run: $0 primeros 2M requests/mes

## Contribuir

Para reportar bugs o sugerir mejoras:

1. Abre un issue describiendo el problema
2. Incluye logs relevantes
3. Especifica versión de Python y sistema operativo

## Licencia

Este proyecto es privado y de uso personal.

## Contacto y Soporte

Para soporte adicional:
- Revisa la documentación en `/docs`
- Consulta `QUICKSTART.md` para inicio rápido
- Ve `EXAMPLES.md` para ejemplos de respuestas JSON

---

**Desarrollado con FastAPI, OpenAI y Supabase**

**Versión**: 1.0.0
**Última actualización**: Diciembre 2025
