# Multi-Broker Trading API Documentation

## 🚀 Overview

Esta API proporciona una interfaz unificada para operar en múltiples brokers simultáneamente. Soporta **Alpaca**, **OANDA**, **Interactive Brokers** y más, con capacidades de trading en:

- 📈 **Stocks & ETFs** (Alpaca, Interactive Brokers)
- 💱 **Forex** (OANDA, Interactive Brokers)
- ₿ **Crypto** (Alpaca)
- 📊 **Options** (Interactive Brokers)
- 📉 **Futures** (Interactive Brokers)
- 🔄 **CFDs** (OANDA)

---

## 📋 Table of Contents

1. [Instalación](#instalación)
2. [Configuración](#configuración)
3. [Endpoints](#endpoints)
   - [Brokers](#brokers)
   - [Trading](#trading)
4. [Ejemplos de Uso](#ejemplos-de-uso)
5. [Estructura de Credenciales](#estructura-de-credenciales)
6. [Seguridad](#seguridad)

---

## 🛠 Instalación

```bash
# Clonar repositorio
git clone <your-repo-url>
cd <project-directory>

# Instalar dependencias
pip install -r requirements.txt

# Configurar variables de entorno
cp .env.example .env
# Editar .env con tus credenciales
```

### Configurar Base de Datos

La API usa **Supabase** como base de datos. La migración ya está incluida en:
- `supabase_migration.sql` o
- Migración aplicada automáticamente vía MCP

---

## ⚙️ Configuración

### Variables de Entorno Requeridas

```env
# Supabase
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key

# Cifrado (generar con: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())")
ENCRYPTION_KEY=your-encryption-key-here

# JWT (opcional, para autenticación personalizada)
JWT_SECRET_KEY=your-jwt-secret
```

### Iniciar el Servidor

```bash
python run.py
```

La API estará disponible en: `http://localhost:8000`

Documentación interactiva: `http://localhost:8000/docs`

---

## 📡 Endpoints

### Base URL
```
http://localhost:8000/api
```

---

## 🏦 Brokers

### 1. Listar Brokers Soportados

```http
GET /api/brokers
```

**Response:**
```json
[
  {
    "id": "uuid",
    "code": "alpaca",
    "display_name": "Alpaca",
    "description": "Commission-free trading...",
    "auth_type": "api_key",
    "supported_assets": ["stocks", "etfs", "crypto"],
    "supported_order_types": ["market", "limit", "stop", "stop_limit", "trailing_stop"],
    "supports_websocket": true,
    "is_active": true
  }
]
```

---

### 2. Crear Conexión a Broker

```http
POST /api/brokers/connections
```

**Request Body:**
```json
{
  "broker_id": "uuid-del-broker",
  "connection_name": "My Alpaca Account",
  "environment": "demo",
  "credentials": {
    "api_key": "your-api-key",
    "api_secret": "your-api-secret"
  },
  "config": {}
}
```

**Response:**
```json
{
  "id": "uuid",
  "user_id": "uuid",
  "broker_id": "uuid",
  "connection_name": "My Alpaca Account",
  "environment": "demo",
  "is_active": true,
  "is_connected": true,
  "last_connected_at": "2024-01-01T00:00:00Z",
  "created_at": "2024-01-01T00:00:00Z"
}
```

---

### 3. Listar Mis Conexiones

```http
GET /api/brokers/connections
```

---

### 4. Probar Conexión

```http
POST /api/brokers/connections/{connection_id}/test
```

**Response:**
```json
{
  "success": true,
  "message": "Connection successful",
  "account_id": "your-account-id"
}
```

---

## 📊 Trading

### 1. Colocar Orden

```http
POST /api/trading/orders
```

**Request Body:**
```json
{
  "connection_id": "uuid",
  "symbol": "AAPL",
  "asset_type": "stock",
  "side": "buy",
  "order_type": "limit",
  "quantity": 10,
  "limit_price": 150.00,
  "time_in_force": "gtc",
  "stop_loss_price": 145.00,
  "take_profit_price": 160.00
}
```

**Response:**
```json
{
  "id": "uuid",
  "broker_order_id": "broker-specific-id",
  "client_order_id": "uuid",
  "symbol": "AAPL",
  "side": "buy",
  "order_type": "limit",
  "quantity": 10,
  "filled_quantity": 0,
  "limit_price": 150.00,
  "status": "submitted",
  "submitted_at": "2024-01-01T00:00:00Z"
}
```

---

### 2. Colocar Orden en Múltiples Brokers

```http
POST /api/trading/orders/multi
```

**Request Body:**
```json
{
  "connection_ids": ["uuid1", "uuid2", "uuid3"],
  "symbol": "EUR/USD",
  "asset_type": "forex",
  "side": "buy",
  "order_type": "market",
  "quantity": 10000,
  "time_in_force": "ioc"
}
```

**Response:**
```json
{
  "total_submitted": 3,
  "successful": [
    { "id": "uuid1", "status": "filled", ... },
    { "id": "uuid2", "status": "filled", ... }
  ],
  "failed": [
    {
      "connection_id": "uuid3",
      "error": "Insufficient buying power"
    }
  ]
}
```

---

### 3. Modificar Orden

```http
PUT /api/trading/orders/{order_id}
```

**Request Body:**
```json
{
  "quantity": 15,
  "limit_price": 152.00
}
```

---

### 4. Cancelar Orden

```http
DELETE /api/trading/orders/{order_id}
```

---

### 5. Listar Órdenes

```http
GET /api/trading/orders?connection_id=uuid&status=filled&limit=50
```

---

### 6. Ver Posiciones

```http
GET /api/trading/positions?connection_id=uuid
```

**Response:**
```json
[
  {
    "id": "uuid",
    "symbol": "AAPL",
    "asset_type": "stock",
    "quantity": 100,
    "average_entry_price": 150.00,
    "current_price": 155.00,
    "unrealized_pnl": 500.00,
    "unrealized_pnl_percent": 3.33,
    "market_value": 15500.00
  }
]
```

---

### 7. Ver Balance de Cuenta

```http
GET /api/trading/account?connection_id=uuid
```

**Response:**
```json
{
  "cash_balance": 50000.00,
  "equity": 75000.00,
  "portfolio_value": 75000.00,
  "buying_power": 100000.00,
  "unrealized_pnl": 2500.00,
  "realized_pnl_today": 350.00,
  "total_positions_count": 5,
  "long_exposure": 25000.00,
  "short_exposure": 0.00,
  "net_exposure": 25000.00
}
```

---

### 8. Obtener Cotización en Tiempo Real

```http
GET /api/trading/quotes/AAPL?connection_id=uuid
```

**Response:**
```json
{
  "symbol": "AAPL",
  "asset_type": "stock",
  "bid_price": 154.95,
  "ask_price": 155.05,
  "last_price": 155.00,
  "volume": 5000000,
  "daily_change": 2.50,
  "daily_change_percent": 1.64,
  "quote_time": "2024-01-01T15:30:00Z"
}
```

---

### 9. Obtener Datos Históricos

```http
GET /api/trading/historical/AAPL?connection_id=uuid&timeframe=1Day&start=2024-01-01&end=2024-01-31&limit=100
```

**Response:**
```json
{
  "symbol": "AAPL",
  "timeframe": "1Day",
  "data": [
    {
      "timestamp": "2024-01-01T00:00:00Z",
      "open": 150.00,
      "high": 155.00,
      "low": 149.50,
      "close": 154.00,
      "volume": 10000000
    }
  ]
}
```

---

## 💡 Ejemplos de Uso

### Ejemplo 1: Trading en Forex con OANDA

```python
import requests

BASE_URL = "http://localhost:8000/api"

# 1. Conectar con OANDA
connection = requests.post(f"{BASE_URL}/brokers/connections", json={
    "broker_id": "oanda-broker-uuid",
    "connection_name": "OANDA Demo",
    "environment": "demo",
    "credentials": {
        "api_key": "your-oanda-api-key",
        "account_id": "your-account-id"
    }
}).json()

connection_id = connection['id']

# 2. Colocar orden de compra EUR/USD
order = requests.post(f"{BASE_URL}/trading/orders", json={
    "connection_id": connection_id,
    "symbol": "EUR/USD",
    "asset_type": "forex",
    "side": "buy",
    "order_type": "market",
    "quantity": 10000,
    "stop_loss_price": 1.0850,
    "take_profit_price": 1.0950
}).json()

print(f"Order placed: {order['id']}")

# 3. Ver posiciones
positions = requests.get(
    f"{BASE_URL}/trading/positions",
    params={"connection_id": connection_id}
).json()

print(f"Current positions: {len(positions)}")
```

---

### Ejemplo 2: Trading Multi-Broker

```python
# Colocar la misma orden en 3 brokers simultáneamente
multi_order = requests.post(f"{BASE_URL}/trading/orders/multi", json={
    "connection_ids": [
        "alpaca-connection-uuid",
        "oanda-connection-uuid",
        "ib-connection-uuid"
    ],
    "symbol": "AAPL",
    "asset_type": "stock",
    "side": "buy",
    "order_type": "limit",
    "quantity": 100,
    "limit_price": 150.00,
    "time_in_force": "day"
}).json()

print(f"Successful: {len(multi_order['successful'])}")
print(f"Failed: {len(multi_order['failed'])}")
```

---

## 🔐 Estructura de Credenciales por Broker

### Alpaca
```json
{
  "api_key": "your-api-key",
  "api_secret": "your-api-secret"
}
```

### OANDA
```json
{
  "api_key": "your-api-token",
  "account_id": "your-account-id"
}
```

### Interactive Brokers
```json
{
  "base_url": "https://localhost:5000/v1/api",
  "account_id": "your-account-id"
}
```

**Nota:** IB requiere tener IB Gateway o TWS corriendo localmente.

### IG Markets
```json
{
  "api_key": "your-ig-api-key",
  "username": "your-username",
  "password": "your-password",
  "account_id": "your-account-id"
}
```

### FOREX.com
```json
{
  "api_token": "your-forex-api-token",
  "account_id": "your-account-id"
}
```

### FXCM
```json
{
  "access_token": "your-fxcm-access-token",
  "account_id": "your-account-id"
}
```

### Pepperstone
```json
{
  "api_key": "your-pepperstone-api-key",
  "account_id": "your-account-id"
}
```

---

## 🔒 Seguridad

### Cifrado de Credenciales

Todas las credenciales se cifran usando **Fernet (AES-128)** antes de almacenarse en Supabase.

### Row Level Security (RLS)

Todas las tablas tienen políticas RLS que garantizan:
- Los usuarios solo pueden ver sus propias conexiones
- Los usuarios solo pueden ver sus propias órdenes
- Los usuarios solo pueden ver sus propias posiciones

### Auditoría

Todas las operaciones de trading se registran en `audit_logs` para compliance.

---

## 📚 Order Types Soportados

| Order Type      | Alpaca | OANDA | IB  | IG  | FOREX | FXCM | Pepper | Descripción |
|-----------------|--------|-------|-----|-----|-------|------|--------|-------------|
| Market          | ✅     | ✅    | ✅  | ✅  | ✅    | ✅   | ✅     | Ejecuta al precio de mercado |
| Limit           | ✅     | ✅    | ✅  | ✅  | ✅    | ✅   | ✅     | Ejecuta a precio específico o mejor |
| Stop            | ✅     | ✅    | ✅  | ✅  | ✅    | ✅   | ✅     | Se convierte en market al alcanzar stop price |
| Stop Limit      | ✅     | ❌    | ✅  | ❌  | ✅    | ✅   | ✅     | Se convierte en limit al alcanzar stop price |
| Trailing Stop   | ✅     | ❌    | ✅  | ❌  | ❌    | ❌   | ✅     | Stop que sigue el precio |

---

## 🎯 Asset Types Soportados

| Asset Type | Alpaca | OANDA | IB  | IG Markets | FOREX.com | FXCM | Pepperstone |
|------------|--------|-------|-----|------------|-----------|------|-------------|
| Stocks     | ✅     | ❌    | ✅  | ✅         | ❌        | ❌   | ✅          |
| ETFs       | ✅     | ❌    | ✅  | ❌         | ❌        | ❌   | ❌          |
| Forex      | ❌     | ✅    | ✅  | ✅         | ✅        | ✅   | ✅          |
| Crypto     | ✅     | ❌    | ❌  | ❌         | ✅        | ❌   | ✅          |
| Options    | ❌     | ❌    | ✅  | ✅         | ❌        | ❌   | ❌          |
| Futures    | ❌     | ❌    | ✅  | ✅         | ❌        | ❌   | ❌          |
| CFDs       | ❌     | ✅    | ❌  | ✅         | ✅        | ✅   | ✅          |

---

## 🚧 Próximas Funcionalidades

- [ ] WebSocket para streaming en tiempo real
- [ ] Sistema 2FA/MFA completo
- [ ] Dashboard de analytics (PnL, exposure, métricas)
- [ ] Backtesting engine
- [ ] Más brokers: Saxo Bank, Dukascopy, AvaTrade, Plus500, XTB

---

## 📞 Soporte

Para preguntas o issues:
- Documentación interactiva: `/docs`
- GitHub Issues: [tu-repo]

---

## 📄 Licencia

[Tu licencia aquí]
