import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.db.supabase_client import get_supabase
from loguru import logger

NEWS_SOURCES = [
    {
        "name": "Reuters Business",
        "url": "https://www.reuters.com/business/",
        "scrape_frequency_minutes": 30
    },
    {
        "name": "Bloomberg Economics",
        "url": "https://www.bloomberg.com/economics",
        "scrape_frequency_minutes": 30
    },
    {
        "name": "Financial Times Markets",
        "url": "https://www.ft.com/markets",
        "scrape_frequency_minutes": 30
    },
    {
        "name": "CNBC Economy",
        "url": "https://www.cnbc.com/economy/",
        "scrape_frequency_minutes": 30
    },
    {
        "name": "Wall Street Journal Economy",
        "url": "https://www.wsj.com/economy",
        "scrape_frequency_minutes": 30
    },
    {
        "name": "MarketWatch Economy",
        "url": "https://www.marketwatch.com/economy-politics",
        "scrape_frequency_minutes": 30
    },
    {
        "name": "Investing.com Economic Calendar",
        "url": "https://www.investing.com/economic-calendar/",
        "scrape_frequency_minutes": 30
    },
    {
        "name": "ForexFactory News",
        "url": "https://www.forexfactory.com/news",
        "scrape_frequency_minutes": 30
    },
    {
        "name": "FXStreet News",
        "url": "https://www.fxstreet.com/news",
        "scrape_frequency_minutes": 30
    },
    {
        "name": "DailyFX News",
        "url": "https://www.dailyfx.com/news",
        "scrape_frequency_minutes": 30
    },
    {
        "name": "Yahoo Finance",
        "url": "https://finance.yahoo.com/",
        "scrape_frequency_minutes": 30
    },
    {
        "name": "The Economist Economics",
        "url": "https://www.economist.com/finance-and-economics",
        "scrape_frequency_minutes": 60
    },
    {
        "name": "BBC Business",
        "url": "https://www.bbc.com/business",
        "scrape_frequency_minutes": 30
    },
    {
        "name": "CNN Business",
        "url": "https://www.cnn.com/business",
        "scrape_frequency_minutes": 30
    },
    {
        "name": "Trading Economics",
        "url": "https://tradingeconomics.com/",
        "scrape_frequency_minutes": 30
    }
]

def init_sources():
    logger.info("Initializing news sources...")

    try:
        supabase = get_supabase()
        added = 0
        skipped = 0

        for source in NEWS_SOURCES:
            try:
                existing = supabase.table("news_sources").select("id").eq("url", source["url"]).execute()

                if existing.data:
                    logger.info(f"Source already exists: {source['name']}")
                    skipped += 1
                    continue

                supabase.table("news_sources").insert({
                    "name": source["name"],
                    "url": source["url"],
                    "scrape_frequency_minutes": source["scrape_frequency_minutes"],
                    "is_active": True
                }).execute()

                logger.info(f"Added source: {source['name']}")
                added += 1

            except Exception as e:
                logger.error(f"Error adding source {source['name']}: {e}")
                continue

        logger.info(f"Initialization complete. Added: {added}, Skipped: {skipped}")

    except Exception as e:
        logger.error(f"Error initializing sources: {e}")
        sys.exit(1)

if __name__ == "__main__":
    init_sources()
