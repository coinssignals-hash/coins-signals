# Guía de Inicio Rápido

Pon tu API en funcionamiento en 5 minutos.

## Paso 1: Instalar Python

Asegúrate de tener Python 3.9 o superior instalado:

```bash
python --version
```

Si no lo tienes, descárgalo desde [python.org](https://www.python.org/downloads/)

## Paso 2: Crear Entorno Virtual

```bash
# Navegar a la carpeta del proyecto
cd project

# Crear entorno virtual
python -m venv venv

# Activar entorno virtual
# En Windows:
venv\Scripts\activate

# En Mac/Linux:
source venv/bin/activate
```

## Paso 3: Instalar Dependencias

```bash
pip install -r requirements.txt
```

## Paso 4: Configurar Variables de Entorno

1. Copiar el archivo de ejemplo:
```bash
cp .env.example .env
```

2. Editar `.env` con tus credenciales:

```env
# Supabase (obtener de https://supabase.com)
SUPABASE_URL=https://tu-proyecto.supabase.co
SUPABASE_KEY=tu_anon_key
SUPABASE_SERVICE_ROLE_KEY=tu_service_role_key

# OpenAI (obtener de https://platform.openai.com)
OPENAI_API_KEY=sk-tu-api-key
```

### ¿Cómo obtener las credenciales?

**Supabase:**
1. Ir a [supabase.com](https://supabase.com)
2. Crear cuenta gratuita
3. Crear nuevo proyecto
4. Ir a Settings → API
5. Copiar `URL`, `anon key` y `service_role key`

**OpenAI:**
1. Ir a [platform.openai.com](https://platform.openai.com)
2. Crear cuenta
3. Ir a API Keys
4. Crear nueva API key
5. Copiar la key

## Paso 5: Inicializar Fuentes de Noticias

```bash
python scripts/init_sources.py
```

Esto añadirá 15 fuentes confiables de noticias económicas.

## Paso 6: Ejecutar el Servidor

```bash
python run.py
```

O usando uvicorn directamente:

```bash
uvicorn app.main:app --reload
```

## Paso 7: Probar la API

Abre tu navegador en:
- **Documentación interactiva:** http://localhost:8000/docs
- **API alternativa:** http://localhost:8000/redoc

## Comandos Útiles

### Activar procesamiento manual

```bash
# Scraping manual
curl -X POST http://localhost:8000/api/v1/admin/scrape

# Análisis manual
curl -X POST http://localhost:8000/api/v1/admin/analyze

# Generar datos históricos
curl -X POST http://localhost:8000/api/v1/admin/historical
```

### Ver estadísticas del sistema

```bash
curl http://localhost:8000/api/v1/admin/stats
```

### Listar noticias

```bash
curl http://localhost:8000/api/v1/news/list?page=1&page_size=10
```

## Solución Rápida de Problemas

**Error: "Module not found"**
```bash
pip install -r requirements.txt
```

**Error: "Supabase connection failed"**
- Verifica que copiaste correctamente las credenciales en `.env`
- Asegúrate que el proyecto Supabase está activo

**Error: "OpenAI API error"**
- Verifica tu API key
- Comprueba que tienes créditos en tu cuenta OpenAI

**No se generan noticias**
- Espera 30 minutos para el primer scraping automático
- O ejecuta manualmente: `POST /api/v1/admin/scrape`

## Próximos Pasos

1. Lee `README.md` para documentación completa
2. Revisa `EXAMPLES.md` para ver respuestas JSON de ejemplo
3. Explora la documentación interactiva en `/docs`
4. Personaliza las fuentes de noticias según tus necesidades

## Despliegue en la Nube

### Opción 1: Railway

```bash
# Instalar Railway CLI
npm install -g @railway/cli

# Login y deploy
railway login
railway init
railway up
```

### Opción 2: Docker

```bash
# Construir imagen
docker build -t trading-news-api .

# Ejecutar contenedor
docker run -p 8000:8000 --env-file .env trading-news-api
```

### Opción 3: Docker Compose

```bash
docker-compose up
```

---

**¡Listo!** Tu API está funcionando y lista para consumir desde tu app móvil.
