# 🚀 Multi-Broker Trading API - Quick Start

## ⚡ Inicio Rápido (5 minutos)

### 1️⃣ Instalar Dependencias

```bash
pip install -r requirements.txt
```

### 2️⃣ Configurar Variables de Entorno

```bash
cp .env.example .env
```

Editar `.env` y configurar:

```env
# Supabase (Requerido)
SUPABASE_URL=https://tu-proyecto.supabase.co
SUPABASE_KEY=tu-anon-key
SUPABASE_SERVICE_ROLE_KEY=tu-service-role-key

# Generar clave de cifrado (Requerido)
# Ejecutar: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
ENCRYPTION_KEY=tu-clave-generada-aqui
```

### 3️⃣ Iniciar el Servidor

```bash
python run.py
```

La API estará disponible en:
- **API**: http://localhost:8000
- **Docs Interactivos**: http://localhost:8000/docs

---

## 📝 Ejemplo Básico: Trading en Alpaca

### Paso 1: Obtener Credenciales de Alpaca

1. Crear cuenta en: https://alpaca.markets
2. Obtener `API Key` y `API Secret` desde el dashboard
3. Por defecto, estarás en **Paper Trading** (demo)

### Paso 2: Conectar tu Broker

```bash
curl -X POST "http://localhost:8000/api/brokers/connections" \
  -H "Content-Type: application/json" \
  -d '{
    "broker_id": "UUID_DEL_BROKER_ALPACA",
    "connection_name": "My Alpaca Demo",
    "environment": "demo",
    "credentials": {
      "api_key": "TU_API_KEY",
      "api_secret": "TU_API_SECRET"
    }
  }'
```

**Response:**
```json
{
  "id": "connection-uuid-12345",
  "is_connected": true,
  "broker": {
    "code": "alpaca",
    "display_name": "Alpaca"
  }
}
```

### Paso 3: Colocar tu Primera Orden

```bash
curl -X POST "http://localhost:8000/api/trading/orders" \
  -H "Content-Type: application/json" \
  -d '{
    "connection_id": "connection-uuid-12345",
    "symbol": "AAPL",
    "asset_type": "stock",
    "side": "buy",
    "order_type": "limit",
    "quantity": 10,
    "limit_price": 150.00,
    "time_in_force": "gtc"
  }'
```

**Response:**
```json
{
  "id": "order-uuid",
  "broker_order_id": "alpaca-order-id",
  "symbol": "AAPL",
  "status": "submitted",
  "quantity": 10,
  "limit_price": 150.00
}
```

### Paso 4: Ver tus Posiciones

```bash
curl "http://localhost:8000/api/trading/positions?connection_id=connection-uuid-12345"
```

### Paso 5: Ver Balance de Cuenta

```bash
curl "http://localhost:8000/api/trading/account?connection_id=connection-uuid-12345"
```

---

## 🌍 Ejemplo: Trading Forex con OANDA

### Paso 1: Obtener Credenciales de OANDA

1. Crear cuenta en: https://www.oanda.com
2. Obtener `API Token` y `Account ID`
3. Usa el ambiente de **Practice** para demo

### Paso 2: Conectar OANDA

```bash
curl -X POST "http://localhost:8000/api/brokers/connections" \
  -H "Content-Type: application/json" \
  -d '{
    "broker_id": "UUID_DEL_BROKER_OANDA",
    "connection_name": "OANDA Forex Demo",
    "environment": "demo",
    "credentials": {
      "api_key": "TU_API_TOKEN",
      "account_id": "TU_ACCOUNT_ID"
    }
  }'
```

### Paso 3: Operar en EUR/USD

```bash
curl -X POST "http://localhost:8000/api/trading/orders" \
  -H "Content-Type: application/json" \
  -d '{
    "connection_id": "oanda-connection-uuid",
    "symbol": "EUR/USD",
    "asset_type": "forex",
    "side": "buy",
    "order_type": "market",
    "quantity": 10000,
    "stop_loss_price": 1.0850,
    "take_profit_price": 1.0950
  }'
```

---

## 🔥 Feature Destacado: Órdenes Multi-Broker

Coloca la misma orden en **múltiples brokers simultáneamente**:

```bash
curl -X POST "http://localhost:8000/api/trading/orders/multi" \
  -H "Content-Type: application/json" \
  -d '{
    "connection_ids": [
      "alpaca-uuid",
      "oanda-uuid",
      "ib-uuid"
    ],
    "symbol": "AAPL",
    "asset_type": "stock",
    "side": "buy",
    "order_type": "market",
    "quantity": 100
  }'
```

**Response:**
```json
{
  "total_submitted": 3,
  "successful": [
    {"id": "order1", "status": "filled"},
    {"id": "order2", "status": "filled"}
  ],
  "failed": [
    {"connection_id": "ib-uuid", "error": "Market closed"}
  ]
}
```

---

## 📊 Obtener Datos de Mercado

### Cotización en Tiempo Real

```bash
curl "http://localhost:8000/api/trading/quotes/AAPL?connection_id=alpaca-uuid"
```

**Response:**
```json
{
  "symbol": "AAPL",
  "bid_price": 154.95,
  "ask_price": 155.05,
  "last_price": 155.00,
  "volume": 5000000,
  "daily_change_percent": 1.64
}
```

### Datos Históricos (OHLCV)

```bash
curl "http://localhost:8000/api/trading/historical/AAPL?connection_id=alpaca-uuid&timeframe=1Day&start=2024-01-01&limit=30"
```

---

## 🎯 Tipos de Órdenes Soportadas

### Market Order (Ejecución Inmediata)

```json
{
  "order_type": "market",
  "quantity": 100
}
```

### Limit Order (Precio Específico)

```json
{
  "order_type": "limit",
  "quantity": 100,
  "limit_price": 150.00
}
```

### Stop Loss Order

```json
{
  "order_type": "stop",
  "quantity": 100,
  "stop_price": 145.00
}
```

### Bracket Order (TP + SL)

```json
{
  "order_type": "market",
  "quantity": 100,
  "take_profit_price": 160.00,
  "stop_loss_price": 145.00
}
```

### Trailing Stop

```json
{
  "order_type": "trailing_stop",
  "quantity": 100,
  "trailing_percent": 5.0
}
```

---

## 🛠 Gestión de Órdenes

### Modificar Orden

```bash
curl -X PUT "http://localhost:8000/api/trading/orders/{order_id}" \
  -H "Content-Type: application/json" \
  -d '{
    "limit_price": 152.00,
    "quantity": 150
  }'
```

### Cancelar Orden

```bash
curl -X DELETE "http://localhost:8000/api/trading/orders/{order_id}"
```

### Listar Órdenes

```bash
# Todas las órdenes
curl "http://localhost:8000/api/trading/orders"

# Solo órdenes completadas
curl "http://localhost:8000/api/trading/orders?status=filled"

# Por conexión específica
curl "http://localhost:8000/api/trading/orders?connection_id=alpaca-uuid"
```

---

## 🔐 Seguridad

### ✅ Todas las credenciales están cifradas

Las credenciales de tus brokers se cifran con **AES-128** antes de guardarse en la base de datos.

### ✅ Row Level Security (RLS)

Solo puedes ver y operar con tus propias cuentas.

### ✅ Audit Logs

Todas las operaciones se registran para compliance.

---

## 🏦 Brokers Soportados (7 implementados)

| Broker              | Stocks | Forex | Crypto | Options | Futures | CFDs |
|---------------------|--------|-------|--------|---------|---------|------|
| **Alpaca**          | ✅     | ❌    | ✅     | ❌      | ❌      | ❌   |
| **OANDA**           | ❌     | ✅    | ❌     | ❌      | ❌      | ✅   |
| **Interactive Brokers** | ✅ | ✅    | ❌     | ✅      | ✅      | ❌   |
| **IG Markets**      | ✅     | ✅    | ❌     | ✅      | ✅      | ✅   |
| **FOREX.com**       | ❌     | ✅    | ✅     | ❌      | ❌      | ✅   |
| **FXCM**            | ❌     | ✅    | ❌     | ❌      | ❌      | ✅   |
| **Pepperstone**     | ✅     | ✅    | ✅     | ❌      | ❌      | ✅   |

### Próximamente:
- Saxo Bank
- Dukascopy
- AvaTrade
- Plus500
- XTB

---

## 📖 Documentación Completa

Para más detalles, consulta:
- [TRADING_API_DOCS.md](./TRADING_API_DOCS.md) - Documentación completa
- http://localhost:8000/docs - Swagger UI interactivo

---

## 🆘 Troubleshooting

### Error: "Broker not found"

1. Verifica que el broker esté en la base de datos:
```bash
curl "http://localhost:8000/api/brokers"
```

2. Si no aparece, ejecuta la migración de base de datos nuevamente.

### Error: "Connection failed"

1. Verifica tus credenciales
2. Asegúrate de que el ambiente sea correcto (`demo` o `live`)
3. Para Interactive Brokers, asegúrate de que IB Gateway esté corriendo

### Error: "ENCRYPTION_KEY not set"

Genera una clave de cifrado:
```bash
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

Agrégala a tu `.env`:
```env
ENCRYPTION_KEY=la-clave-generada-aqui
```

---

## 💡 Tips

1. **Siempre usa `demo` o `paper trading` primero**
2. **Verifica tu conexión** antes de operar: `POST /brokers/connections/{id}/test`
3. **Usa stop loss y take profit** para gestionar riesgo
4. **Monitorea tus posiciones** regularmente: `GET /trading/positions`

---

## 🎉 ¡Listo para Trading!

Ya tienes todo configurado. Comienza a operar en múltiples brokers con una sola API unificada.

**Happy Trading! 📈**
