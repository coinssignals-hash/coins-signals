# Cómo Descargar y Usar el Proyecto

Esta guía te explica paso a paso cómo descargar el proyecto completo a tu computadora.

## 📦 Ubicación del Proyecto

El proyecto está ubicado en:
```
/tmp/cc-agent/61935029/project
```

## 💾 Método 1: Copiar la Carpeta (Recomendado)

### En Windows:

1. **Abrir Explorador de Archivos**
2. **Navegar a la carpeta temporal:**
   - Pegar en la barra de dirección: `/tmp/cc-agent/61935029/project`
   - O buscar manualmente la carpeta

3. **Copiar toda la carpeta "project"**
   - Clic derecho sobre la carpeta `project`
   - Seleccionar "Copiar"

4. **Pegar en tu ubicación deseada:**
   ```
   C:\Users\TuUsuario\Documents\trading-news-api
   ```

### En Mac:

```bash
# Abrir Terminal
cd ~

# Copiar carpeta completa
cp -r /tmp/cc-agent/61935029/project ~/trading-news-api

# Verificar
cd ~/trading-news-api
ls -la
```

### En Linux:

```bash
# Abrir Terminal
cd ~

# Copiar carpeta completa
cp -r /tmp/cc-agent/61935029/project ~/trading-news-api

# Cambiar permisos si es necesario
chmod -R 755 ~/trading-news-api

# Verificar
cd ~/trading-news-api
ls -la
```

## 📋 Método 2: Crear ZIP

### Windows/Mac/Linux:

```bash
# Crear archivo ZIP
cd /tmp/cc-agent/61935029
zip -r trading-news-api.zip project/

# Mover a tu carpeta de descargas
mv trading-news-api.zip ~/Downloads/

# Descomprimir en destino
cd ~/Documents
unzip ~/Downloads/trading-news-api.zip
mv project trading-news-api
```

## ✅ Verificar Estructura Completa

Después de copiar/descargar, verifica que tengas esta estructura:

```
trading-news-api/
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── api/
│   │   ├── __init__.py
│   │   ├── admin_endpoints.py
│   │   └── news_endpoints.py
│   ├── core/
│   │   ├── __init__.py
│   │   └── config.py
│   ├── db/
│   │   ├── __init__.py
│   │   └── supabase_client.py
│   ├── schemas/
│   │   ├── __init__.py
│   │   └── news_schemas.py
│   └── services/
│       ├── __init__.py
│       ├── ai_analysis_service.py
│       ├── historical_service.py
│       ├── scraper_service.py
│       └── utils.py
├── scripts/
│   ├── __init__.py
│   └── init_sources.py
├── .env.example
├── .gitignore
├── Dockerfile
├── docker-compose.yml
├── EXAMPLES.md
├── INSTRUCCIONES_DESCARGA.md
├── QUICKSTART.md
├── README.md
├── requirements.txt
├── run.py
└── supabase_migration.sql
```

## 🔍 Comando de Verificación

Ejecuta este comando para contar los archivos:

### Windows (PowerShell):
```powershell
Get-ChildItem -Recurse -File | Measure-Object | Select-Object Count
```

### Mac/Linux:
```bash
find . -type f | wc -l
```

Deberías tener **aproximadamente 24-26 archivos** en total.

## 📝 Lista de Archivos por Tipo

### Archivos Python (código fuente):
- `app/__init__.py`
- `app/main.py`
- `app/api/__init__.py`
- `app/api/admin_endpoints.py`
- `app/api/news_endpoints.py`
- `app/core/__init__.py`
- `app/core/config.py`
- `app/db/__init__.py`
- `app/db/supabase_client.py`
- `app/schemas/__init__.py`
- `app/schemas/news_schemas.py`
- `app/services/__init__.py`
- `app/services/ai_analysis_service.py`
- `app/services/historical_service.py`
- `app/services/scraper_service.py`
- `app/services/utils.py`
- `scripts/__init__.py`
- `scripts/init_sources.py`
- `run.py`

### Archivos de Configuración:
- `.env.example` - Plantilla de variables de entorno
- `.gitignore` - Archivos a ignorar en Git
- `requirements.txt` - Dependencias Python
- `Dockerfile` - Para Docker
- `docker-compose.yml` - Para Docker Compose

### Archivos de Base de Datos:
- `supabase_migration.sql` - Script SQL para crear tablas

### Archivos de Documentación:
- `README.md` - Documentación completa
- `QUICKSTART.md` - Guía de inicio rápido
- `EXAMPLES.md` - Ejemplos de respuestas JSON
- `INSTRUCCIONES_DESCARGA.md` - Este archivo

## 🚀 Próximos Pasos

Una vez descargado el proyecto:

1. **Lee el archivo QUICKSTART.md**
   - Guía de instalación paso a paso
   - Configuración de credenciales
   - Ejecución del servidor

2. **Configura el archivo .env**
   - Copia `.env.example` a `.env`
   - Añade tus credenciales de Supabase
   - Añade tu API key de OpenAI

3. **Instala las dependencias**
   ```bash
   python -m venv venv
   source venv/bin/activate  # Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

4. **Aplica las migraciones de base de datos**
   - Abre Supabase
   - Ve a SQL Editor
   - Ejecuta el contenido de `supabase_migration.sql`

5. **Inicializa las fuentes**
   ```bash
   python scripts/init_sources.py
   ```

6. **Ejecuta el servidor**
   ```bash
   python run.py
   ```

7. **Abre la documentación**
   - http://localhost:8000/docs

## ❓ Preguntas Frecuentes

### ¿Puedo renombrar la carpeta?
Sí, puedes renombrar la carpeta principal como quieras. El código interno funciona con rutas relativas.

### ¿Necesito todos los archivos?
Sí, todos los archivos son necesarios para que el proyecto funcione correctamente.

### ¿Puedo eliminar los archivos .md?
Los archivos de documentación (.md) no son necesarios para que el código funcione, pero son muy útiles como referencia.

### ¿Qué hago si falta algún archivo?
Vuelve a copiar la carpeta completa desde la ubicación original.

### ¿Dónde guardo mis credenciales?
Crea un archivo `.env` en la raíz del proyecto (copia de `.env.example`) y añade tus credenciales ahí.

## 🔒 Seguridad

**IMPORTANTE:**
- NUNCA subas el archivo `.env` a Git o repositorios públicos
- Mantén tus API keys privadas
- El archivo `.gitignore` ya está configurado para proteger `.env`

## 📞 Soporte

Si tienes problemas con la descarga o instalación:

1. Verifica que copiaste TODOS los archivos
2. Revisa la estructura de carpetas
3. Lee QUICKSTART.md para instrucciones detalladas
4. Consulta README.md para documentación completa

---

**¡Listo para empezar!** 🎉

Una vez descargado y verificado, continúa con `QUICKSTART.md` para poner en marcha tu API.
