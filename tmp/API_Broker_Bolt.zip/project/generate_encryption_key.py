#!/usr/bin/env python3
"""
Script para generar una clave de cifrado segura para el sistema de trading.
"""

from cryptography.fernet import Fernet
import os
from pathlib import Path


def generate_key():
    key = Fernet.generate_key()
    return key.decode()


def update_env_file(encryption_key: str):
    env_path = Path(__file__).parent / '.env'

    if not env_path.exists():
        print("⚠️  Archivo .env no encontrado. Creando desde .env.example...")
        example_path = Path(__file__).parent / '.env.example'
        if example_path.exists():
            with open(example_path, 'r') as f:
                content = f.read()
            with open(env_path, 'w') as f:
                f.write(content)
        else:
            print("❌ .env.example no encontrado")
            return False

    with open(env_path, 'r') as f:
        lines = f.readlines()

    updated = False
    for i, line in enumerate(lines):
        if line.startswith('ENCRYPTION_KEY=') and 'your-encryption-key-here' in line:
            lines[i] = f'ENCRYPTION_KEY={encryption_key}\n'
            updated = True
            break

    if updated:
        with open(env_path, 'w') as f:
            f.writelines(lines)
        return True

    return False


def main():
    print("🔐 Generando clave de cifrado para el sistema de trading...")
    print()

    encryption_key = generate_key()

    print("✅ Clave generada exitosamente:")
    print()
    print(f"   {encryption_key}")
    print()

    print("📝 Opciones:")
    print("   1. Copiar manualmente a tu archivo .env")
    print("   2. Actualizar automáticamente el archivo .env")
    print()

    choice = input("Selecciona una opción (1 o 2): ").strip()

    if choice == '2':
        if update_env_file(encryption_key):
            print("✅ Archivo .env actualizado exitosamente")
        else:
            print("⚠️  No se pudo actualizar automáticamente. Por favor, copia la clave manualmente.")
    else:
        print()
        print("📋 Copia esta línea a tu archivo .env:")
        print()
        print(f"ENCRYPTION_KEY={encryption_key}")
        print()

    print("✨ ¡Listo! Tu sistema de cifrado está configurado.")


if __name__ == '__main__':
    main()
