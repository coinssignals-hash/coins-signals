/*
  # Sistema Completo de Trading Multi-Broker

  1. Nuevas Tablas
    - `brokers`
      - Catálogo de brokers soportados (Alpaca, OANDA, IB, etc.)
      - Configuración de tipos de autenticación y activos soportados
    
    - `user_broker_connections`
      - Conexiones de usuarios a brokers
      - Credenciales cifradas y configuración por conexión
      - Soporte para ambientes demo/live
    
    - `orders`
      - Órdenes unificadas entre todos los brokers
      - Soporte para market, limit, stop, stop-limit
      - Stop loss, take profit, trailing stops
    
    - `positions`
      - Posiciones abiertas en tiempo real
      - Cálculo de PnL no realizado
    
    - `trades`
      - Ejecuciones/fills de órdenes
      - Histórico completo de transacciones
    
    - `account_snapshots`
      - Snapshots periódicos de cuentas
      - Balance, equity, margin, PnL
    
    - `market_data_cache`
      - Caché de datos de mercado
      - Precios en tiempo real y datos históricos
    
    - `user_mfa_settings`
      - Configuración 2FA/MFA por usuario
      - Múltiples métodos (TOTP, SMS, Email)
    
    - `api_keys`
      - API keys para acceso externo a la plataforma
      - Rate limiting y permisos granulares
    
    - `audit_logs`
      - Logs de auditoría de todas las operaciones
      - Tracking de trading y cambios de configuración

  2. Security
    - RLS habilitado en todas las tablas
    - Políticas restrictivas por usuario autenticado
    - Cifrado de credenciales en columnas sensibles
    - Logs de auditoría para compliance

  3. Funciones
    - Función para calcular PnL
    - Función para validar órdenes
    - Función para sincronizar datos de brokers
*/

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- =====================================================
-- 1. TABLA: brokers
-- =====================================================
CREATE TABLE IF NOT EXISTS brokers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT NOT NULL UNIQUE, -- 'alpaca', 'oanda', 'interactive_brokers', etc.
  display_name TEXT NOT NULL,
  description TEXT,
  logo_url TEXT,
  auth_type TEXT NOT NULL, -- 'api_key', 'oauth2', 'basic_auth', 'fix_api'
  supported_assets TEXT[] NOT NULL DEFAULT '{}', -- ['stocks', 'forex', 'crypto', 'options', 'futures', 'cfds']
  supported_order_types TEXT[] NOT NULL DEFAULT '{}', -- ['market', 'limit', 'stop', 'stop_limit', 'trailing_stop']
  api_documentation_url TEXT,
  base_url_live TEXT,
  base_url_demo TEXT,
  supports_websocket BOOLEAN DEFAULT false,
  websocket_url_live TEXT,
  websocket_url_demo TEXT,
  min_deposit DECIMAL,
  trading_fees_description TEXT,
  is_active BOOLEAN DEFAULT true,
  requires_2fa BOOLEAN DEFAULT false,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- =====================================================
-- 2. TABLA: user_broker_connections
-- =====================================================
CREATE TABLE IF NOT EXISTS user_broker_connections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  broker_id UUID NOT NULL REFERENCES brokers(id) ON DELETE CASCADE,
  connection_name TEXT NOT NULL,
  environment TEXT NOT NULL DEFAULT 'demo' CHECK (environment IN ('demo', 'live')),
  
  -- Credenciales cifradas (usar pgcrypto para cifrar en la aplicación)
  encrypted_credentials BYTEA NOT NULL, -- Credenciales cifradas
  credentials_iv BYTEA, -- Initialization vector para cifrado
  
  -- Configuración adicional
  config JSONB DEFAULT '{}'::jsonb,
  
  -- Estado de la conexión
  is_active BOOLEAN DEFAULT true,
  is_connected BOOLEAN DEFAULT false,
  last_connected_at TIMESTAMPTZ,
  last_sync_at TIMESTAMPTZ,
  connection_error TEXT,
  
  -- Metadata
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  
  UNIQUE(user_id, broker_id, connection_name, environment)
);

-- =====================================================
-- 3. TABLA: orders
-- =====================================================
CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  connection_id UUID NOT NULL REFERENCES user_broker_connections(id) ON DELETE CASCADE,
  
  -- Identificadores del broker
  broker_order_id TEXT, -- ID de la orden en el broker
  client_order_id TEXT NOT NULL UNIQUE, -- ID generado por nosotros
  
  -- Detalles de la orden
  symbol TEXT NOT NULL,
  asset_type TEXT NOT NULL, -- 'stock', 'forex', 'crypto', 'option', 'future', 'cfd'
  side TEXT NOT NULL CHECK (side IN ('buy', 'sell')),
  order_type TEXT NOT NULL CHECK (order_type IN ('market', 'limit', 'stop', 'stop_limit', 'trailing_stop')),
  time_in_force TEXT NOT NULL DEFAULT 'gtc' CHECK (time_in_force IN ('day', 'gtc', 'ioc', 'fok')),
  
  -- Cantidades y precios
  quantity DECIMAL NOT NULL CHECK (quantity > 0),
  filled_quantity DECIMAL DEFAULT 0 CHECK (filled_quantity >= 0),
  remaining_quantity DECIMAL GENERATED ALWAYS AS (quantity - filled_quantity) STORED,
  
  limit_price DECIMAL,
  stop_price DECIMAL,
  trailing_percent DECIMAL,
  trailing_amount DECIMAL,
  average_fill_price DECIMAL,
  
  -- Risk management
  stop_loss_price DECIMAL,
  take_profit_price DECIMAL,
  
  -- Estado
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN (
    'pending', 'submitted', 'accepted', 'partial_fill', 'filled', 
    'cancelled', 'rejected', 'expired', 'replaced'
  )),
  
  -- Tiempos
  submitted_at TIMESTAMPTZ,
  filled_at TIMESTAMPTZ,
  cancelled_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ,
  
  -- Metadata y errores
  rejection_reason TEXT,
  metadata JSONB DEFAULT '{}'::jsonb,
  
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- =====================================================
-- 4. TABLA: trades (ejecuciones)
-- =====================================================
CREATE TABLE IF NOT EXISTS trades (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  connection_id UUID NOT NULL REFERENCES user_broker_connections(id) ON DELETE CASCADE,
  
  broker_trade_id TEXT,
  symbol TEXT NOT NULL,
  side TEXT NOT NULL CHECK (side IN ('buy', 'sell')),
  
  quantity DECIMAL NOT NULL CHECK (quantity > 0),
  price DECIMAL NOT NULL CHECK (price > 0),
  commission DECIMAL DEFAULT 0,
  fees DECIMAL DEFAULT 0,
  
  executed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  metadata JSONB DEFAULT '{}'::jsonb,
  
  created_at TIMESTAMPTZ DEFAULT now()
);

-- =====================================================
-- 5. TABLA: positions
-- =====================================================
CREATE TABLE IF NOT EXISTS positions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  connection_id UUID NOT NULL REFERENCES user_broker_connections(id) ON DELETE CASCADE,
  
  symbol TEXT NOT NULL,
  asset_type TEXT NOT NULL,
  
  -- Cantidades
  quantity DECIMAL NOT NULL,
  available_quantity DECIMAL NOT NULL DEFAULT 0,
  
  -- Precios
  average_entry_price DECIMAL NOT NULL CHECK (average_entry_price > 0),
  current_price DECIMAL,
  last_price_update_at TIMESTAMPTZ,
  
  -- PnL
  unrealized_pnl DECIMAL DEFAULT 0,
  unrealized_pnl_percent DECIMAL DEFAULT 0,
  realized_pnl DECIMAL DEFAULT 0,
  total_pnl DECIMAL GENERATED ALWAYS AS (unrealized_pnl + realized_pnl) STORED,
  
  -- Costos
  total_cost DECIMAL NOT NULL DEFAULT 0,
  total_commission DECIMAL DEFAULT 0,
  total_fees DECIMAL DEFAULT 0,
  
  -- Market value
  market_value DECIMAL,
  
  -- Metadata
  metadata JSONB DEFAULT '{}'::jsonb,
  
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  
  UNIQUE(connection_id, symbol)
);

-- =====================================================
-- 6. TABLA: account_snapshots
-- =====================================================
CREATE TABLE IF NOT EXISTS account_snapshots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  connection_id UUID NOT NULL REFERENCES user_broker_connections(id) ON DELETE CASCADE,
  
  -- Balances
  cash_balance DECIMAL NOT NULL DEFAULT 0,
  equity DECIMAL NOT NULL DEFAULT 0,
  portfolio_value DECIMAL NOT NULL DEFAULT 0,
  
  -- Margin (si aplica)
  buying_power DECIMAL DEFAULT 0,
  margin_used DECIMAL DEFAULT 0,
  margin_available DECIMAL DEFAULT 0,
  maintenance_margin DECIMAL DEFAULT 0,
  
  -- PnL
  unrealized_pnl DECIMAL DEFAULT 0,
  realized_pnl_today DECIMAL DEFAULT 0,
  realized_pnl_total DECIMAL DEFAULT 0,
  
  -- Métricas
  total_positions_count INTEGER DEFAULT 0,
  total_open_orders_count INTEGER DEFAULT 0,
  
  -- Exposures
  long_exposure DECIMAL DEFAULT 0,
  short_exposure DECIMAL DEFAULT 0,
  net_exposure DECIMAL DEFAULT 0,
  
  -- Snapshot data completo del broker
  snapshot_data JSONB DEFAULT '{}'::jsonb,
  
  snapshot_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- =====================================================
-- 7. TABLA: market_data_cache
-- =====================================================
CREATE TABLE IF NOT EXISTS market_data_cache (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  broker_id UUID REFERENCES brokers(id) ON DELETE CASCADE,
  
  symbol TEXT NOT NULL,
  asset_type TEXT NOT NULL,
  
  -- Precio actual
  bid_price DECIMAL,
  ask_price DECIMAL,
  mid_price DECIMAL,
  last_price DECIMAL,
  
  -- Volume y cambios
  volume BIGINT,
  daily_change DECIMAL,
  daily_change_percent DECIMAL,
  
  -- OHLC del día
  open_price DECIMAL,
  high_price DECIMAL,
  low_price DECIMAL,
  close_price DECIMAL,
  
  -- Timestamps
  quote_time TIMESTAMPTZ,
  cached_at TIMESTAMPTZ DEFAULT now(),
  expires_at TIMESTAMPTZ,
  
  metadata JSONB DEFAULT '{}'::jsonb,
  
  UNIQUE(broker_id, symbol)
);

-- =====================================================
-- 8. TABLA: user_mfa_settings
-- =====================================================
CREATE TABLE IF NOT EXISTS user_mfa_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE,
  
  -- 2FA/MFA settings
  mfa_enabled BOOLEAN DEFAULT false,
  mfa_method TEXT CHECK (mfa_method IN ('totp', 'sms', 'email')),
  
  -- TOTP (Google Authenticator, Authy, etc.)
  totp_secret BYTEA, -- Cifrado
  totp_verified BOOLEAN DEFAULT false,
  
  -- Backup codes (cifrados)
  backup_codes BYTEA,
  
  -- Phone/Email para 2FA
  phone_number TEXT,
  phone_verified BOOLEAN DEFAULT false,
  
  -- Recovery
  recovery_email TEXT,
  recovery_email_verified BOOLEAN DEFAULT false,
  
  -- Metadata
  last_mfa_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- =====================================================
-- 9. TABLA: api_keys (para acceso externo)
-- =====================================================
CREATE TABLE IF NOT EXISTS api_keys (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  
  key_name TEXT NOT NULL,
  key_hash TEXT NOT NULL UNIQUE, -- Hash de la API key
  key_prefix TEXT NOT NULL, -- Primeros caracteres visibles
  
  -- Permisos
  permissions TEXT[] DEFAULT '{}', -- ['read', 'trade', 'manage']
  scopes TEXT[] DEFAULT '{}', -- ['orders', 'positions', 'account']
  
  -- Rate limiting
  rate_limit_per_minute INTEGER DEFAULT 60,
  
  -- Estado
  is_active BOOLEAN DEFAULT true,
  last_used_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ,
  
  -- IP whitelist (opcional)
  allowed_ips TEXT[] DEFAULT '{}',
  
  created_at TIMESTAMPTZ DEFAULT now()
);

-- =====================================================
-- 10. TABLA: audit_logs
-- =====================================================
CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  
  action TEXT NOT NULL, -- 'order_placed', 'order_cancelled', 'connection_added', etc.
  resource_type TEXT NOT NULL, -- 'order', 'connection', 'position', etc.
  resource_id UUID,
  
  -- Detalles
  details JSONB DEFAULT '{}'::jsonb,
  
  -- Metadata de la request
  ip_address INET,
  user_agent TEXT,
  
  -- Result
  success BOOLEAN NOT NULL,
  error_message TEXT,
  
  created_at TIMESTAMPTZ DEFAULT now()
);

-- =====================================================
-- ÍNDICES para optimización
-- =====================================================

-- Orders indexes
CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_connection_id ON orders(connection_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_symbol ON orders(symbol);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_broker_order_id ON orders(broker_order_id);

-- Trades indexes
CREATE INDEX IF NOT EXISTS idx_trades_user_id ON trades(user_id);
CREATE INDEX IF NOT EXISTS idx_trades_order_id ON trades(order_id);
CREATE INDEX IF NOT EXISTS idx_trades_executed_at ON trades(executed_at DESC);

-- Positions indexes
CREATE INDEX IF NOT EXISTS idx_positions_user_id ON positions(user_id);
CREATE INDEX IF NOT EXISTS idx_positions_connection_id ON positions(connection_id);
CREATE INDEX IF NOT EXISTS idx_positions_symbol ON positions(symbol);

-- Account snapshots indexes
CREATE INDEX IF NOT EXISTS idx_snapshots_user_id ON account_snapshots(user_id);
CREATE INDEX IF NOT EXISTS idx_snapshots_connection_id ON account_snapshots(connection_id);
CREATE INDEX IF NOT EXISTS idx_snapshots_snapshot_at ON account_snapshots(snapshot_at DESC);

-- Market data cache indexes
CREATE INDEX IF NOT EXISTS idx_market_data_symbol ON market_data_cache(symbol);
CREATE INDEX IF NOT EXISTS idx_market_data_cached_at ON market_data_cache(cached_at DESC);

-- Audit logs indexes
CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action ON audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at DESC);

-- =====================================================
-- FUNCIONES ÚTILES
-- =====================================================

-- Función para actualizar updated_at automáticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers para updated_at
CREATE TRIGGER update_brokers_updated_at BEFORE UPDATE ON brokers
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_connections_updated_at BEFORE UPDATE ON user_broker_connections
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_orders_updated_at BEFORE UPDATE ON orders
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_positions_updated_at BEFORE UPDATE ON positions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_mfa_updated_at BEFORE UPDATE ON user_mfa_settings
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- ROW LEVEL SECURITY (RLS)
-- =====================================================

-- Habilitar RLS en todas las tablas de usuario
ALTER TABLE brokers ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_broker_connections ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE trades ENABLE ROW LEVEL SECURITY;
ALTER TABLE positions ENABLE ROW LEVEL SECURITY;
ALTER TABLE account_snapshots ENABLE ROW LEVEL SECURITY;
ALTER TABLE market_data_cache ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_mfa_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE api_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- Policies para brokers (lectura pública, escritura admin)
CREATE POLICY "Anyone can view active brokers"
  ON brokers FOR SELECT
  TO authenticated
  USING (is_active = true);

-- Policies para user_broker_connections
CREATE POLICY "Users can view own broker connections"
  ON user_broker_connections FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own broker connections"
  ON user_broker_connections FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own broker connections"
  ON user_broker_connections FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own broker connections"
  ON user_broker_connections FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Policies para orders
CREATE POLICY "Users can view own orders"
  ON orders FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own orders"
  ON orders FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own orders"
  ON orders FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own orders"
  ON orders FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Policies para trades
CREATE POLICY "Users can view own trades"
  ON trades FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own trades"
  ON trades FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Policies para positions
CREATE POLICY "Users can view own positions"
  ON positions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own positions"
  ON positions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own positions"
  ON positions FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own positions"
  ON positions FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Policies para account_snapshots
CREATE POLICY "Users can view own account snapshots"
  ON account_snapshots FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own account snapshots"
  ON account_snapshots FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Policies para market_data_cache (lectura pública para autenticados)
CREATE POLICY "Authenticated users can view market data"
  ON market_data_cache FOR SELECT
  TO authenticated
  USING (true);

-- Policies para user_mfa_settings
CREATE POLICY "Users can view own MFA settings"
  ON user_mfa_settings FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own MFA settings"
  ON user_mfa_settings FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own MFA settings"
  ON user_mfa_settings FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Policies para api_keys
CREATE POLICY "Users can view own API keys"
  ON api_keys FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own API keys"
  ON api_keys FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own API keys"
  ON api_keys FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own API keys"
  ON api_keys FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Policies para audit_logs (solo lectura de propios logs)
CREATE POLICY "Users can view own audit logs"
  ON audit_logs FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "System can insert audit logs"
  ON audit_logs FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- =====================================================
-- DATOS INICIALES: Insertar brokers soportados
-- =====================================================

INSERT INTO brokers (code, display_name, description, auth_type, supported_assets, supported_order_types, api_documentation_url, base_url_live, base_url_demo, supports_websocket, websocket_url_live, websocket_url_demo, is_active)
VALUES
  (
    'alpaca',
    'Alpaca',
    'Commission-free trading for stocks, ETFs, and crypto with developer-friendly API',
    'api_key',
    ARRAY['stocks', 'etfs', 'crypto'],
    ARRAY['market', 'limit', 'stop', 'stop_limit', 'trailing_stop'],
    'https://docs.alpaca.markets/docs',
    'https://api.alpaca.markets',
    'https://paper-api.alpaca.markets',
    true,
    'wss://stream.data.alpaca.markets',
    'wss://stream.data.alpaca.markets',
    true
  ),
  (
    'oanda',
    'OANDA',
    'Forex and CFD trading with competitive spreads and powerful API',
    'api_key',
    ARRAY['forex', 'cfds'],
    ARRAY['market', 'limit', 'stop', 'market_if_touched'],
    'https://developer.oanda.com/rest-live-v20/introduction/',
    'https://api-fxtrade.oanda.com',
    'https://api-fxpractice.oanda.com',
    true,
    'wss://stream-fxtrade.oanda.com',
    'wss://stream-fxpractice.oanda.com',
    true
  ),
  (
    'interactive_brokers',
    'Interactive Brokers',
    'Multi-asset broker with access to 150+ markets worldwide',
    'oauth2',
    ARRAY['stocks', 'options', 'futures', 'forex', 'bonds', 'funds'],
    ARRAY['market', 'limit', 'stop', 'stop_limit', 'trailing_stop'],
    'https://www.interactivebrokers.com/api/doc.html',
    'https://api.ibkr.com/v1/api',
    'https://api.ibkr.com/v1/api',
    true,
    null,
    null,
    true
  )
ON CONFLICT (code) DO NOTHING;
