# Ejemplos de Respuestas JSON

Este documento contiene ejemplos reales de las respuestas JSON que devuelve la API.

## Endpoint: GET /api/v1/news/list

**Request:**
```http
GET /api/v1/news/list?page=1&page_size=3&currency=EUR
```

**Response (200 OK):**
```json
{
  "news": [
    {
      "id": "a3b7f8c2-4d1e-4a9b-8f2c-1e3d4a5b6c7d",
      "title": "ECB Signals Potential Rate Hike Amidst Inflation Concerns",
      "image_url": "https://example.com/images/ecb-building.jpg",
      "source_name": "Reuters",
      "published_at": "2025-12-27T14:30:00+00:00",
      "time_ago": "2 hours ago",
      "economic_category": "Interest Rates",
      "affected_currencies": ["EUR", "USD"],
      "primary_sentiment": "bullish"
    },
    {
      "id": "b4c8g9d3-5e2f-5b0c-9g3d-2f4e5b6c7d8e",
      "title": "Eurozone GDP Growth Exceeds Expectations in Q4",
      "image_url": "https://example.com/images/eurozone-growth.jpg",
      "source_name": "Bloomberg",
      "published_at": "2025-12-27T10:15:00+00:00",
      "time_ago": "6 hours ago",
      "economic_category": "GDP",
      "affected_currencies": ["EUR", "GBP", "CHF"],
      "primary_sentiment": "bullish"
    },
    {
      "id": "c5d9h0e4-6f3g-6c1d-0h4e-3g5f6c7d8e9f",
      "title": "German Manufacturing Data Shows Contraction",
      "image_url": "https://example.com/images/german-factory.jpg",
      "source_name": "Financial Times",
      "published_at": "2025-12-26T16:45:00+00:00",
      "time_ago": "1 day ago",
      "economic_category": "Manufacturing Data",
      "affected_currencies": ["EUR"],
      "primary_sentiment": "bearish"
    }
  ],
  "total": 127,
  "page": 1,
  "page_size": 3
}
```

---

## Endpoint: GET /api/v1/news/{article_id}

**Request:**
```http
GET /api/v1/news/a3b7f8c2-4d1e-4a9b-8f2c-1e3d4a5b6c7d
```

**Response (200 OK):**
```json
{
  "id": "a3b7f8c2-4d1e-4a9b-8f2c-1e3d4a5b6c7d",
  "title": "ECB Signals Potential Rate Hike Amidst Inflation Concerns",
  "image_url": "https://example.com/images/ecb-building.jpg",
  "source_name": "Reuters",
  "source_url": "https://www.reuters.com/business/finance/ecb-signals-rate-hike-2025-12-27/",
  "published_at": "2025-12-27T14:30:00+00:00",
  "time_ago": "2 hours ago",
  "economic_category": "Interest Rates",
  "ai_summary": "El Banco Central Europeo (BCE) ha señalado hoy una postura más hawkish de lo esperado, sugiriendo que podría implementar una subida de tasas de interés en los próximos meses si la inflación continúa por encima del objetivo del 2%. La presidenta Christine Lagarde destacó en su discurso que, aunque el crecimiento económico muestra signos de moderación, la persistencia de presiones inflacionarias en el sector servicios justifica mantener una vigilancia estrecha sobre la política monetaria. Los mercados han reaccionado inmediatamente, con el euro fortaleciéndose frente al dólar y las expectativas de tasas ajustándose al alza. Este movimiento marca un cambio significativo en la narrativa del BCE, que había mantenido un tono más cauteloso en reuniones anteriores. Los traders de forex deben prestar especial atención a los datos de inflación de la próxima semana, que serán determinantes para confirmar o desmentir este cambio de postura. El contexto global, con la Fed manteniendo tasas elevadas, añade complejidad al panorama de divisas.",
  "key_points": [
    "El BCE ha adoptado un tono más hawkish sobre la política monetaria futura",
    "Posible subida de tasas si la inflación permanece elevada, especialmente en servicios",
    "Christine Lagarde enfatizó la necesidad de vigilancia continua sobre presiones inflacionarias",
    "El euro se fortaleció inmediatamente tras el anuncio, ganando 0.8% frente al USD",
    "Los datos de inflación de la próxima semana serán cruciales para confirmar la dirección",
    "Divergencia con otras políticas de bancos centrales crea oportunidades de carry trade"
  ],
  "trader_conclusion": "Esta declaración hawkish del BCE representa una oportunidad alcista clara para el EUR. Los traders deben considerar posiciones largas en EUR/USD con objetivo en 1.1150 y stop loss en 1.0850. El sesgo de mercado es definitivamente bullish para el euro a corto-medio plazo. Sin embargo, es crucial monitorear los datos de inflación de la próxima semana, ya que una sorpresa a la baja podría revertir rápidamente este sentimiento. Las estrategias de carry trade favoreciendo el EUR contra divisas de bajo rendimiento (JPY, CHF) podrían ser particularmente atractivas. Atención especial a la volatilidad en torno a comunicados oficiales del BCE en las próximas semanas.",
  "currency_impacts": [
    {
      "currency_code": "EUR",
      "positive_percent": 80.0,
      "negative_percent": 10.0,
      "neutral_percent": 10.0,
      "overall_sentiment": "bullish"
    },
    {
      "currency_code": "USD",
      "positive_percent": 15.0,
      "negative_percent": 70.0,
      "neutral_percent": 15.0,
      "overall_sentiment": "bearish"
    },
    {
      "currency_code": "GBP",
      "positive_percent": 25.0,
      "negative_percent": 45.0,
      "neutral_percent": 30.0,
      "overall_sentiment": "bearish"
    },
    {
      "currency_code": "CHF",
      "positive_percent": 20.0,
      "negative_percent": 50.0,
      "neutral_percent": 30.0,
      "overall_sentiment": "bearish"
    }
  ],
  "affected_currencies": ["EUR", "USD", "GBP", "CHF"],
  "historical_data": [
    {
      "date": "2024-01",
      "currency_code": "EUR",
      "impact_value": -0.8,
      "event_description": "ECB mantiene tasas sin cambios"
    },
    {
      "date": "2024-02",
      "currency_code": "EUR",
      "impact_value": 1.2,
      "event_description": "Datos inflación eurozona superan expectativas"
    },
    {
      "date": "2024-03",
      "currency_code": "EUR",
      "impact_value": 2.5,
      "event_description": "ECB sube tasas +25bp inesperadamente"
    },
    {
      "date": "2024-04",
      "currency_code": "EUR",
      "impact_value": -1.5,
      "event_description": "Datos manufactura débiles en Alemania"
    },
    {
      "date": "2024-05",
      "currency_code": "EUR",
      "impact_value": 0.3,
      "event_description": "Lagarde mantiene tono neutral"
    },
    {
      "date": "2024-06",
      "currency_code": "EUR",
      "impact_value": 1.8,
      "event_description": "Reunión ECB señala preocupación inflación"
    },
    {
      "date": "2024-07",
      "currency_code": "EUR",
      "impact_value": -0.5,
      "event_description": "PIB eurozona decepciona expectativas"
    },
    {
      "date": "2024-08",
      "currency_code": "EUR",
      "impact_value": 0.7,
      "event_description": "Inflación servicios persistentemente alta"
    },
    {
      "date": "2024-09",
      "currency_code": "EUR",
      "impact_value": 1.1,
      "event_description": "Miembros ECB dividen opiniones tasas"
    },
    {
      "date": "2024-10",
      "currency_code": "EUR",
      "impact_value": 2.2,
      "event_description": "Datos empleo eurozona sólidos"
    },
    {
      "date": "2024-11",
      "currency_code": "EUR",
      "impact_value": 0.9,
      "event_description": "ECB pausa ciclo subidas tasas"
    },
    {
      "date": "2024-12",
      "currency_code": "EUR",
      "impact_value": 3.1,
      "event_description": "Discurso hawkish Lagarde sobre inflación"
    }
  ]
}
```

---

## Endpoint: GET /api/v1/news/currencies

**Response (200 OK):**
```json
[
  "EUR",
  "USD",
  "AUD",
  "CAD",
  "GBP",
  "JPY",
  "CHF",
  "NZD"
]
```

---

## Endpoint: GET /api/v1/news/categories

**Response (200 OK):**
```json
[
  "Interest Rates",
  "Employment",
  "GDP",
  "Inflation",
  "Trade Balance",
  "Central Bank Policy",
  "Consumer Confidence",
  "Manufacturing Data",
  "Retail Sales",
  "Housing Market"
]
```

---

## Endpoint: POST /api/v1/admin/sources

**Request:**
```http
POST /api/v1/admin/sources
Content-Type: application/json

{
  "name": "Reuters Business",
  "url": "https://www.reuters.com/business/",
  "scrape_frequency_minutes": 30
}
```

**Response (200 OK):**
```json
{
  "status": "success",
  "message": "News source added successfully",
  "data": {
    "id": "f7e8d9c0-1a2b-3c4d-5e6f-7g8h9i0j1k2l",
    "name": "Reuters Business",
    "url": "https://www.reuters.com/business/",
    "is_active": true,
    "scrape_frequency_minutes": 30,
    "last_scraped_at": null,
    "created_at": "2025-12-27T16:45:30+00:00"
  }
}
```

---

## Endpoint: GET /api/v1/admin/sources

**Response (200 OK):**
```json
{
  "status": "success",
  "data": [
    {
      "id": "f7e8d9c0-1a2b-3c4d-5e6f-7g8h9i0j1k2l",
      "name": "Reuters Business",
      "url": "https://www.reuters.com/business/",
      "is_active": true,
      "scrape_frequency_minutes": 30,
      "last_scraped_at": "2025-12-27T16:00:00+00:00",
      "created_at": "2025-12-27T10:00:00+00:00"
    },
    {
      "id": "g8f9e0d1-2b3c-4d5e-6f7g-8h9i0j1k2l3m",
      "name": "Bloomberg Economics",
      "url": "https://www.bloomberg.com/economics",
      "is_active": true,
      "scrape_frequency_minutes": 30,
      "last_scraped_at": "2025-12-27T15:30:00+00:00",
      "created_at": "2025-12-27T10:05:00+00:00"
    }
  ]
}
```

---

## Endpoint: POST /api/v1/admin/scrape

**Response (200 OK):**
```json
{
  "status": "success",
  "message": "Scraping started in background",
  "data": {
    "task": "running"
  }
}
```

---

## Endpoint: GET /api/v1/admin/stats

**Response (200 OK):**
```json
{
  "status": "success",
  "data": {
    "total_sources": 15,
    "total_articles": 453,
    "relevant_articles": 287,
    "analyzed_articles": 265,
    "pending_analysis": 22
  }
}
```

---

## Endpoint: GET /health

**Response (200 OK):**
```json
{
  "status": "healthy",
  "scheduler": true
}
```

---

## Errores Comunes

### 404 Not Found
```json
{
  "detail": "Article not found"
}
```

### 500 Internal Server Error
```json
{
  "detail": "Error fetching news"
}
```

### 400 Bad Request
```json
{
  "detail": "Source already exists"
}
```

---

## Notas sobre los Datos

### Formato de Fechas
- Todas las fechas se devuelven en formato ISO 8601 con timezone UTC
- Ejemplo: `"2025-12-27T14:30:00+00:00"`

### Porcentajes de Impacto
- Siempre suman 100% para cada divisa
- Representan la distribución de sentimiento del mercado
- Calculados por análisis de IA basado en contenido y contexto histórico

### Datos Históricos
- Cubren los últimos 12 meses
- `impact_value` representa el cambio porcentual aproximado
- Valores positivos = apreciación de la divisa
- Valores negativos = depreciación de la divisa

### Sentimientos
- `bullish`: Expectativa de fortalecimiento de la divisa
- `bearish`: Expectativa de debilitamiento de la divisa
- `neutral`: Sin dirección clara o impacto balanceado
