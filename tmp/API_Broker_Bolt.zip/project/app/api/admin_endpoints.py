from fastapi import APIRouter, HTTPException, BackgroundTasks
from typing import List
from loguru import logger
from app.db.supabase_client import get_supabase
from app.schemas.news_schemas import NewsSource, AddSourceRequest, AdminResponse
from app.services.scraper_service import NewsScraperService
from app.services.ai_analysis_service import AIAnalysisService
from app.services.historical_service import HistoricalDataService

router = APIRouter(prefix="/api/v1/admin", tags=["Admin"])

@router.post("/sources", response_model=AdminResponse)
async def add_news_source(source: AddSourceRequest):
    try:
        supabase = get_supabase()

        existing = supabase.table("news_sources").select("id").eq("url", source.url).execute()
        if existing.data:
            raise HTTPException(status_code=400, detail="Source already exists")

        source_data = {
            "name": source.name,
            "url": source.url,
            "scrape_frequency_minutes": source.scrape_frequency_minutes,
            "is_active": True
        }

        response = supabase.table("news_sources").insert(source_data).execute()

        return AdminResponse(
            status="success",
            message="News source added successfully",
            data=response.data[0]
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error adding news source: {e}")
        raise HTTPException(status_code=500, detail="Error adding news source")

@router.get("/sources", response_model=AdminResponse)
async def get_all_sources():
    try:
        supabase = get_supabase()
        response = supabase.table("news_sources").select("*").order("created_at", desc=True).execute()

        return AdminResponse(
            status="success",
            data=response.data
        )

    except Exception as e:
        logger.error(f"Error fetching sources: {e}")
        raise HTTPException(status_code=500, detail="Error fetching sources")

@router.post("/scrape", response_model=AdminResponse)
async def trigger_scraping(background_tasks: BackgroundTasks):
    try:
        background_tasks.add_task(run_scraping)

        return AdminResponse(
            status="success",
            message="Scraping started in background",
            data={"task": "running"}
        )

    except Exception as e:
        logger.error(f"Error triggering scraping: {e}")
        raise HTTPException(status_code=500, detail="Error triggering scraping")

@router.post("/analyze", response_model=AdminResponse)
async def trigger_analysis(background_tasks: BackgroundTasks):
    try:
        background_tasks.add_task(run_analysis)

        return AdminResponse(
            status="success",
            message="Analysis started in background",
            data={"task": "running"}
        )

    except Exception as e:
        logger.error(f"Error triggering analysis: {e}")
        raise HTTPException(status_code=500, detail="Error triggering analysis")

@router.post("/historical", response_model=AdminResponse)
async def trigger_historical_generation(background_tasks: BackgroundTasks):
    try:
        background_tasks.add_task(run_historical_generation)

        return AdminResponse(
            status="success",
            message="Historical data generation started in background",
            data={"task": "running"}
        )

    except Exception as e:
        logger.error(f"Error triggering historical generation: {e}")
        raise HTTPException(status_code=500, detail="Error triggering historical generation")

@router.get("/stats", response_model=AdminResponse)
async def get_statistics():
    try:
        supabase = get_supabase()

        sources = supabase.table("news_sources").select("id", count="exact").execute()
        articles = supabase.table("news_articles").select("id", count="exact").execute()
        relevant = supabase.table("news_articles").select("id", count="exact").eq("is_relevant", True).execute()
        analyzed = supabase.table("news_articles").select("id", count="exact").not_.is_("analysis_id", "null").execute()

        pending_analysis = relevant.count - analyzed.count if relevant.count and analyzed.count else 0

        stats = {
            "total_sources": sources.count or 0,
            "total_articles": articles.count or 0,
            "relevant_articles": relevant.count or 0,
            "analyzed_articles": analyzed.count or 0,
            "pending_analysis": pending_analysis
        }

        return AdminResponse(
            status="success",
            data=stats
        )

    except Exception as e:
        logger.error(f"Error fetching stats: {e}")
        raise HTTPException(status_code=500, detail="Error fetching statistics")

def run_scraping():
    try:
        logger.info("Starting background scraping task")
        scraper = NewsScraperService()
        result = scraper.scrape_all_sources()
        logger.info(f"Scraping completed: {result}")

        ai_service = AIAnalysisService()
        ai_service.analyze_all_pending()
        logger.info("Analysis completed")

        historical_service = HistoricalDataService()
        historical_service.generate_for_all_analyzed()
        logger.info("Historical data generation completed")

    except Exception as e:
        logger.error(f"Error in background scraping: {e}")

def run_analysis():
    try:
        logger.info("Starting background analysis task")
        ai_service = AIAnalysisService()
        result = ai_service.analyze_all_pending()
        logger.info(f"Analysis completed: {result}")

        historical_service = HistoricalDataService()
        historical_service.generate_for_all_analyzed()
        logger.info("Historical data generation completed")

    except Exception as e:
        logger.error(f"Error in background analysis: {e}")

def run_historical_generation():
    try:
        logger.info("Starting background historical data generation")
        historical_service = HistoricalDataService()
        result = historical_service.generate_for_all_analyzed()
        logger.info(f"Historical generation completed: {result}")

    except Exception as e:
        logger.error(f"Error in background historical generation: {e}")
