from fastapi import APIRouter, Depends, HTTPException, status, Query
from typing import List, Optional
from app.services.trading_service import trading_service
from app.schemas.broker_schemas import (
    OrderCreate, OrderResponse, OrderUpdate, MultiOrderCreate, MultiOrderResponse,
    PositionResponse, AccountSnapshot, MarketQuote
)
from datetime import datetime


router = APIRouter(prefix="/trading", tags=["trading"])


def get_current_user_id():
    return "user-placeholder-id"


@router.post("/orders", response_model=OrderResponse, status_code=status.HTTP_201_CREATED)
async def place_order(
    order: OrderCreate,
    user_id: str = Depends(get_current_user_id)
):
    try:
        result = await trading_service.place_order(user_id, order)
        return result
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.post("/orders/multi", response_model=MultiOrderResponse)
async def place_multi_broker_orders(
    multi_order: MultiOrderCreate,
    user_id: str = Depends(get_current_user_id)
):
    try:
        result = await trading_service.place_multi_broker_orders(user_id, multi_order)
        return result
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/orders", response_model=List[OrderResponse])
async def get_orders(
    connection_id: Optional[str] = Query(None),
    status_filter: Optional[str] = Query(None, alias="status"),
    limit: int = Query(100, ge=1, le=500),
    user_id: str = Depends(get_current_user_id)
):
    try:
        orders = await trading_service.get_orders(
            user_id,
            connection_id=connection_id,
            status=status_filter,
            limit=limit
        )
        return orders
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/orders/{order_id}", response_model=OrderResponse)
async def get_order(
    order_id: str,
    user_id: str = Depends(get_current_user_id)
):
    try:
        order = await trading_service.get_order(user_id, order_id)

        if not order:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Order not found"
            )

        return order
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.put("/orders/{order_id}", response_model=OrderResponse)
async def modify_order(
    order_id: str,
    updates: OrderUpdate,
    user_id: str = Depends(get_current_user_id)
):
    try:
        result = await trading_service.modify_order(user_id, order_id, updates)
        return result
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.delete("/orders/{order_id}", status_code=status.HTTP_204_NO_CONTENT)
async def cancel_order(
    order_id: str,
    user_id: str = Depends(get_current_user_id)
):
    try:
        success = await trading_service.cancel_order(user_id, order_id)

        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Order not found or could not be cancelled"
            )

        return None
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/positions", response_model=List[PositionResponse])
async def get_positions(
    connection_id: str = Query(...),
    user_id: str = Depends(get_current_user_id)
):
    try:
        positions = await trading_service.get_positions(user_id, connection_id)
        return positions
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/account", response_model=AccountSnapshot)
async def get_account(
    connection_id: str = Query(...),
    user_id: str = Depends(get_current_user_id)
):
    try:
        account = await trading_service.get_account(user_id, connection_id)
        return account
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/quotes/{symbol}", response_model=MarketQuote)
async def get_quote(
    symbol: str,
    connection_id: str = Query(...),
    user_id: str = Depends(get_current_user_id)
):
    try:
        quote = await trading_service.get_quote(user_id, connection_id, symbol)
        return quote
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/historical/{symbol}")
async def get_historical_data(
    symbol: str,
    connection_id: str = Query(...),
    timeframe: str = Query("1Day"),
    start: str = Query(...),
    end: Optional[str] = Query(None),
    limit: Optional[int] = Query(None, ge=1, le=10000),
    user_id: str = Depends(get_current_user_id)
):
    try:
        start_date = datetime.fromisoformat(start)
        end_date = datetime.fromisoformat(end) if end else None

        data = await trading_service.get_historical_data(
            user_id,
            connection_id,
            symbol,
            timeframe,
            start_date,
            end_date,
            limit
        )

        return {"symbol": symbol, "timeframe": timeframe, "data": data}
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )
