from fastapi import APIRouter, HTTPException, Query
from typing import Optional, List
from loguru import logger
from app.db.supabase_client import get_supabase
from app.schemas.news_schemas import NewsListResponse, NewsDetail, NewsListItem, CurrencyImpact, HistoricalDataPoint
from app.services.utils import calculate_time_ago
from app.core.config import settings
from datetime import datetime

router = APIRouter(prefix="/api/v1/news", tags=["News"])

@router.get("/list", response_model=NewsListResponse)
async def get_news_list(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    currency: Optional[str] = None,
    category: Optional[str] = None
):
    try:
        supabase = get_supabase()

        query = supabase.table("news_articles").select("*, news_sources(name), news_analysis(id)", count="exact")

        query = query.eq("is_relevant", True)
        query = query.not_.is_("analysis_id", "null")

        if currency:
            query = query.contains("affected_currencies", [currency])

        if category:
            query = query.eq("economic_category", category)

        query = query.order("published_at", desc=True)

        offset = (page - 1) * page_size
        query = query.range(offset, offset + page_size - 1)

        response = query.execute()

        news_items = []
        for article in response.data:
            impact_response = supabase.table("currency_impact").select("overall_sentiment").eq("article_id", article["id"]).limit(1).execute()

            primary_sentiment = "neutral"
            if impact_response.data:
                primary_sentiment = impact_response.data[0]["overall_sentiment"]

            published_at = datetime.fromisoformat(article["published_at"].replace('Z', '+00:00'))

            news_item = NewsListItem(
                id=article["id"],
                title=article["title"],
                image_url=article.get("image_url"),
                source_name=article["news_sources"]["name"],
                published_at=published_at,
                time_ago=calculate_time_ago(published_at),
                economic_category=article["economic_category"],
                affected_currencies=article["affected_currencies"],
                primary_sentiment=primary_sentiment
            )
            news_items.append(news_item)

        total = response.count if response.count else 0

        return NewsListResponse(
            news=news_items,
            total=total,
            page=page,
            page_size=page_size
        )

    except Exception as e:
        logger.error(f"Error fetching news list: {e}")
        raise HTTPException(status_code=500, detail="Error fetching news")

@router.get("/{article_id}", response_model=NewsDetail)
async def get_news_detail(article_id: str):
    try:
        supabase = get_supabase()

        article_response = supabase.table("news_articles").select("*, news_sources(name), news_analysis(*)").eq("id", article_id).maybeSingle().execute()

        if not article_response.data:
            raise HTTPException(status_code=404, detail="Article not found")

        article = article_response.data

        if not article.get("news_analysis"):
            raise HTTPException(status_code=404, detail="Analysis not available")

        analysis = article["news_analysis"]

        impacts_response = supabase.table("currency_impact").select("*").eq("article_id", article_id).execute()

        currency_impacts = []
        for impact in impacts_response.data:
            currency_impacts.append(CurrencyImpact(
                currency_code=impact["currency_code"],
                positive_percent=impact["positive_percent"],
                negative_percent=impact["negative_percent"],
                neutral_percent=impact["neutral_percent"],
                overall_sentiment=impact["overall_sentiment"]
            ))

        historical_response = supabase.table("historical_analysis").select("*").eq("article_id", article_id).order("date").execute()

        historical_data = []
        for point in historical_response.data:
            historical_data.append(HistoricalDataPoint(
                date=point["date"],
                currency_code=point["currency_code"],
                impact_value=point["impact_value"],
                event_description=point["event_description"]
            ))

        published_at = datetime.fromisoformat(article["published_at"].replace('Z', '+00:00'))

        news_detail = NewsDetail(
            id=article["id"],
            title=article["title"],
            image_url=article.get("image_url"),
            source_name=article["news_sources"]["name"],
            source_url=article["url"],
            published_at=published_at,
            time_ago=calculate_time_ago(published_at),
            economic_category=article["economic_category"],
            ai_summary=analysis["ai_summary"],
            key_points=analysis["key_points"],
            trader_conclusion=analysis["trader_conclusion"],
            currency_impacts=currency_impacts,
            affected_currencies=article["affected_currencies"],
            historical_data=historical_data
        )

        return news_detail

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching news detail: {e}")
        raise HTTPException(status_code=500, detail="Error fetching news detail")

@router.get("/currencies", response_model=List[str])
async def get_supported_currencies():
    return settings.SUPPORTED_CURRENCIES

@router.get("/categories", response_model=List[str])
async def get_economic_categories():
    return settings.ECONOMIC_CATEGORIES
