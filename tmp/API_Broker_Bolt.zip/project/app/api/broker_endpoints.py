from fastapi import APIRouter, Depends, HTTPException, status
from typing import List
from app.services.broker_service import broker_service
from app.schemas.broker_schemas import (
    BrokerResponse, BrokerConnectionCreate, BrokerConnectionResponse,
    BrokerConnectionUpdate
)


router = APIRouter(prefix="/brokers", tags=["brokers"])


def get_current_user_id():
    return "user-placeholder-id"


@router.get("", response_model=List[BrokerResponse])
async def get_brokers():
    try:
        brokers = await broker_service.get_all_brokers()
        return [BrokerResponse(**broker) for broker in brokers]
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/{broker_id}", response_model=BrokerResponse)
async def get_broker(broker_id: str):
    try:
        broker = await broker_service.get_broker(broker_id)

        if not broker:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Broker not found"
            )

        return BrokerResponse(**broker)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.post("/connections", response_model=BrokerConnectionResponse, status_code=status.HTTP_201_CREATED)
async def create_connection(
    connection_data: BrokerConnectionCreate,
    user_id: str = Depends(get_current_user_id)
):
    try:
        connection = await broker_service.create_connection(user_id, connection_data)
        return connection
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/connections", response_model=List[BrokerConnectionResponse])
async def get_connections(user_id: str = Depends(get_current_user_id)):
    try:
        connections = await broker_service.get_user_connections(user_id)
        return connections
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/connections/{connection_id}", response_model=BrokerConnectionResponse)
async def get_connection(
    connection_id: str,
    user_id: str = Depends(get_current_user_id)
):
    try:
        connection = await broker_service.get_connection(connection_id, user_id)

        if not connection:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Connection not found"
            )

        return connection
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.put("/connections/{connection_id}", response_model=BrokerConnectionResponse)
async def update_connection(
    connection_id: str,
    updates: BrokerConnectionUpdate,
    user_id: str = Depends(get_current_user_id)
):
    try:
        connection = await broker_service.update_connection(connection_id, user_id, updates)
        return connection
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.delete("/connections/{connection_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_connection(
    connection_id: str,
    user_id: str = Depends(get_current_user_id)
):
    try:
        success = await broker_service.delete_connection(connection_id, user_id)

        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Connection not found"
            )

        return None
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.post("/connections/{connection_id}/test")
async def test_connection(
    connection_id: str,
    user_id: str = Depends(get_current_user_id)
):
    try:
        result = await broker_service.test_connection(connection_id, user_id)
        return result
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )
