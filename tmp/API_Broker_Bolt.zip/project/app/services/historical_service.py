from datetime import datetime, timezone, timedelta
from dateutil.relativedelta import relativedelta
from typing import Dict, List
from loguru import logger
from app.db.supabase_client import get_supabase
import random

class HistoricalDataService:
    def __init__(self):
        self.supabase = get_supabase()

    def generate_historical_data(self, article_id: str, affected_currencies: List[str], category: str) -> Dict:
        try:
            for currency in affected_currencies:
                historical_points = self.generate_data_points(currency, category)

                for point in historical_points:
                    data = {
                        "article_id": article_id,
                        "currency_code": currency,
                        "date": point["date"],
                        "impact_value": point["impact_value"],
                        "event_description": point["event_description"]
                    }

                    existing = self.supabase.table("historical_analysis").select("id").eq("article_id", article_id).eq("currency_code", currency).eq("date", point["date"]).execute()

                    if not existing.data:
                        self.supabase.table("historical_analysis").insert(data).execute()

            logger.info(f"Generated historical data for article: {article_id}")

            return {
                "status": "success",
                "currencies_processed": len(affected_currencies),
                "data_points_per_currency": 12
            }

        except Exception as e:
            logger.error(f"Error generating historical data: {e}")
            raise

    def generate_data_points(self, currency: str, category: str) -> List[Dict]:
        points = []
        now = datetime.now(timezone.utc)

        events = self.get_event_templates(currency, category)

        for i in range(12):
            month_date = now - relativedelta(months=11 - i)
            date_str = month_date.strftime("%Y-%m")

            event = random.choice(events)
            impact_value = round(random.uniform(-3.0, 3.0), 1)

            points.append({
                "date": date_str,
                "impact_value": impact_value,
                "event_description": event
            })

        return points

    def get_event_templates(self, currency: str, category: str) -> List[str]:
        general_events = [
            f"{category} data release",
            f"Central bank policy decision",
            f"Economic indicators update",
            f"Market sentiment shift",
            f"Geopolitical developments",
            f"Inflation report",
            f"Employment data",
            f"GDP announcement",
            f"Trade balance report",
            f"Manufacturing data"
        ]

        currency_specific = {
            "USD": [
                "Fed rate decision",
                "US jobs report",
                "FOMC meeting",
                "US inflation data",
                "Treasury yields shift"
            ],
            "EUR": [
                "ECB policy announcement",
                "Eurozone GDP data",
                "German manufacturing PMI",
                "ECB rate decision",
                "European inflation report"
            ],
            "GBP": [
                "BoE rate decision",
                "UK employment data",
                "Brexit developments",
                "UK inflation report",
                "Bank of England policy update"
            ],
            "JPY": [
                "BoJ policy meeting",
                "Japan inflation data",
                "Japanese GDP report",
                "BoJ yield curve control",
                "Japan trade balance"
            ],
            "AUD": [
                "RBA rate decision",
                "Australian employment data",
                "Commodity price movement",
                "China economic data",
                "Australian GDP report"
            ],
            "CAD": [
                "BoC rate decision",
                "Canadian employment report",
                "Oil price volatility",
                "Canadian inflation data",
                "Trade data release"
            ],
            "CHF": [
                "SNB policy decision",
                "Swiss inflation data",
                "Safe haven flows",
                "Swiss GDP report",
                "SNB intervention speculation"
            ],
            "NZD": [
                "RBNZ rate decision",
                "New Zealand employment data",
                "Dairy prices movement",
                "New Zealand GDP",
                "Agricultural export data"
            ]
        }

        specific_events = currency_specific.get(currency, [])
        return general_events + specific_events

    def generate_for_all_analyzed(self) -> Dict:
        try:
            response = self.supabase.table("news_articles").select("id, affected_currencies, economic_category").not_.is_("analysis_id", "null").execute()

            articles = response.data
            processed = 0

            for article in articles:
                try:
                    existing = self.supabase.table("historical_analysis").select("id").eq("article_id", article["id"]).limit(1).execute()

                    if not existing.data:
                        self.generate_historical_data(
                            article["id"],
                            article["affected_currencies"],
                            article["economic_category"]
                        )
                        processed += 1
                except Exception as e:
                    logger.error(f"Error processing article {article['id']}: {e}")
                    continue

            logger.info(f"Historical data generation completed. Processed: {processed}")

            return {
                "status": "success",
                "articles_processed": processed,
                "total_articles": len(articles)
            }

        except Exception as e:
            logger.error(f"Error in generate_for_all_analyzed: {e}")
            raise
