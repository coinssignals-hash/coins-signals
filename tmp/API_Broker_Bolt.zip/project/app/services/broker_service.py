from typing import List, Dict, Any, Optional
from datetime import datetime
import uuid
from app.db.supabase_client import get_supabase_client
from app.services.encryption_service import encryption_service
from app.brokers.broker_factory import BrokerFactory
from app.brokers.base_adapter import BrokerAdapter
from app.schemas.broker_schemas import (
    BrokerConnectionCreate, BrokerConnectionResponse, BrokerConnectionUpdate,
    OrderCreate, OrderResponse, OrderUpdate, PositionResponse,
    AccountSnapshot, MarketQuote, TradeResponse
)


class BrokerService:
    def __init__(self):
        self.supabase = get_supabase_client()

    async def get_all_brokers(self) -> List[Dict[str, Any]]:
        response = self.supabase.table('brokers').select('*').eq('is_active', True).execute()
        return response.data

    async def get_broker(self, broker_id: str) -> Optional[Dict[str, Any]]:
        response = self.supabase.table('brokers').select('*').eq('id', broker_id).maybeSingle().execute()
        return response.data

    async def create_connection(
        self,
        user_id: str,
        connection_data: BrokerConnectionCreate
    ) -> BrokerConnectionResponse:
        broker = await self.get_broker(connection_data.broker_id)
        if not broker:
            raise ValueError(f"Broker not found: {connection_data.broker_id}")

        encrypted_credentials = encryption_service.encrypt_credentials(connection_data.credentials)

        connection_record = {
            'user_id': user_id,
            'broker_id': connection_data.broker_id,
            'connection_name': connection_data.connection_name,
            'environment': connection_data.environment.value,
            'encrypted_credentials': encrypted_credentials,
            'config': connection_data.config,
            'is_active': True,
            'is_connected': False
        }

        try:
            adapter = await self._create_adapter_from_data(
                broker['code'],
                connection_data.credentials,
                connection_data.environment.value
            )
            test_result = await adapter.test_connection()

            if test_result.get('success'):
                connection_record['is_connected'] = True
                connection_record['last_connected_at'] = datetime.now().isoformat()
            else:
                connection_record['connection_error'] = test_result.get('message')

        except Exception as e:
            connection_record['connection_error'] = str(e)

        response = self.supabase.table('user_broker_connections').insert(connection_record).execute()

        if response.data and len(response.data) > 0:
            created_connection = response.data[0]
            return BrokerConnectionResponse(**created_connection, broker=broker)

        raise Exception("Failed to create broker connection")

    async def get_user_connections(self, user_id: str) -> List[BrokerConnectionResponse]:
        response = self.supabase.table('user_broker_connections')\
            .select('*, brokers(*)')\
            .eq('user_id', user_id)\
            .execute()

        connections = []
        for conn in response.data:
            broker_data = conn.pop('brokers', None)
            connections.append(BrokerConnectionResponse(**conn, broker=broker_data))

        return connections

    async def get_connection(self, connection_id: str, user_id: str) -> Optional[BrokerConnectionResponse]:
        response = self.supabase.table('user_broker_connections')\
            .select('*, brokers(*)')\
            .eq('id', connection_id)\
            .eq('user_id', user_id)\
            .maybeSingle()\
            .execute()

        if response.data:
            broker_data = response.data.pop('brokers', None)
            return BrokerConnectionResponse(**response.data, broker=broker_data)

        return None

    async def update_connection(
        self,
        connection_id: str,
        user_id: str,
        updates: BrokerConnectionUpdate
    ) -> BrokerConnectionResponse:
        update_data = {}

        if updates.connection_name:
            update_data['connection_name'] = updates.connection_name

        if updates.credentials:
            encrypted_credentials = encryption_service.encrypt_credentials(updates.credentials)
            update_data['encrypted_credentials'] = encrypted_credentials

        if updates.config:
            update_data['config'] = updates.config

        if updates.is_active is not None:
            update_data['is_active'] = updates.is_active

        response = self.supabase.table('user_broker_connections')\
            .update(update_data)\
            .eq('id', connection_id)\
            .eq('user_id', user_id)\
            .execute()

        if response.data and len(response.data) > 0:
            return await self.get_connection(connection_id, user_id)

        raise Exception("Failed to update connection")

    async def delete_connection(self, connection_id: str, user_id: str) -> bool:
        response = self.supabase.table('user_broker_connections')\
            .delete()\
            .eq('id', connection_id)\
            .eq('user_id', user_id)\
            .execute()

        return len(response.data) > 0

    async def test_connection(self, connection_id: str, user_id: str) -> Dict[str, Any]:
        connection = await self.get_connection(connection_id, user_id)

        if not connection:
            return {"success": False, "message": "Connection not found"}

        try:
            adapter = await self._create_adapter_from_connection(connection)
            result = await adapter.test_connection()

            update_data = {
                'is_connected': result.get('success', False),
                'last_connected_at': datetime.now().isoformat() if result.get('success') else None,
                'connection_error': result.get('message') if not result.get('success') else None
            }

            self.supabase.table('user_broker_connections')\
                .update(update_data)\
                .eq('id', connection_id)\
                .execute()

            return result

        except Exception as e:
            return {"success": False, "message": str(e)}

    async def _create_adapter_from_connection(self, connection: BrokerConnectionResponse) -> BrokerAdapter:
        if not connection.broker:
            broker = await self.get_broker(connection.broker_id)
            broker_code = broker['code']
        else:
            broker_code = connection.broker.get('code')

        conn_data = self.supabase.table('user_broker_connections')\
            .select('encrypted_credentials')\
            .eq('id', connection.id)\
            .maybeSingle()\
            .execute()

        if not conn_data.data:
            raise ValueError("Connection not found")

        encrypted_credentials = conn_data.data['encrypted_credentials']
        decrypted_credentials = encryption_service.decrypt_credentials(encrypted_credentials)

        return await self._create_adapter_from_data(
            broker_code,
            decrypted_credentials,
            connection.environment.value
        )

    async def _create_adapter_from_data(
        self,
        broker_code: str,
        credentials: Dict[str, Any],
        environment: str
    ) -> BrokerAdapter:
        return BrokerFactory.create_adapter(broker_code, credentials, environment)


broker_service = BrokerService()
