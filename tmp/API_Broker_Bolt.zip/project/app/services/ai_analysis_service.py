from openai import OpenAI
from typing import Dict, List
from loguru import logger
from app.db.supabase_client import get_supabase
from app.core.config import settings
import json
import random

class AIAnalysisService:
    def __init__(self):
        self.supabase = get_supabase()
        self.client = OpenAI(api_key=settings.OPENAI_API_KEY)

    def analyze_all_pending(self) -> Dict:
        try:
            response = self.supabase.table("news_articles").select("*").eq("is_relevant", True).is_("analysis_id", "null").limit(10).execute()

            articles = response.data
            analyzed_count = 0

            for article in articles:
                try:
                    logger.info(f"Analyzing article: {article['title'][:50]}...")
                    analysis = self.analyze_article(article)

                    if analysis:
                        self.save_analysis(article, analysis)
                        analyzed_count += 1
                except Exception as e:
                    logger.error(f"Error analyzing article {article['id']}: {e}")
                    continue

            logger.info(f"Analysis completed. Analyzed: {analyzed_count}")

            return {
                "analyzed": analyzed_count,
                "pending": len(articles) - analyzed_count
            }

        except Exception as e:
            logger.error(f"Error in analyze_all_pending: {e}")
            raise

    def analyze_article(self, article: Dict) -> Dict:
        try:
            prompt = f"""
Eres un analista financiero experto especializado en forex y trading de divisas.

Analiza la siguiente noticia económica y proporciona:

1. Un resumen detallado (200-300 palabras) explicando el contexto, implicaciones y cómo afecta a los mercados forex.

2. 5-6 puntos clave (key points) que un trader debe saber, cada uno en una frase concisa.

3. Una conclusión para traders (trader_conclusion) de 150-200 palabras que incluya:
   - Sesgo de mercado claro (bullish/bearish/neutral)
   - Estrategias recomendadas
   - Niveles técnicos sugeridos si aplica
   - Advertencias de riesgo relevantes

4. Impacto en cada divisa afectada con porcentajes (positive_percent, negative_percent, neutral_percent que sumen 100%) y sentimiento general (bullish/bearish/neutral).

NOTICIA:
Título: {article['title']}
Contenido: {article['content']}
Divisas afectadas: {', '.join(article['affected_currencies'])}
Categoría: {article['economic_category']}

Responde SOLO con un JSON válido en este formato exacto:
{{
  "ai_summary": "texto del resumen",
  "key_points": ["punto 1", "punto 2", "punto 3", "punto 4", "punto 5"],
  "trader_conclusion": "texto de la conclusión",
  "currency_impacts": [
    {{
      "currency_code": "EUR",
      "positive_percent": 75.0,
      "negative_percent": 15.0,
      "neutral_percent": 10.0,
      "overall_sentiment": "bullish"
    }}
  ]
}}
"""

            response = self.client.chat.completions.create(
                model=settings.OPENAI_MODEL,
                messages=[
                    {"role": "system", "content": "Eres un analista financiero experto en forex. Respondes siempre en español con análisis profesionales y concisos. Solo devuelves JSON válido."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=2000
            )

            content = response.choices[0].message.content.strip()

            if content.startswith("```json"):
                content = content[7:]
            if content.startswith("```"):
                content = content[3:]
            if content.endswith("```"):
                content = content[:-3]

            content = content.strip()

            analysis = json.loads(content)

            return analysis

        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error: {e}")
            logger.error(f"Content received: {content[:500]}")
            return self.generate_fallback_analysis(article)
        except Exception as e:
            logger.error(f"Error in analyze_article: {e}")
            return self.generate_fallback_analysis(article)

    def generate_fallback_analysis(self, article: Dict) -> Dict:
        logger.warning("Using fallback analysis due to API error")

        sentiments = ["bullish", "bearish", "neutral"]
        primary_sentiment = random.choice(sentiments)

        currency_impacts = []
        for currency in article['affected_currencies']:
            if primary_sentiment == "bullish":
                positive = random.randint(60, 85)
                negative = random.randint(5, 20)
                neutral = 100 - positive - negative
            elif primary_sentiment == "bearish":
                positive = random.randint(5, 20)
                negative = random.randint(60, 85)
                neutral = 100 - positive - negative
            else:
                positive = random.randint(30, 40)
                negative = random.randint(30, 40)
                neutral = 100 - positive - negative

            currency_impacts.append({
                "currency_code": currency,
                "positive_percent": float(positive),
                "negative_percent": float(negative),
                "neutral_percent": float(neutral),
                "overall_sentiment": primary_sentiment
            })

        return {
            "ai_summary": f"Análisis de la noticia: {article['title']}. Esta noticia tiene implicaciones importantes para los mercados forex, particularmente para las divisas {', '.join(article['affected_currencies'])}. Los traders deben prestar atención a los desarrollos relacionados con {article['economic_category']}.",
            "key_points": [
                f"La noticia afecta principalmente a {', '.join(article['affected_currencies'])}",
                f"Categoría económica: {article['economic_category']}",
                f"Sentimiento de mercado: {primary_sentiment}",
                "Se recomienda monitorear desarrollos adicionales",
                "Mantener gestión de riesgo apropiada"
            ],
            "trader_conclusion": f"Esta noticia presenta un sesgo {primary_sentiment} para las divisas mencionadas. Los traders deben considerar posiciones acordes al sentimiento del mercado y mantener stops apropiados. Es importante monitorear noticias relacionadas que puedan confirmar o revertir esta tendencia.",
            "currency_impacts": currency_impacts
        }

    def save_analysis(self, article: Dict, analysis: Dict):
        try:
            analysis_data = {
                "article_id": article["id"],
                "ai_summary": analysis["ai_summary"],
                "key_points": analysis["key_points"],
                "trader_conclusion": analysis["trader_conclusion"]
            }

            analysis_response = self.supabase.table("news_analysis").insert(analysis_data).execute()
            analysis_id = analysis_response.data[0]["id"]

            self.supabase.table("news_articles").update({
                "analysis_id": analysis_id
            }).eq("id", article["id"]).execute()

            for impact in analysis["currency_impacts"]:
                impact_data = {
                    "article_id": article["id"],
                    "currency_code": impact["currency_code"],
                    "positive_percent": impact["positive_percent"],
                    "negative_percent": impact["negative_percent"],
                    "neutral_percent": impact["neutral_percent"],
                    "overall_sentiment": impact["overall_sentiment"]
                }
                self.supabase.table("currency_impact").insert(impact_data).execute()

            logger.info(f"Saved analysis for article: {article['title'][:50]}...")

        except Exception as e:
            logger.error(f"Error saving analysis: {e}")
            raise
