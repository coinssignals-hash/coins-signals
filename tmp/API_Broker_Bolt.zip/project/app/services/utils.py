from datetime import datetime, timezone
from dateutil.relativedelta import relativedelta
import pytz

def calculate_time_ago(published_at: datetime) -> str:
    if published_at.tzinfo is None:
        published_at = published_at.replace(tzinfo=timezone.utc)

    now = datetime.now(timezone.utc)
    diff = now - published_at

    seconds = diff.total_seconds()

    if seconds < 60:
        return "just now"
    elif seconds < 3600:
        minutes = int(seconds / 60)
        return f"{minutes} minute{'s' if minutes != 1 else ''} ago"
    elif seconds < 86400:
        hours = int(seconds / 3600)
        return f"{hours} hour{'s' if hours != 1 else ''} ago"
    elif seconds < 604800:
        days = int(seconds / 86400)
        return f"{days} day{'s' if days != 1 else ''} ago"
    elif seconds < 2592000:
        weeks = int(seconds / 604800)
        return f"{weeks} week{'s' if weeks != 1 else ''} ago"
    elif seconds < 31536000:
        months = int(seconds / 2592000)
        return f"{months} month{'s' if months != 1 else ''} ago"
    else:
        years = int(seconds / 31536000)
        return f"{years} year{'s' if years != 1 else ''} ago"

def is_forex_relevant(title: str, content: str, currencies: list) -> bool:
    forex_keywords = [
        "central bank", "interest rate", "inflation", "gdp", "employment",
        "unemployment", "trade balance", "retail sales", "consumer confidence",
        "manufacturing", "pmi", "monetary policy", "fiscal policy", "forex",
        "currency", "exchange rate", "dollar", "euro", "pound", "yen",
        "federal reserve", "fed", "ecb", "boe", "boj", "rba", "boc",
        "economic growth", "recession", "stimulus", "quantitative easing"
    ]

    text = (title + " " + content).lower()

    for keyword in forex_keywords:
        if keyword in text:
            return True

    for currency in currencies:
        if currency.lower() in text:
            return True

    return False

def extract_affected_currencies(title: str, content: str, all_currencies: list) -> list:
    text = (title + " " + content).lower()
    found_currencies = []

    currency_keywords = {
        "USD": ["dollar", "usd", "us dollar", "fed", "federal reserve"],
        "EUR": ["euro", "eur", "eurozone", "ecb", "european central bank"],
        "GBP": ["pound", "gbp", "sterling", "boe", "bank of england"],
        "JPY": ["yen", "jpy", "japan", "boj", "bank of japan"],
        "AUD": ["aussie", "aud", "australian dollar", "rba", "reserve bank of australia"],
        "CAD": ["loonie", "cad", "canadian dollar", "boc", "bank of canada"],
        "CHF": ["franc", "chf", "swiss franc", "snb", "swiss national bank"],
        "NZD": ["kiwi", "nzd", "new zealand dollar", "rbnz"]
    }

    for currency, keywords in currency_keywords.items():
        if currency in all_currencies:
            for keyword in keywords:
                if keyword in text:
                    if currency not in found_currencies:
                        found_currencies.append(currency)
                    break

    if not found_currencies:
        found_currencies = ["USD", "EUR"]

    return found_currencies

def categorize_news(title: str, content: str) -> str:
    text = (title + " " + content).lower()

    categories = {
        "Interest Rates": ["interest rate", "rate hike", "rate cut", "monetary policy", "policy rate"],
        "Employment": ["employment", "unemployment", "jobs", "payroll", "labor market", "jobless"],
        "GDP": ["gdp", "gross domestic product", "economic growth", "growth rate"],
        "Inflation": ["inflation", "cpi", "consumer price", "ppi", "producer price", "deflation"],
        "Trade Balance": ["trade balance", "exports", "imports", "trade deficit", "trade surplus"],
        "Central Bank Policy": ["central bank", "fed", "ecb", "boe", "boj", "rba", "boc", "monetary policy"],
        "Consumer Confidence": ["consumer confidence", "consumer sentiment", "spending"],
        "Manufacturing Data": ["manufacturing", "pmi", "industrial production", "factory orders"],
        "Retail Sales": ["retail sales", "consumer spending", "sales data"],
        "Housing Market": ["housing", "home sales", "real estate", "mortgage"]
    }

    for category, keywords in categories.items():
        for keyword in keywords:
            if keyword in text:
                return category

    return "Central Bank Policy"
