from typing import List, Optional
from datetime import datetime
import uuid
import asyncio
from app.db.supabase_client import get_supabase_client
from app.services.broker_service import broker_service
from app.schemas.broker_schemas import (
    OrderCreate, OrderResponse, OrderUpdate, MultiOrderCreate, MultiOrderResponse,
    PositionResponse, AccountSnapshot, MarketQuote, TradeResponse
)


class TradingService:
    def __init__(self):
        self.supabase = get_supabase_client()

    async def place_order(self, user_id: str, order: OrderCreate) -> OrderResponse:
        connection = await broker_service.get_connection(order.connection_id, user_id)

        if not connection:
            raise ValueError("Connection not found")

        if not connection.is_active:
            raise ValueError("Connection is not active")

        adapter = await broker_service._create_adapter_from_connection(connection)

        try:
            await adapter.connect()

            client_order_id = str(uuid.uuid4())
            order_response = await adapter.place_order(order)

            order_record = {
                'user_id': user_id,
                'connection_id': order.connection_id,
                'broker_order_id': order_response.broker_order_id,
                'client_order_id': client_order_id,
                'symbol': order.symbol,
                'asset_type': order.asset_type.value,
                'side': order.side.value,
                'order_type': order.order_type.value,
                'time_in_force': order.time_in_force.value,
                'quantity': order.quantity,
                'filled_quantity': order_response.filled_quantity,
                'limit_price': order.limit_price,
                'stop_price': order.stop_price,
                'trailing_percent': order.trailing_percent,
                'trailing_amount': order.trailing_amount,
                'stop_loss_price': order.stop_loss_price,
                'take_profit_price': order.take_profit_price,
                'average_fill_price': order_response.average_fill_price,
                'status': order_response.status.value,
                'submitted_at': datetime.now().isoformat(),
                'metadata': order_response.metadata
            }

            db_response = self.supabase.table('orders').insert(order_record).execute()

            if db_response.data and len(db_response.data) > 0:
                saved_order = db_response.data[0]
                return OrderResponse(**saved_order)

            return order_response

        except Exception as e:
            await self._log_audit(user_id, 'order_placed', 'order', None, False, str(e))
            raise Exception(f"Failed to place order: {str(e)}")
        finally:
            await adapter.disconnect()

    async def place_multi_broker_orders(
        self,
        user_id: str,
        multi_order: MultiOrderCreate
    ) -> MultiOrderResponse:
        tasks = []
        for connection_id in multi_order.connection_ids:
            order = OrderCreate(
                connection_id=connection_id,
                symbol=multi_order.symbol,
                asset_type=multi_order.asset_type,
                side=multi_order.side,
                order_type=multi_order.order_type,
                quantity=multi_order.quantity,
                time_in_force=multi_order.time_in_force,
                limit_price=multi_order.limit_price,
                stop_price=multi_order.stop_price,
                stop_loss_price=multi_order.stop_loss_price,
                take_profit_price=multi_order.take_profit_price
            )
            tasks.append(self._place_order_safe(user_id, order))

        results = await asyncio.gather(*tasks, return_exceptions=True)

        successful = []
        failed = []

        for i, result in enumerate(results):
            if isinstance(result, Exception):
                failed.append({
                    'connection_id': multi_order.connection_ids[i],
                    'error': str(result)
                })
            else:
                successful.append(result)

        return MultiOrderResponse(
            total_submitted=len(multi_order.connection_ids),
            successful=successful,
            failed=failed
        )

    async def _place_order_safe(self, user_id: str, order: OrderCreate) -> OrderResponse:
        try:
            return await self.place_order(user_id, order)
        except Exception as e:
            raise e

    async def modify_order(
        self,
        user_id: str,
        order_id: str,
        updates: OrderUpdate
    ) -> OrderResponse:
        order_data = self.supabase.table('orders')\
            .select('*, user_broker_connections(*)').eq('id', order_id)\
            .eq('user_id', user_id)\
            .maybeSingle()\
            .execute()

        if not order_data.data:
            raise ValueError("Order not found")

        order = order_data.data
        connection = order['user_broker_connections']

        connection_response = await broker_service.get_connection(connection['id'], user_id)
        adapter = await broker_service._create_adapter_from_connection(connection_response)

        try:
            await adapter.connect()

            broker_order_id = order['broker_order_id']
            updated_order = await adapter.modify_order(broker_order_id, updates)

            update_data = {
                'quantity': updates.quantity if updates.quantity else order['quantity'],
                'limit_price': updates.limit_price if updates.limit_price else order['limit_price'],
                'stop_price': updates.stop_price if updates.stop_price else order['stop_price'],
                'status': updated_order.status.value,
                'average_fill_price': updated_order.average_fill_price,
                'filled_quantity': updated_order.filled_quantity,
                'updated_at': datetime.now().isoformat()
            }

            self.supabase.table('orders').update(update_data).eq('id', order_id).execute()

            await self._log_audit(user_id, 'order_modified', 'order', order_id, True, None)

            return updated_order

        except Exception as e:
            await self._log_audit(user_id, 'order_modified', 'order', order_id, False, str(e))
            raise Exception(f"Failed to modify order: {str(e)}")
        finally:
            await adapter.disconnect()

    async def cancel_order(self, user_id: str, order_id: str) -> bool:
        order_data = self.supabase.table('orders')\
            .select('*, user_broker_connections(*)')\
            .eq('id', order_id)\
            .eq('user_id', user_id)\
            .maybeSingle()\
            .execute()

        if not order_data.data:
            raise ValueError("Order not found")

        order = order_data.data
        connection = order['user_broker_connections']

        connection_response = await broker_service.get_connection(connection['id'], user_id)
        adapter = await broker_service._create_adapter_from_connection(connection_response)

        try:
            await adapter.connect()

            broker_order_id = order['broker_order_id']
            success = await adapter.cancel_order(broker_order_id)

            if success:
                self.supabase.table('orders').update({
                    'status': 'cancelled',
                    'cancelled_at': datetime.now().isoformat()
                }).eq('id', order_id).execute()

                await self._log_audit(user_id, 'order_cancelled', 'order', order_id, True, None)

            return success

        except Exception as e:
            await self._log_audit(user_id, 'order_cancelled', 'order', order_id, False, str(e))
            raise Exception(f"Failed to cancel order: {str(e)}")
        finally:
            await adapter.disconnect()

    async def get_orders(
        self,
        user_id: str,
        connection_id: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 100
    ) -> List[OrderResponse]:
        query = self.supabase.table('orders').select('*').eq('user_id', user_id)

        if connection_id:
            query = query.eq('connection_id', connection_id)

        if status:
            query = query.eq('status', status)

        response = query.order('created_at', desc=True).limit(limit).execute()

        return [OrderResponse(**order) for order in response.data]

    async def get_order(self, user_id: str, order_id: str) -> Optional[OrderResponse]:
        response = self.supabase.table('orders')\
            .select('*')\
            .eq('id', order_id)\
            .eq('user_id', user_id)\
            .maybeSingle()\
            .execute()

        if response.data:
            return OrderResponse(**response.data)

        return None

    async def get_positions(self, user_id: str, connection_id: str) -> List[PositionResponse]:
        connection = await broker_service.get_connection(connection_id, user_id)

        if not connection:
            raise ValueError("Connection not found")

        adapter = await broker_service._create_adapter_from_connection(connection)

        try:
            await adapter.connect()
            positions = await adapter.get_positions()

            for position in positions:
                await self._sync_position_to_db(user_id, connection_id, position)

            return positions

        except Exception as e:
            raise Exception(f"Failed to get positions: {str(e)}")
        finally:
            await adapter.disconnect()

    async def get_account(self, user_id: str, connection_id: str) -> AccountSnapshot:
        connection = await broker_service.get_connection(connection_id, user_id)

        if not connection:
            raise ValueError("Connection not found")

        adapter = await broker_service._create_adapter_from_connection(connection)

        try:
            await adapter.connect()
            account = await adapter.get_account()

            await self._save_account_snapshot(user_id, connection_id, account)

            return account

        except Exception as e:
            raise Exception(f"Failed to get account: {str(e)}")
        finally:
            await adapter.disconnect()

    async def get_quote(self, user_id: str, connection_id: str, symbol: str) -> MarketQuote:
        connection = await broker_service.get_connection(connection_id, user_id)

        if not connection:
            raise ValueError("Connection not found")

        adapter = await broker_service._create_adapter_from_connection(connection)

        try:
            await adapter.connect()
            quote = await adapter.get_quote(symbol)

            return quote

        except Exception as e:
            raise Exception(f"Failed to get quote: {str(e)}")
        finally:
            await adapter.disconnect()

    async def get_historical_data(
        self,
        user_id: str,
        connection_id: str,
        symbol: str,
        timeframe: str,
        start: datetime,
        end: Optional[datetime] = None,
        limit: Optional[int] = None
    ) -> List[dict]:
        connection = await broker_service.get_connection(connection_id, user_id)

        if not connection:
            raise ValueError("Connection not found")

        adapter = await broker_service._create_adapter_from_connection(connection)

        try:
            await adapter.connect()
            data = await adapter.get_historical_data(symbol, timeframe, start, end, limit)

            return data

        except Exception as e:
            raise Exception(f"Failed to get historical data: {str(e)}")
        finally:
            await adapter.disconnect()

    async def _sync_position_to_db(
        self,
        user_id: str,
        connection_id: str,
        position: PositionResponse
    ):
        existing = self.supabase.table('positions')\
            .select('id')\
            .eq('connection_id', connection_id)\
            .eq('symbol', position.symbol)\
            .maybeSingle()\
            .execute()

        position_data = {
            'user_id': user_id,
            'connection_id': connection_id,
            'symbol': position.symbol,
            'asset_type': position.asset_type,
            'quantity': position.quantity,
            'available_quantity': position.available_quantity,
            'average_entry_price': position.average_entry_price,
            'current_price': position.current_price,
            'last_price_update_at': position.last_price_update_at.isoformat() if position.last_price_update_at else None,
            'unrealized_pnl': position.unrealized_pnl,
            'unrealized_pnl_percent': position.unrealized_pnl_percent,
            'realized_pnl': position.realized_pnl,
            'total_cost': position.total_cost,
            'market_value': position.market_value,
            'updated_at': datetime.now().isoformat()
        }

        if existing.data:
            self.supabase.table('positions').update(position_data).eq('id', existing.data['id']).execute()
        else:
            self.supabase.table('positions').insert(position_data).execute()

    async def _save_account_snapshot(
        self,
        user_id: str,
        connection_id: str,
        snapshot: AccountSnapshot
    ):
        snapshot_data = {
            'user_id': user_id,
            'connection_id': connection_id,
            'cash_balance': snapshot.cash_balance,
            'equity': snapshot.equity,
            'portfolio_value': snapshot.portfolio_value,
            'buying_power': snapshot.buying_power,
            'margin_used': snapshot.margin_used,
            'margin_available': snapshot.margin_available,
            'unrealized_pnl': snapshot.unrealized_pnl,
            'realized_pnl_today': snapshot.realized_pnl_today,
            'realized_pnl_total': snapshot.realized_pnl_total,
            'total_positions_count': snapshot.total_positions_count,
            'total_open_orders_count': snapshot.total_open_orders_count,
            'long_exposure': snapshot.long_exposure,
            'short_exposure': snapshot.short_exposure,
            'net_exposure': snapshot.net_exposure,
            'snapshot_at': snapshot.snapshot_at.isoformat()
        }

        self.supabase.table('account_snapshots').insert(snapshot_data).execute()

    async def _log_audit(
        self,
        user_id: str,
        action: str,
        resource_type: str,
        resource_id: Optional[str],
        success: bool,
        error_message: Optional[str]
    ):
        audit_log = {
            'user_id': user_id,
            'action': action,
            'resource_type': resource_type,
            'resource_id': resource_id,
            'success': success,
            'error_message': error_message
        }

        self.supabase.table('audit_logs').insert(audit_log).execute()


trading_service = TradingService()
