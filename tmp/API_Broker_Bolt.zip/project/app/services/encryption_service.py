from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2
from cryptography.hazmat.backends import default_backend
import base64
import json
import os
from typing import Dict, Any
from app.core.config import settings


class EncryptionService:
    def __init__(self):
        self.encryption_key = self._get_or_create_encryption_key()
        self.cipher_suite = Fernet(self.encryption_key)

    def _get_or_create_encryption_key(self) -> bytes:
        if settings.ENCRYPTION_KEY:
            key = settings.ENCRYPTION_KEY.encode()
            if len(key) == 44 and key.endswith(b'='):
                return key
            kdf = PBKDF2(
                algorithm=hashes.SHA256(),
                length=32,
                salt=b'trading_broker_salt_change_this',
                iterations=100000,
                backend=default_backend()
            )
            derived_key = base64.urlsafe_b64encode(kdf.derive(key))
            return derived_key
        else:
            key = Fernet.generate_key()
            print(f"⚠️ WARNING: No ENCRYPTION_KEY found. Generated new key: {key.decode()}")
            print("⚠️ Add this to your .env file as ENCRYPTION_KEY=...")
            return key

    def encrypt_credentials(self, credentials: Dict[str, Any]) -> bytes:
        credentials_json = json.dumps(credentials)
        encrypted_data = self.cipher_suite.encrypt(credentials_json.encode())
        return encrypted_data

    def decrypt_credentials(self, encrypted_data: bytes) -> Dict[str, Any]:
        decrypted_data = self.cipher_suite.decrypt(encrypted_data)
        credentials = json.loads(decrypted_data.decode())
        return credentials

    def encrypt_string(self, value: str) -> bytes:
        return self.cipher_suite.encrypt(value.encode())

    def decrypt_string(self, encrypted_value: bytes) -> str:
        return self.cipher_suite.decrypt(encrypted_value).decode()


encryption_service = EncryptionService()
