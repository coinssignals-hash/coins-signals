import requests
from bs4 import BeautifulSoup
from datetime import datetime, timezone
from typing import List, Dict
from loguru import logger
from app.db.supabase_client import get_supabase
from app.core.config import settings
from app.services.utils import is_forex_relevant, extract_affected_currencies, categorize_news
import uuid

class NewsScraperService:
    def __init__(self):
        self.supabase = get_supabase()
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }

    def scrape_all_sources(self) -> Dict:
        try:
            response = self.supabase.table("news_sources").select("*").eq("is_active", True).execute()
            sources = response.data

            total_scraped = 0
            total_relevant = 0

            for source in sources:
                logger.info(f"Scraping source: {source['name']}")
                try:
                    articles = self.scrape_source(source)
                    total_scraped += len(articles)

                    for article in articles:
                        if self.save_article(article, source):
                            total_relevant += 1

                    self.supabase.table("news_sources").update({
                        "last_scraped_at": datetime.now(timezone.utc).isoformat()
                    }).eq("id", source["id"]).execute()

                except Exception as e:
                    logger.error(f"Error scraping {source['name']}: {e}")
                    continue

            logger.info(f"Scraping completed. Total: {total_scraped}, Relevant: {total_relevant}")

            return {
                "total_scraped": total_scraped,
                "relevant_articles": total_relevant,
                "sources_processed": len(sources)
            }

        except Exception as e:
            logger.error(f"Error in scrape_all_sources: {e}")
            raise

    def scrape_source(self, source: Dict) -> List[Dict]:
        try:
            response = requests.get(source["url"], headers=self.headers, timeout=10)
            response.raise_for_status()

            soup = BeautifulSoup(response.content, 'html.parser')
            articles = []

            article_tags = soup.find_all(['article', 'div'], class_=lambda x: x and ('article' in str(x).lower() or 'story' in str(x).lower() or 'post' in str(x).lower()), limit=20)

            for tag in article_tags:
                try:
                    article = self.extract_article_data(tag, source["url"])
                    if article:
                        articles.append(article)
                except Exception as e:
                    logger.debug(f"Error extracting article: {e}")
                    continue

            return articles

        except Exception as e:
            logger.error(f"Error scraping source {source['name']}: {e}")
            return []

    def extract_article_data(self, tag, base_url: str) -> Dict:
        title_tag = tag.find(['h1', 'h2', 'h3', 'h4'])
        if not title_tag:
            return None

        title = title_tag.get_text(strip=True)
        if not title or len(title) < 10:
            return None

        link_tag = tag.find('a', href=True)
        url = link_tag['href'] if link_tag else ""
        if url and not url.startswith('http'):
            from urllib.parse import urljoin
            url = urljoin(base_url, url)

        img_tag = tag.find('img')
        image_url = img_tag.get('src', '') or img_tag.get('data-src', '') if img_tag else None
        if image_url and not image_url.startswith('http'):
            from urllib.parse import urljoin
            image_url = urljoin(base_url, image_url)

        content_tag = tag.find(['p', 'div'], class_=lambda x: x and ('description' in str(x).lower() or 'summary' in str(x).lower() or 'excerpt' in str(x).lower()))
        content = content_tag.get_text(strip=True) if content_tag else title

        return {
            "title": title,
            "url": url,
            "image_url": image_url,
            "content": content,
            "published_at": datetime.now(timezone.utc)
        }

    def save_article(self, article: Dict, source: Dict) -> bool:
        try:
            if not is_forex_relevant(article["title"], article["content"], settings.SUPPORTED_CURRENCIES):
                return False

            existing = self.supabase.table("news_articles").select("id").eq("title", article["title"]).execute()
            if existing.data:
                return False

            affected_currencies = extract_affected_currencies(
                article["title"],
                article["content"],
                settings.SUPPORTED_CURRENCIES
            )

            economic_category = categorize_news(article["title"], article["content"])

            article_data = {
                "id": str(uuid.uuid4()),
                "source_id": source["id"],
                "title": article["title"],
                "content": article["content"],
                "url": article["url"],
                "image_url": article["image_url"],
                "published_at": article["published_at"].isoformat(),
                "is_relevant": True,
                "economic_category": economic_category,
                "affected_currencies": affected_currencies
            }

            self.supabase.table("news_articles").insert(article_data).execute()
            logger.info(f"Saved article: {article['title'][:50]}...")
            return True

        except Exception as e:
            logger.error(f"Error saving article: {e}")
            return False
