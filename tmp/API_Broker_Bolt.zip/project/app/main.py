from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from loguru import logger
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger
import sys

from app.core.config import settings
from app.api import news_endpoints, admin_endpoints, broker_endpoints, trading_endpoints
from app.services.scraper_service import NewsScraperService
from app.services.ai_analysis_service import AIAnalysisService
from app.services.historical_service import HistoricalDataService
from app.brokers import registry

logger.remove()
logger.add(
    sys.stderr,
    format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <level>{message}</level>",
    level=settings.LOG_LEVEL
)

app = FastAPI(
    title="Multi-Broker Trading API",
    description="Unified API for multi-broker trading: Alpaca, OANDA, Interactive Brokers, and more. Supports stocks, forex, crypto, options, futures, and CFDs.",
    version="2.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(news_endpoints.router)
app.include_router(admin_endpoints.router)
app.include_router(broker_endpoints.router, prefix="/api")
app.include_router(trading_endpoints.router, prefix="/api")

scheduler = BackgroundScheduler()

def scheduled_scraping_job():
    try:
        logger.info("Running scheduled scraping job")

        scraper = NewsScraperService()
        scraper.scrape_all_sources()

        ai_service = AIAnalysisService()
        ai_service.analyze_all_pending()

        historical_service = HistoricalDataService()
        historical_service.generate_for_all_analyzed()

        logger.info("Scheduled job completed successfully")

    except Exception as e:
        logger.error(f"Error in scheduled job: {e}")

@app.on_event("startup")
async def startup_event():
    logger.info("Starting Trading News API")

    try:
        scheduler.add_job(
            scheduled_scraping_job,
            trigger=IntervalTrigger(minutes=settings.SCRAPING_INTERVAL_MINUTES),
            id='scraping_job',
            name='Scrape and analyze news',
            replace_existing=True
        )
        scheduler.start()
        logger.info(f"Scheduler started successfully. Interval: {settings.SCRAPING_INTERVAL_MINUTES} minutes")
    except Exception as e:
        logger.error(f"Error starting scheduler: {e}")

@app.on_event("shutdown")
async def shutdown_event():
    logger.info("Shutting down Trading News API")
    scheduler.shutdown()

@app.get("/")
async def root():
    return {
        "message": "Trading News API",
        "version": "1.0.0",
        "docs": "/docs",
        "status": "operational"
    }

@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "scheduler": scheduler.running
    }
