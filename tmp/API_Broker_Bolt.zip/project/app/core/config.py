from pydantic_settings import BaseSettings
from typing import Optional
import os
from dotenv import load_dotenv

load_dotenv()

class Settings(BaseSettings):
    SUPABASE_URL: str = os.getenv("SUPABASE_URL", "")
    SUPABASE_KEY: str = os.getenv("SUPABASE_KEY", "")
    SUPABASE_SERVICE_ROLE_KEY: str = os.getenv("SUPABASE_SERVICE_ROLE_KEY", "")

    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    OPENAI_MODEL: str = os.getenv("OPENAI_MODEL", "gpt-4-turbo-preview")

    DATABASE_URL: Optional[str] = os.getenv("DATABASE_URL", None)

    API_HOST: str = os.getenv("API_HOST", "0.0.0.0")
    API_PORT: int = int(os.getenv("API_PORT", "8000"))
    API_RELOAD: bool = os.getenv("API_RELOAD", "true").lower() == "true"

    SCRAPING_INTERVAL_MINUTES: int = int(os.getenv("SCRAPING_INTERVAL_MINUTES", "30"))
    MAX_WORKERS: int = int(os.getenv("MAX_WORKERS", "5"))

    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")

    # Trading & Broker Configuration
    ENCRYPTION_KEY: str = os.getenv("ENCRYPTION_KEY", "")
    JWT_SECRET_KEY: str = os.getenv("JWT_SECRET_KEY", "your-secret-key-change-in-production")
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24  # 24 hours

    # Rate limiting for API
    RATE_LIMIT_PER_MINUTE: int = int(os.getenv("RATE_LIMIT_PER_MINUTE", "100"))

    SUPPORTED_CURRENCIES: list = [
        "EUR", "USD", "AUD", "CAD", "GBP", "JPY", "CHF", "NZD"
    ]

    ECONOMIC_CATEGORIES: list = [
        "Interest Rates",
        "Employment",
        "GDP",
        "Inflation",
        "Trade Balance",
        "Central Bank Policy",
        "Consumer Confidence",
        "Manufacturing Data",
        "Retail Sales",
        "Housing Market"
    ]

    class Config:
        case_sensitive = True
        env_file = ".env"

settings = Settings()
