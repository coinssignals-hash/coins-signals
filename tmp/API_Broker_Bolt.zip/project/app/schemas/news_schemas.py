from pydantic import BaseModel, HttpUrl
from typing import List, Optional
from datetime import datetime

class NewsListItem(BaseModel):
    id: str
    title: str
    image_url: Optional[str] = None
    source_name: str
    published_at: datetime
    time_ago: str
    economic_category: str
    affected_currencies: List[str]
    primary_sentiment: str

class CurrencyImpact(BaseModel):
    currency_code: str
    positive_percent: float
    negative_percent: float
    neutral_percent: float
    overall_sentiment: str

class HistoricalDataPoint(BaseModel):
    date: str
    currency_code: str
    impact_value: float
    event_description: str

class NewsDetail(BaseModel):
    id: str
    title: str
    image_url: Optional[str] = None
    source_name: str
    source_url: str
    published_at: datetime
    time_ago: str
    economic_category: str
    ai_summary: str
    key_points: List[str]
    trader_conclusion: str
    currency_impacts: List[CurrencyImpact]
    affected_currencies: List[str]
    historical_data: List[HistoricalDataPoint]

class NewsListResponse(BaseModel):
    news: List[NewsListItem]
    total: int
    page: int
    page_size: int

class NewsSource(BaseModel):
    id: Optional[str] = None
    name: str
    url: str
    is_active: bool = True
    scrape_frequency_minutes: int = 30
    last_scraped_at: Optional[datetime] = None
    created_at: Optional[datetime] = None

class AddSourceRequest(BaseModel):
    name: str
    url: str
    scrape_frequency_minutes: int = 30

class AdminResponse(BaseModel):
    status: str
    message: Optional[str] = None
    data: Optional[dict] = None
