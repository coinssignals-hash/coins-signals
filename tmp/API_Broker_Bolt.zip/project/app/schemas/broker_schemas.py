from pydantic import BaseModel, Field, validator
from typing import Optional, Dict, Any, List
from datetime import datetime
from enum import Enum


class Environment(str, Enum):
    DEMO = "demo"
    LIVE = "live"


class BrokerCode(str, Enum):
    ALPACA = "alpaca"
    OANDA = "oanda"
    INTERACTIVE_BROKERS = "interactive_brokers"
    IG_MARKETS = "ig_markets"
    FOREX_COM = "forex_com"
    FXCM = "fxcm"
    PEPPERSTONE = "pepperstone"
    SAXO_BANK = "saxo_bank"
    DUKASCOPY = "dukascopy"
    AVATRADE = "avatrade"


class AssetType(str, Enum):
    STOCK = "stock"
    ETF = "etf"
    FOREX = "forex"
    CRYPTO = "crypto"
    OPTION = "option"
    FUTURE = "future"
    CFD = "cfd"
    BOND = "bond"
    FUND = "fund"


class OrderSide(str, Enum):
    BUY = "buy"
    SELL = "sell"


class OrderType(str, Enum):
    MARKET = "market"
    LIMIT = "limit"
    STOP = "stop"
    STOP_LIMIT = "stop_limit"
    TRAILING_STOP = "trailing_stop"
    MARKET_IF_TOUCHED = "market_if_touched"


class TimeInForce(str, Enum):
    DAY = "day"
    GTC = "gtc"  # Good Till Cancelled
    IOC = "ioc"  # Immediate Or Cancel
    FOK = "fok"  # Fill Or Kill


class OrderStatus(str, Enum):
    PENDING = "pending"
    SUBMITTED = "submitted"
    ACCEPTED = "accepted"
    PARTIAL_FILL = "partial_fill"
    FILLED = "filled"
    CANCELLED = "cancelled"
    REJECTED = "rejected"
    EXPIRED = "expired"
    REPLACED = "replaced"


class BrokerResponse(BaseModel):
    id: str
    code: str
    display_name: str
    description: Optional[str] = None
    logo_url: Optional[str] = None
    auth_type: str
    supported_assets: List[str]
    supported_order_types: List[str]
    api_documentation_url: Optional[str] = None
    is_active: bool
    supports_websocket: bool
    created_at: datetime
    updated_at: datetime


class BrokerConnectionCreate(BaseModel):
    broker_id: str = Field(..., description="UUID of the broker")
    connection_name: str = Field(..., min_length=1, max_length=100)
    environment: Environment = Environment.DEMO
    credentials: Dict[str, Any] = Field(..., description="Broker-specific credentials")
    config: Optional[Dict[str, Any]] = Field(default_factory=dict)

    @validator('connection_name')
    def validate_connection_name(cls, v):
        if not v.strip():
            raise ValueError("Connection name cannot be empty")
        return v.strip()


class BrokerConnectionResponse(BaseModel):
    id: str
    user_id: str
    broker_id: str
    connection_name: str
    environment: Environment
    is_active: bool
    is_connected: bool
    last_connected_at: Optional[datetime] = None
    last_sync_at: Optional[datetime] = None
    connection_error: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    broker: Optional[BrokerResponse] = None


class BrokerConnectionUpdate(BaseModel):
    connection_name: Optional[str] = None
    credentials: Optional[Dict[str, Any]] = None
    config: Optional[Dict[str, Any]] = None
    is_active: Optional[bool] = None


class OrderCreate(BaseModel):
    connection_id: str = Field(..., description="UUID of broker connection")
    symbol: str = Field(..., min_length=1)
    asset_type: AssetType
    side: OrderSide
    order_type: OrderType
    quantity: float = Field(..., gt=0)
    time_in_force: TimeInForce = TimeInForce.GTC

    limit_price: Optional[float] = Field(None, gt=0)
    stop_price: Optional[float] = Field(None, gt=0)
    trailing_percent: Optional[float] = Field(None, gt=0, le=100)
    trailing_amount: Optional[float] = Field(None, gt=0)

    stop_loss_price: Optional[float] = Field(None, gt=0)
    take_profit_price: Optional[float] = Field(None, gt=0)

    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)

    @validator('limit_price')
    def validate_limit_price(cls, v, values):
        if values.get('order_type') in [OrderType.LIMIT, OrderType.STOP_LIMIT] and v is None:
            raise ValueError("limit_price is required for limit orders")
        return v

    @validator('stop_price')
    def validate_stop_price(cls, v, values):
        if values.get('order_type') in [OrderType.STOP, OrderType.STOP_LIMIT] and v is None:
            raise ValueError("stop_price is required for stop orders")
        return v


class OrderUpdate(BaseModel):
    quantity: Optional[float] = Field(None, gt=0)
    limit_price: Optional[float] = Field(None, gt=0)
    stop_price: Optional[float] = Field(None, gt=0)
    trailing_percent: Optional[float] = Field(None, gt=0, le=100)
    trailing_amount: Optional[float] = Field(None, gt=0)
    time_in_force: Optional[TimeInForce] = None


class OrderResponse(BaseModel):
    id: str
    user_id: str
    connection_id: str
    broker_order_id: Optional[str] = None
    client_order_id: str
    symbol: str
    asset_type: AssetType
    side: OrderSide
    order_type: OrderType
    time_in_force: TimeInForce
    quantity: float
    filled_quantity: float
    remaining_quantity: float
    limit_price: Optional[float] = None
    stop_price: Optional[float] = None
    trailing_percent: Optional[float] = None
    trailing_amount: Optional[float] = None
    average_fill_price: Optional[float] = None
    stop_loss_price: Optional[float] = None
    take_profit_price: Optional[float] = None
    status: OrderStatus
    submitted_at: Optional[datetime] = None
    filled_at: Optional[datetime] = None
    cancelled_at: Optional[datetime] = None
    expires_at: Optional[datetime] = None
    rejection_reason: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime
    updated_at: datetime


class PositionResponse(BaseModel):
    id: str
    user_id: str
    connection_id: str
    symbol: str
    asset_type: str
    quantity: float
    available_quantity: float
    average_entry_price: float
    current_price: Optional[float] = None
    last_price_update_at: Optional[datetime] = None
    unrealized_pnl: float
    unrealized_pnl_percent: float
    realized_pnl: float
    total_pnl: float
    total_cost: float
    market_value: Optional[float] = None
    created_at: datetime
    updated_at: datetime


class AccountSnapshot(BaseModel):
    id: str
    user_id: str
    connection_id: str
    cash_balance: float
    equity: float
    portfolio_value: float
    buying_power: float
    margin_used: float
    margin_available: float
    unrealized_pnl: float
    realized_pnl_today: float
    realized_pnl_total: float
    total_positions_count: int
    total_open_orders_count: int
    long_exposure: float
    short_exposure: float
    net_exposure: float
    snapshot_at: datetime
    created_at: datetime


class MarketQuote(BaseModel):
    symbol: str
    asset_type: str
    bid_price: Optional[float] = None
    ask_price: Optional[float] = None
    mid_price: Optional[float] = None
    last_price: Optional[float] = None
    volume: Optional[int] = None
    daily_change: Optional[float] = None
    daily_change_percent: Optional[float] = None
    quote_time: datetime


class TradeResponse(BaseModel):
    id: str
    order_id: str
    connection_id: str
    broker_trade_id: Optional[str] = None
    symbol: str
    side: OrderSide
    quantity: float
    price: float
    commission: float
    fees: float
    executed_at: datetime
    created_at: datetime


class MultiOrderCreate(BaseModel):
    connection_ids: List[str] = Field(..., min_items=1, description="List of broker connection UUIDs")
    symbol: str
    asset_type: AssetType
    side: OrderSide
    order_type: OrderType
    quantity: float = Field(..., gt=0)
    time_in_force: TimeInForce = TimeInForce.GTC
    limit_price: Optional[float] = None
    stop_price: Optional[float] = None
    stop_loss_price: Optional[float] = None
    take_profit_price: Optional[float] = None


class MultiOrderResponse(BaseModel):
    total_submitted: int
    successful: List[OrderResponse]
    failed: List[Dict[str, Any]]
