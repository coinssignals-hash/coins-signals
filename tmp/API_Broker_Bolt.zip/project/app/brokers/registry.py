from app.brokers.broker_factory import BrokerFactory
from app.brokers.alpaca_adapter import AlpacaAdapter
from app.brokers.oanda_adapter import OandaAdapter
from app.brokers.interactive_brokers_adapter import InteractiveBrokersAdapter
from app.brokers.ig_markets_adapter import IGMarketsAdapter
from app.brokers.forex_com_adapter import ForexComAdapter
from app.brokers.fxcm_adapter import FXCMAdapter
from app.brokers.pepperstone_adapter import PepperstoneAdapter


def register_all_brokers():
    BrokerFactory.register_adapter('alpaca', AlpacaAdapter)
    BrokerFactory.register_adapter('oanda', OandaAdapter)
    BrokerFactory.register_adapter('interactive_brokers', InteractiveBrokersAdapter)
    BrokerFactory.register_adapter('ig_markets', IGMarketsAdapter)
    BrokerFactory.register_adapter('forex_com', ForexComAdapter)
    BrokerFactory.register_adapter('fxcm', FXCMAdapter)
    BrokerFactory.register_adapter('pepperstone', PepperstoneAdapter)


register_all_brokers()
