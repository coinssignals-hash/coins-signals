import httpx
from typing import Dict, Any, List, Optional
from datetime import datetime
import uuid
from app.brokers.base_adapter import BrokerAdapter
from app.schemas.broker_schemas import (
    OrderCreate, OrderResponse, OrderUpdate,
    PositionResponse, AccountSnapshot, MarketQuote, TradeResponse,
    OrderStatus, OrderSide, AssetType
)


class ForexComAdapter(BrokerAdapter):
    SUPPORTED_ASSETS = ['forex', 'cfd', 'crypto']
    SUPPORTED_ORDER_TYPES = ['market', 'limit', 'stop', 'stop_limit']

    def __init__(self, credentials: Dict[str, Any], environment: str = "demo"):
        super().__init__(credentials, environment)
        self.api_token = credentials.get('api_token')
        self.account_id = credentials.get('account_id')

        if not self.api_token or not self.account_id:
            raise ValueError("api_token and account_id are required for FOREX.com")

        self.base_url = self.get_base_url()
        self.headers = {
            "Authorization": f"Bearer {self.api_token}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }

    def get_base_url(self) -> str:
        if self.environment == "live":
            return "https://api.forex.com/v3"
        return "https://api-demo.forex.com/v3"

    def get_websocket_url(self) -> str:
        if self.environment == "live":
            return "wss://stream.forex.com"
        return "wss://stream-demo.forex.com"

    def supports_asset_type(self, asset_type: str) -> bool:
        return asset_type in self.SUPPORTED_ASSETS

    def supports_order_type(self, order_type: str) -> bool:
        return order_type in self.SUPPORTED_ORDER_TYPES

    async def connect(self) -> bool:
        try:
            result = await self.test_connection()
            self.is_connected = result.get('success', False)
            return self.is_connected
        except Exception as e:
            self.is_connected = False
            raise Exception(f"Failed to connect to FOREX.com: {str(e)}")

    async def disconnect(self) -> bool:
        self.is_connected = False
        return True

    async def test_connection(self) -> Dict[str, Any]:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/accounts/{self.account_id}",
                    headers=self.headers,
                    timeout=10.0
                )
                response.raise_for_status()
                return {
                    "success": True,
                    "message": "Connection successful",
                    "account_id": self.account_id
                }
            except httpx.HTTPStatusError as e:
                return {
                    "success": False,
                    "message": f"HTTP error: {e.response.status_code}",
                    "details": e.response.text
                }
            except Exception as e:
                return {
                    "success": False,
                    "message": str(e)
                }

    async def place_order(self, order: OrderCreate) -> OrderResponse:
        self._validate_order(order)

        forex_order = {
            "order": {
                "instrument": order.symbol.replace('/', '_'),
                "units": str(int(order.quantity)) if order.side == OrderSide.BUY else str(-int(order.quantity)),
                "type": self._map_order_type_to_forex(order.order_type),
                "timeInForce": self._map_time_in_force(order.time_in_force)
            }
        }

        if order.limit_price:
            forex_order["order"]["price"] = str(order.limit_price)

        if order.stop_price:
            forex_order["order"]["priceBound"] = str(order.stop_price)

        if order.take_profit_price:
            forex_order["order"]["takeProfitOnFill"] = {
                "price": str(order.take_profit_price)
            }

        if order.stop_loss_price:
            forex_order["order"]["stopLossOnFill"] = {
                "price": str(order.stop_loss_price)
            }

        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    f"{self.base_url}/accounts/{self.account_id}/orders",
                    headers=self.headers,
                    json=forex_order,
                    timeout=30.0
                )
                response.raise_for_status()
                forex_response = response.json()

                order_info = forex_response.get('orderCreateTransaction', {})
                fill_info = forex_response.get('orderFillTransaction', {})

                return self._map_forex_order_to_response(order_info, fill_info, order)

            except httpx.HTTPStatusError as e:
                error_detail = e.response.json() if e.response.content else {}
                raise Exception(f"FOREX.com order failed: {error_detail.get('errorMessage', str(e))}")
            except Exception as e:
                raise Exception(f"Error placing order: {str(e)}")

    async def modify_order(self, broker_order_id: str, updates: OrderUpdate) -> OrderResponse:
        forex_updates = {}

        if updates.limit_price:
            forex_updates["price"] = str(updates.limit_price)
        if updates.stop_price:
            forex_updates["priceBound"] = str(updates.stop_price)

        async with httpx.AsyncClient() as client:
            try:
                response = await client.put(
                    f"{self.base_url}/accounts/{self.account_id}/orders/{broker_order_id}",
                    headers=self.headers,
                    json={"order": forex_updates},
                    timeout=30.0
                )
                response.raise_for_status()

                return await self.get_order(broker_order_id)

            except httpx.HTTPStatusError as e:
                error_detail = e.response.json() if e.response.content else {}
                raise Exception(f"Order modification failed: {error_detail.get('errorMessage', str(e))}")

    async def cancel_order(self, broker_order_id: str) -> bool:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.put(
                    f"{self.base_url}/accounts/{self.account_id}/orders/{broker_order_id}/cancel",
                    headers=self.headers,
                    timeout=30.0
                )
                response.raise_for_status()
                return True
            except Exception as e:
                raise Exception(f"Order cancellation failed: {str(e)}")

    async def get_order(self, broker_order_id: str) -> OrderResponse:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/accounts/{self.account_id}/orders/{broker_order_id}",
                    headers=self.headers,
                    timeout=10.0
                )
                response.raise_for_status()
                forex_order = response.json().get('order', {})
                return self._map_forex_order_to_response(forex_order, {})
            except Exception as e:
                raise Exception(f"Failed to get order: {str(e)}")

    async def get_orders(
        self,
        status: Optional[str] = None,
        limit: int = 100,
        after: Optional[datetime] = None
    ) -> List[OrderResponse]:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/accounts/{self.account_id}/orders",
                    headers=self.headers,
                    params={"count": min(limit, 500)},
                    timeout=10.0
                )
                response.raise_for_status()
                forex_orders = response.json().get('orders', [])

                return [self._map_forex_order_to_response(order, {}) for order in forex_orders]

            except Exception as e:
                raise Exception(f"Failed to get orders: {str(e)}")

    async def get_positions(self) -> List[PositionResponse]:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/accounts/{self.account_id}/positions",
                    headers=self.headers,
                    timeout=10.0
                )
                response.raise_for_status()
                forex_positions = response.json().get('positions', [])

                positions = []
                for pos in forex_positions:
                    long_units = float(pos.get('long', {}).get('units', 0))
                    short_units = float(pos.get('short', {}).get('units', 0))

                    if long_units != 0 or short_units != 0:
                        positions.append(self._map_forex_position_to_response(pos))

                return positions

            except Exception as e:
                raise Exception(f"Failed to get positions: {str(e)}")

    async def get_position(self, symbol: str) -> Optional[PositionResponse]:
        instrument = symbol.replace('/', '_')

        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/accounts/{self.account_id}/positions/{instrument}",
                    headers=self.headers,
                    timeout=10.0
                )
                response.raise_for_status()
                forex_position = response.json().get('position', {})

                return self._map_forex_position_to_response(forex_position)

            except httpx.HTTPStatusError as e:
                if e.response.status_code == 404:
                    return None
                raise Exception(f"Failed to get position: {str(e)}")

    async def close_position(self, symbol: str, quantity: Optional[float] = None) -> OrderResponse:
        instrument = symbol.replace('/', '_')

        body = {}
        if quantity:
            body["longUnits"] = str(int(quantity))
        else:
            body["longUnits"] = "ALL"

        async with httpx.AsyncClient() as client:
            try:
                response = await client.put(
                    f"{self.base_url}/accounts/{self.account_id}/positions/{instrument}/close",
                    headers=self.headers,
                    json=body,
                    timeout=30.0
                )
                response.raise_for_status()
                forex_response = response.json()

                close_transaction = forex_response.get('longOrderFillTransaction', {}) or \
                                    forex_response.get('shortOrderFillTransaction', {})

                return self._map_forex_order_to_response(close_transaction, close_transaction)

            except Exception as e:
                raise Exception(f"Failed to close position: {str(e)}")

    async def get_account(self) -> AccountSnapshot:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/accounts/{self.account_id}",
                    headers=self.headers,
                    timeout=10.0
                )
                response.raise_for_status()
                forex_account = response.json().get('account', {})

                return self._map_forex_account_to_snapshot(forex_account)

            except Exception as e:
                raise Exception(f"Failed to get account: {str(e)}")

    async def get_quote(self, symbol: str) -> MarketQuote:
        instrument = symbol.replace('/', '_')

        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/accounts/{self.account_id}/pricing",
                    headers=self.headers,
                    params={"instruments": instrument},
                    timeout=10.0
                )
                response.raise_for_status()
                prices = response.json().get('prices', [])

                if not prices:
                    raise Exception(f"No price data for {symbol}")

                price = prices[0]
                bid = float(price.get('bids', [{}])[0].get('price', 0))
                ask = float(price.get('asks', [{}])[0].get('price', 0))

                return MarketQuote(
                    symbol=symbol,
                    asset_type="forex",
                    bid_price=bid,
                    ask_price=ask,
                    mid_price=(bid + ask) / 2 if bid and ask else None,
                    last_price=float(price.get('closeoutBid', 0)),
                    quote_time=datetime.fromisoformat(price.get('time', datetime.now().isoformat()).replace('Z', '+00:00'))
                )

            except Exception as e:
                raise Exception(f"Failed to get quote: {str(e)}")

    async def get_quotes(self, symbols: List[str]) -> List[MarketQuote]:
        instruments = ','.join([s.replace('/', '_') for s in symbols])

        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/accounts/{self.account_id}/pricing",
                    headers=self.headers,
                    params={"instruments": instruments},
                    timeout=10.0
                )
                response.raise_for_status()
                prices = response.json().get('prices', [])

                quotes = []
                for price in prices:
                    bid = float(price.get('bids', [{}])[0].get('price', 0))
                    ask = float(price.get('asks', [{}])[0].get('price', 0))

                    quotes.append(MarketQuote(
                        symbol=price['instrument'].replace('_', '/'),
                        asset_type="forex",
                        bid_price=bid,
                        ask_price=ask,
                        mid_price=(bid + ask) / 2 if bid and ask else None,
                        last_price=float(price.get('closeoutBid', 0)),
                        quote_time=datetime.fromisoformat(price.get('time', datetime.now().isoformat()).replace('Z', '+00:00'))
                    ))

                return quotes

            except Exception as e:
                raise Exception(f"Failed to get quotes: {str(e)}")

    async def get_historical_data(
        self,
        symbol: str,
        timeframe: str,
        start: datetime,
        end: Optional[datetime] = None,
        limit: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        instrument = symbol.replace('/', '_')

        params = {
            "granularity": self._map_timeframe(timeframe),
            "from": start.isoformat(),
        }

        if end:
            params["to"] = end.isoformat()

        if limit:
            params["count"] = min(limit, 5000)

        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/instruments/{instrument}/candles",
                    headers=self.headers,
                    params=params,
                    timeout=30.0
                )
                response.raise_for_status()
                data = response.json()

                candles = data.get('candles', [])
                return [
                    {
                        "timestamp": candle['time'],
                        "open": float(candle['mid']['o']),
                        "high": float(candle['mid']['h']),
                        "low": float(candle['mid']['l']),
                        "close": float(candle['mid']['c']),
                        "volume": int(candle['volume'])
                    }
                    for candle in candles
                    if candle.get('complete', False)
                ]

            except Exception as e:
                raise Exception(f"Failed to get historical data: {str(e)}")

    async def get_trades(
        self,
        limit: int = 100,
        after: Optional[datetime] = None
    ) -> List[TradeResponse]:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/accounts/{self.account_id}/trades",
                    headers=self.headers,
                    params={"count": min(limit, 500)},
                    timeout=10.0
                )
                response.raise_for_status()
                forex_trades = response.json().get('trades', [])

                return [self._map_forex_trade_to_response(trade) for trade in forex_trades]

            except Exception as e:
                raise Exception(f"Failed to get trades: {str(e)}")

    async def subscribe_to_quotes(self, symbols: List[str], callback) -> bool:
        raise NotImplementedError("WebSocket streaming requires separate implementation")

    async def unsubscribe_from_quotes(self, symbols: List[str]) -> bool:
        raise NotImplementedError("WebSocket streaming requires separate implementation")

    def _map_order_type_to_forex(self, order_type: str) -> str:
        mapping = {
            'market': 'MARKET',
            'limit': 'LIMIT',
            'stop': 'STOP',
            'stop_limit': 'STOP_LIMIT'
        }
        return mapping.get(order_type, 'MARKET')

    def _map_time_in_force(self, tif: str) -> str:
        mapping = {
            'day': 'DAY',
            'gtc': 'GTC',
            'ioc': 'IOC',
            'fok': 'FOK'
        }
        return mapping.get(tif, 'GTC')

    def _map_timeframe(self, timeframe: str) -> str:
        mapping = {
            '1Min': 'M1',
            '5Min': 'M5',
            '15Min': 'M15',
            '1Hour': 'H1',
            '4Hour': 'H4',
            '1Day': 'D',
        }
        return mapping.get(timeframe, 'M1')

    def _map_forex_order_to_response(
        self,
        forex_order: Dict,
        fill_transaction: Dict = None,
        original_order: Optional[OrderCreate] = None
    ) -> OrderResponse:
        units = float(forex_order.get('units', 0))
        side = OrderSide.BUY if units > 0 else OrderSide.SELL

        filled_units = 0
        if fill_transaction:
            filled_units = abs(float(fill_transaction.get('units', 0)))

        status = OrderStatus.SUBMITTED
        if forex_order.get('state') == 'FILLED':
            status = OrderStatus.FILLED
        elif forex_order.get('state') == 'CANCELLED':
            status = OrderStatus.CANCELLED

        return OrderResponse(
            id=str(uuid.uuid4()),
            user_id="",
            connection_id="",
            broker_order_id=forex_order.get('id', forex_order.get('orderID')),
            client_order_id=str(uuid.uuid4()),
            symbol=forex_order.get('instrument', '').replace('_', '/'),
            asset_type=AssetType.FOREX,
            side=side,
            order_type=forex_order.get('type', 'MARKET').lower(),
            time_in_force=forex_order.get('timeInForce', 'GTC').lower(),
            quantity=abs(units),
            filled_quantity=filled_units,
            remaining_quantity=abs(units) - filled_units,
            limit_price=float(forex_order['price']) if forex_order.get('price') else None,
            stop_price=float(forex_order['priceBound']) if forex_order.get('priceBound') else None,
            average_fill_price=float(fill_transaction['price']) if fill_transaction and fill_transaction.get('price') else None,
            status=status,
            submitted_at=datetime.fromisoformat(forex_order['time'].replace('Z', '+00:00')) if forex_order.get('time') else None,
            filled_at=datetime.fromisoformat(fill_transaction['time'].replace('Z', '+00:00')) if fill_transaction and fill_transaction.get('time') else None,
            metadata=forex_order,
            created_at=datetime.now(),
            updated_at=datetime.now()
        )

    def _map_forex_position_to_response(self, forex_position: Dict) -> PositionResponse:
        long_data = forex_position.get('long', {})
        short_data = forex_position.get('short', {})

        long_units = float(long_data.get('units', 0))
        short_units = float(short_data.get('units', 0))
        net_units = long_units + short_units

        avg_price = 0
        if long_units != 0:
            avg_price = float(long_data.get('averagePrice', 0))
        elif short_units != 0:
            avg_price = float(short_data.get('averagePrice', 0))

        unrealized_pnl = float(long_data.get('unrealizedPL', 0)) + float(short_data.get('unrealizedPL', 0))

        return PositionResponse(
            id=str(uuid.uuid4()),
            user_id="",
            connection_id="",
            symbol=forex_position['instrument'].replace('_', '/'),
            asset_type="forex",
            quantity=net_units,
            available_quantity=net_units,
            average_entry_price=avg_price,
            current_price=None,
            unrealized_pnl=unrealized_pnl,
            unrealized_pnl_percent=(unrealized_pnl / (abs(net_units) * avg_price) * 100) if avg_price and net_units else 0,
            realized_pnl=0.0,
            total_pnl=unrealized_pnl,
            total_cost=abs(net_units) * avg_price,
            market_value=None,
            created_at=datetime.now(),
            updated_at=datetime.now()
        )

    def _map_forex_account_to_snapshot(self, forex_account: Dict) -> AccountSnapshot:
        balance = float(forex_account.get('balance', 0))
        nav = float(forex_account.get('NAV', 0))
        margin_used = float(forex_account.get('marginUsed', 0))
        margin_available = float(forex_account.get('marginAvailable', 0))
        unrealized_pnl = float(forex_account.get('unrealizedPL', 0))
        pl = float(forex_account.get('pl', 0))

        return AccountSnapshot(
            id=str(uuid.uuid4()),
            user_id="",
            connection_id="",
            cash_balance=balance,
            equity=nav,
            portfolio_value=nav,
            buying_power=margin_available,
            margin_used=margin_used,
            margin_available=margin_available,
            unrealized_pnl=unrealized_pnl,
            realized_pnl_today=pl,
            realized_pnl_total=pl,
            total_positions_count=int(forex_account.get('openPositionCount', 0)),
            total_open_orders_count=int(forex_account.get('openTradeCount', 0)),
            long_exposure=float(forex_account.get('positionValue', 0)),
            short_exposure=0.0,
            net_exposure=float(forex_account.get('positionValue', 0)),
            snapshot_at=datetime.now(),
            created_at=datetime.now()
        )

    def _map_forex_trade_to_response(self, forex_trade: Dict) -> TradeResponse:
        units = float(forex_trade.get('initialUnits', 0))

        return TradeResponse(
            id=str(uuid.uuid4()),
            order_id="",
            connection_id="",
            broker_trade_id=forex_trade.get('id'),
            symbol=forex_trade.get('instrument', '').replace('_', '/'),
            side=OrderSide.BUY if units > 0 else OrderSide.SELL,
            quantity=abs(units),
            price=float(forex_trade.get('price', 0)),
            commission=0.0,
            fees=0.0,
            executed_at=datetime.fromisoformat(forex_trade['openTime'].replace('Z', '+00:00')) if forex_trade.get('openTime') else datetime.now(),
            created_at=datetime.now()
        )
