from typing import Dict, Any
from app.brokers.base_adapter import BrokerAdapter


class BrokerFactory:
    _adapters: Dict[str, type] = {}

    @classmethod
    def register_adapter(cls, broker_code: str, adapter_class: type):
        cls._adapters[broker_code] = adapter_class

    @classmethod
    def create_adapter(
        cls,
        broker_code: str,
        credentials: Dict[str, Any],
        environment: str = "demo"
    ) -> BrokerAdapter:
        adapter_class = cls._adapters.get(broker_code)

        if not adapter_class:
            raise ValueError(f"Broker '{broker_code}' is not supported or not registered")

        return adapter_class(credentials, environment)

    @classmethod
    def get_supported_brokers(cls) -> list:
        return list(cls._adapters.keys())

    @classmethod
    def is_broker_supported(cls, broker_code: str) -> bool:
        return broker_code in cls._adapters
