import httpx
from typing import Dict, Any, List, Optional
from datetime import datetime
import uuid
from app.brokers.base_adapter import BrokerAdapter
from app.schemas.broker_schemas import (
    OrderCreate, OrderResponse, OrderUpdate,
    PositionResponse, AccountSnapshot, MarketQuote, TradeResponse,
    OrderStatus, OrderSide, AssetType
)


class PepperstoneAdapter(BrokerAdapter):
    SUPPORTED_ASSETS = ['forex', 'cfd', 'stock', 'crypto']
    SUPPORTED_ORDER_TYPES = ['market', 'limit', 'stop', 'stop_limit', 'trailing_stop']

    def __init__(self, credentials: Dict[str, Any], environment: str = "demo"):
        super().__init__(credentials, environment)
        self.api_key = credentials.get('api_key')
        self.account_id = credentials.get('account_id')

        if not self.api_key:
            raise ValueError("api_key is required for Pepperstone")

        self.base_url = self.get_base_url()
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }

    def get_base_url(self) -> str:
        if self.environment == "live":
            return "https://api.pepperstone.com/v1"
        return "https://api-demo.pepperstone.com/v1"

    def get_websocket_url(self) -> str:
        if self.environment == "live":
            return "wss://stream.pepperstone.com"
        return "wss://stream-demo.pepperstone.com"

    def supports_asset_type(self, asset_type: str) -> bool:
        return asset_type in self.SUPPORTED_ASSETS

    def supports_order_type(self, order_type: str) -> bool:
        return order_type in self.SUPPORTED_ORDER_TYPES

    async def connect(self) -> bool:
        try:
            result = await self.test_connection()
            self.is_connected = result.get('success', False)
            return self.is_connected
        except Exception as e:
            self.is_connected = False
            raise Exception(f"Failed to connect to Pepperstone: {str(e)}")

    async def disconnect(self) -> bool:
        self.is_connected = False
        return True

    async def test_connection(self) -> Dict[str, Any]:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/accounts",
                    headers=self.headers,
                    timeout=10.0
                )
                response.raise_for_status()
                accounts = response.json().get('accounts', [])

                if accounts and not self.account_id:
                    self.account_id = accounts[0].get('id')

                return {
                    "success": True,
                    "message": "Connection successful",
                    "account_id": self.account_id
                }
            except httpx.HTTPStatusError as e:
                return {
                    "success": False,
                    "message": f"HTTP error: {e.response.status_code}",
                    "details": e.response.text
                }
            except Exception as e:
                return {
                    "success": False,
                    "message": str(e)
                }

    async def place_order(self, order: OrderCreate) -> OrderResponse:
        self._validate_order(order)

        pepperstone_order = {
            "accountId": self.account_id,
            "symbol": order.symbol.replace('/', ''),
            "side": order.side.value.upper(),
            "type": self._map_order_type_to_pepperstone(order.order_type),
            "quantity": order.quantity,
            "timeInForce": self._map_time_in_force(order.time_in_force)
        }

        if order.limit_price:
            pepperstone_order["limitPrice"] = order.limit_price

        if order.stop_price:
            pepperstone_order["stopPrice"] = order.stop_price

        if order.trailing_percent:
            pepperstone_order["trailingPercent"] = order.trailing_percent
        elif order.trailing_amount:
            pepperstone_order["trailingAmount"] = order.trailing_amount

        if order.stop_loss_price:
            pepperstone_order["stopLoss"] = {"price": order.stop_loss_price}

        if order.take_profit_price:
            pepperstone_order["takeProfit"] = {"price": order.take_profit_price}

        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    f"{self.base_url}/orders",
                    headers=self.headers,
                    json=pepperstone_order,
                    timeout=30.0
                )
                response.raise_for_status()
                pepperstone_response = response.json()

                return self._map_pepperstone_order_to_response(pepperstone_response, order)

            except httpx.HTTPStatusError as e:
                error_detail = e.response.json() if e.response.content else {}
                raise Exception(f"Pepperstone order failed: {error_detail.get('message', str(e))}")
            except Exception as e:
                raise Exception(f"Error placing order: {str(e)}")

    async def modify_order(self, broker_order_id: str, updates: OrderUpdate) -> OrderResponse:
        pepperstone_updates = {}

        if updates.quantity:
            pepperstone_updates["quantity"] = updates.quantity
        if updates.limit_price:
            pepperstone_updates["limitPrice"] = updates.limit_price
        if updates.stop_price:
            pepperstone_updates["stopPrice"] = updates.stop_price
        if updates.trailing_percent:
            pepperstone_updates["trailingPercent"] = updates.trailing_percent

        async with httpx.AsyncClient() as client:
            try:
                response = await client.patch(
                    f"{self.base_url}/orders/{broker_order_id}",
                    headers=self.headers,
                    json=pepperstone_updates,
                    timeout=30.0
                )
                response.raise_for_status()

                return await self.get_order(broker_order_id)

            except httpx.HTTPStatusError as e:
                error_detail = e.response.json() if e.response.content else {}
                raise Exception(f"Order modification failed: {error_detail.get('message', str(e))}")

    async def cancel_order(self, broker_order_id: str) -> bool:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.delete(
                    f"{self.base_url}/orders/{broker_order_id}",
                    headers=self.headers,
                    timeout=30.0
                )
                response.raise_for_status()
                return True
            except Exception as e:
                raise Exception(f"Order cancellation failed: {str(e)}")

    async def get_order(self, broker_order_id: str) -> OrderResponse:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/orders/{broker_order_id}",
                    headers=self.headers,
                    timeout=10.0
                )
                response.raise_for_status()
                pepperstone_order = response.json()
                return self._map_pepperstone_order_to_response(pepperstone_order)
            except Exception as e:
                raise Exception(f"Failed to get order: {str(e)}")

    async def get_orders(
        self,
        status: Optional[str] = None,
        limit: int = 100,
        after: Optional[datetime] = None
    ) -> List[OrderResponse]:
        params = {"limit": min(limit, 500)}

        if status:
            params["status"] = status.upper()

        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/orders",
                    headers=self.headers,
                    params=params,
                    timeout=10.0
                )
                response.raise_for_status()
                pepperstone_orders = response.json().get('orders', [])

                return [self._map_pepperstone_order_to_response(order) for order in pepperstone_orders]

            except Exception as e:
                raise Exception(f"Failed to get orders: {str(e)}")

    async def get_positions(self) -> List[PositionResponse]:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/positions",
                    headers=self.headers,
                    params={"accountId": self.account_id},
                    timeout=10.0
                )
                response.raise_for_status()
                pepperstone_positions = response.json().get('positions', [])

                return [self._map_pepperstone_position_to_response(pos) for pos in pepperstone_positions]

            except Exception as e:
                raise Exception(f"Failed to get positions: {str(e)}")

    async def get_position(self, symbol: str) -> Optional[PositionResponse]:
        positions = await self.get_positions()

        for position in positions:
            if position.symbol == symbol:
                return position

        return None

    async def close_position(self, symbol: str, quantity: Optional[float] = None) -> OrderResponse:
        position = await self.get_position(symbol)

        if not position:
            raise Exception(f"No position found for {symbol}")

        close_side = OrderSide.SELL if position.quantity > 0 else OrderSide.BUY
        close_qty = quantity if quantity else abs(position.quantity)

        close_order = OrderCreate(
            connection_id="",
            symbol=symbol,
            asset_type=AssetType(position.asset_type),
            side=close_side,
            order_type="market",
            quantity=close_qty,
            time_in_force="ioc"
        )

        return await self.place_order(close_order)

    async def get_account(self) -> AccountSnapshot:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/accounts/{self.account_id}",
                    headers=self.headers,
                    timeout=10.0
                )
                response.raise_for_status()
                pepperstone_account = response.json()

                return self._map_pepperstone_account_to_snapshot(pepperstone_account)

            except Exception as e:
                raise Exception(f"Failed to get account: {str(e)}")

    async def get_quote(self, symbol: str) -> MarketQuote:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/quotes/{symbol.replace('/', '')}",
                    headers=self.headers,
                    timeout=10.0
                )
                response.raise_for_status()
                quote_data = response.json()

                return MarketQuote(
                    symbol=symbol,
                    asset_type="forex",
                    bid_price=quote_data.get('bid'),
                    ask_price=quote_data.get('ask'),
                    mid_price=(quote_data.get('bid', 0) + quote_data.get('ask', 0)) / 2,
                    last_price=quote_data.get('last'),
                    volume=quote_data.get('volume'),
                    daily_change=quote_data.get('change'),
                    daily_change_percent=quote_data.get('changePercent'),
                    quote_time=datetime.fromisoformat(quote_data.get('timestamp', datetime.now().isoformat()))
                )

            except Exception as e:
                raise Exception(f"Failed to get quote: {str(e)}")

    async def get_quotes(self, symbols: List[str]) -> List[MarketQuote]:
        quotes = []
        for symbol in symbols:
            try:
                quote = await self.get_quote(symbol)
                quotes.append(quote)
            except:
                continue
        return quotes

    async def get_historical_data(
        self,
        symbol: str,
        timeframe: str,
        start: datetime,
        end: Optional[datetime] = None,
        limit: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        params = {
            "symbol": symbol.replace('/', ''),
            "interval": self._map_timeframe(timeframe),
            "from": start.isoformat(),
            "to": end.isoformat() if end else datetime.now().isoformat()
        }

        if limit:
            params["limit"] = min(limit, 5000)

        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/candles",
                    headers=self.headers,
                    params=params,
                    timeout=30.0
                )
                response.raise_for_status()
                data = response.json()

                candles = data.get('candles', [])
                return [
                    {
                        "timestamp": candle['timestamp'],
                        "open": candle['open'],
                        "high": candle['high'],
                        "low": candle['low'],
                        "close": candle['close'],
                        "volume": candle.get('volume', 0)
                    }
                    for candle in candles
                ]

            except Exception as e:
                raise Exception(f"Failed to get historical data: {str(e)}")

    async def get_trades(
        self,
        limit: int = 100,
        after: Optional[datetime] = None
    ) -> List[TradeResponse]:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/trades",
                    headers=self.headers,
                    params={"accountId": self.account_id, "limit": min(limit, 500)},
                    timeout=10.0
                )
                response.raise_for_status()
                pepperstone_trades = response.json().get('trades', [])

                return [self._map_pepperstone_trade_to_response(trade) for trade in pepperstone_trades]

            except Exception as e:
                raise Exception(f"Failed to get trades: {str(e)}")

    async def subscribe_to_quotes(self, symbols: List[str], callback) -> bool:
        raise NotImplementedError("WebSocket streaming requires separate implementation")

    async def unsubscribe_from_quotes(self, symbols: List[str]) -> bool:
        raise NotImplementedError("WebSocket streaming requires separate implementation")

    def _map_order_type_to_pepperstone(self, order_type: str) -> str:
        mapping = {
            'market': 'MARKET',
            'limit': 'LIMIT',
            'stop': 'STOP',
            'stop_limit': 'STOP_LIMIT',
            'trailing_stop': 'TRAILING_STOP'
        }
        return mapping.get(order_type, 'MARKET')

    def _map_time_in_force(self, tif: str) -> str:
        mapping = {
            'day': 'DAY',
            'gtc': 'GTC',
            'ioc': 'IOC',
            'fok': 'FOK'
        }
        return mapping.get(tif, 'GTC')

    def _map_timeframe(self, timeframe: str) -> str:
        mapping = {
            '1Min': '1m',
            '5Min': '5m',
            '15Min': '15m',
            '1Hour': '1h',
            '4Hour': '4h',
            '1Day': '1d',
            '1Week': '1w'
        }
        return mapping.get(timeframe, '1d')

    def _map_pepperstone_order_to_response(
        self,
        pepperstone_order: Dict,
        original_order: Optional[OrderCreate] = None
    ) -> OrderResponse:
        status_map = {
            'PENDING': OrderStatus.PENDING,
            'SUBMITTED': OrderStatus.SUBMITTED,
            'ACCEPTED': OrderStatus.ACCEPTED,
            'PARTIAL': OrderStatus.PARTIAL_FILL,
            'FILLED': OrderStatus.FILLED,
            'CANCELLED': OrderStatus.CANCELLED,
            'REJECTED': OrderStatus.REJECTED,
            'EXPIRED': OrderStatus.EXPIRED
        }

        side_map = {'BUY': OrderSide.BUY, 'SELL': OrderSide.SELL}

        return OrderResponse(
            id=str(uuid.uuid4()),
            user_id="",
            connection_id="",
            broker_order_id=pepperstone_order.get('id', str(uuid.uuid4())),
            client_order_id=pepperstone_order.get('clientOrderId', str(uuid.uuid4())),
            symbol=pepperstone_order.get('symbol', ''),
            asset_type=AssetType.FOREX,
            side=side_map.get(pepperstone_order.get('side', 'BUY'), OrderSide.BUY),
            order_type=pepperstone_order.get('type', 'MARKET').lower(),
            time_in_force=pepperstone_order.get('timeInForce', 'GTC').lower(),
            quantity=float(pepperstone_order.get('quantity', 0)),
            filled_quantity=float(pepperstone_order.get('filledQuantity', 0)),
            remaining_quantity=float(pepperstone_order.get('remainingQuantity', 0)),
            limit_price=float(pepperstone_order['limitPrice']) if pepperstone_order.get('limitPrice') else None,
            stop_price=float(pepperstone_order['stopPrice']) if pepperstone_order.get('stopPrice') else None,
            trailing_percent=float(pepperstone_order['trailingPercent']) if pepperstone_order.get('trailingPercent') else None,
            average_fill_price=float(pepperstone_order['avgFillPrice']) if pepperstone_order.get('avgFillPrice') else None,
            status=status_map.get(pepperstone_order.get('status'), OrderStatus.PENDING),
            submitted_at=datetime.fromisoformat(pepperstone_order['submittedAt']) if pepperstone_order.get('submittedAt') else None,
            filled_at=datetime.fromisoformat(pepperstone_order['filledAt']) if pepperstone_order.get('filledAt') else None,
            cancelled_at=datetime.fromisoformat(pepperstone_order['cancelledAt']) if pepperstone_order.get('cancelledAt') else None,
            metadata=pepperstone_order,
            created_at=datetime.now(),
            updated_at=datetime.now()
        )

    def _map_pepperstone_position_to_response(self, pepperstone_position: Dict) -> PositionResponse:
        quantity = float(pepperstone_position.get('quantity', 0))
        side = pepperstone_position.get('side', 'LONG')

        if side == 'SHORT':
            quantity = -quantity

        return PositionResponse(
            id=str(uuid.uuid4()),
            user_id="",
            connection_id="",
            symbol=pepperstone_position.get('symbol', ''),
            asset_type="forex",
            quantity=quantity,
            available_quantity=quantity,
            average_entry_price=float(pepperstone_position.get('avgEntryPrice', 0)),
            current_price=float(pepperstone_position.get('currentPrice', 0)),
            unrealized_pnl=float(pepperstone_position.get('unrealizedPnl', 0)),
            unrealized_pnl_percent=float(pepperstone_position.get('unrealizedPnlPercent', 0)),
            realized_pnl=float(pepperstone_position.get('realizedPnl', 0)),
            total_pnl=float(pepperstone_position.get('totalPnl', 0)),
            total_cost=abs(quantity) * float(pepperstone_position.get('avgEntryPrice', 0)),
            market_value=float(pepperstone_position.get('marketValue', 0)),
            created_at=datetime.now(),
            updated_at=datetime.now()
        )

    def _map_pepperstone_account_to_snapshot(self, pepperstone_account: Dict) -> AccountSnapshot:
        return AccountSnapshot(
            id=str(uuid.uuid4()),
            user_id="",
            connection_id="",
            cash_balance=float(pepperstone_account.get('balance', 0)),
            equity=float(pepperstone_account.get('equity', 0)),
            portfolio_value=float(pepperstone_account.get('equity', 0)),
            buying_power=float(pepperstone_account.get('buyingPower', 0)),
            margin_used=float(pepperstone_account.get('marginUsed', 0)),
            margin_available=float(pepperstone_account.get('marginAvailable', 0)),
            unrealized_pnl=float(pepperstone_account.get('unrealizedPnl', 0)),
            realized_pnl_today=float(pepperstone_account.get('realizedPnlToday', 0)),
            realized_pnl_total=float(pepperstone_account.get('realizedPnlTotal', 0)),
            total_positions_count=int(pepperstone_account.get('positionsCount', 0)),
            total_open_orders_count=int(pepperstone_account.get('openOrdersCount', 0)),
            long_exposure=float(pepperstone_account.get('longExposure', 0)),
            short_exposure=float(pepperstone_account.get('shortExposure', 0)),
            net_exposure=float(pepperstone_account.get('netExposure', 0)),
            snapshot_at=datetime.now(),
            created_at=datetime.now()
        )

    def _map_pepperstone_trade_to_response(self, pepperstone_trade: Dict) -> TradeResponse:
        side_map = {'BUY': OrderSide.BUY, 'SELL': OrderSide.SELL}

        return TradeResponse(
            id=str(uuid.uuid4()),
            order_id=pepperstone_trade.get('orderId', ''),
            connection_id="",
            broker_trade_id=pepperstone_trade.get('id'),
            symbol=pepperstone_trade.get('symbol', ''),
            side=side_map.get(pepperstone_trade.get('side', 'BUY'), OrderSide.BUY),
            quantity=float(pepperstone_trade.get('quantity', 0)),
            price=float(pepperstone_trade.get('price', 0)),
            commission=float(pepperstone_trade.get('commission', 0)),
            fees=float(pepperstone_trade.get('fees', 0)),
            executed_at=datetime.fromisoformat(pepperstone_trade['executedAt']) if pepperstone_trade.get('executedAt') else datetime.now(),
            created_at=datetime.now()
        )
