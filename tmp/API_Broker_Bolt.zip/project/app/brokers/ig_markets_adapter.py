import httpx
from typing import Dict, Any, List, Optional
from datetime import datetime
import uuid
import base64
from app.brokers.base_adapter import BrokerAdapter
from app.schemas.broker_schemas import (
    OrderCreate, OrderResponse, OrderUpdate,
    PositionResponse, AccountSnapshot, MarketQuote, TradeResponse,
    OrderStatus, OrderSide, AssetType
)


class IGMarketsAdapter(BrokerAdapter):
    SUPPORTED_ASSETS = ['stock', 'forex', 'cfd', 'option', 'future']
    SUPPORTED_ORDER_TYPES = ['market', 'limit', 'stop']

    def __init__(self, credentials: Dict[str, Any], environment: str = "demo"):
        super().__init__(credentials, environment)
        self.api_key = credentials.get('api_key')
        self.username = credentials.get('username')
        self.password = credentials.get('password')
        self.account_id = credentials.get('account_id')

        if not all([self.api_key, self.username, self.password]):
            raise ValueError("api_key, username, and password are required for IG Markets")

        self.base_url = self.get_base_url()
        self.security_token = None
        self.cst_token = None

    def get_base_url(self) -> str:
        if self.environment == "live":
            return "https://api.ig.com/gateway/deal"
        return "https://demo-api.ig.com/gateway/deal"

    def get_websocket_url(self) -> str:
        if self.environment == "live":
            return "wss://api.ig.com/gateway/deal/stream"
        return "wss://demo-api.ig.com/gateway/deal/stream"

    def supports_asset_type(self, asset_type: str) -> bool:
        return asset_type in self.SUPPORTED_ASSETS

    def supports_order_type(self, order_type: str) -> bool:
        return order_type in self.SUPPORTED_ORDER_TYPES

    async def connect(self) -> bool:
        try:
            result = await self.test_connection()
            self.is_connected = result.get('success', False)
            return self.is_connected
        except Exception as e:
            self.is_connected = False
            raise Exception(f"Failed to connect to IG Markets: {str(e)}")

    async def disconnect(self) -> bool:
        if self.security_token and self.cst_token:
            async with httpx.AsyncClient() as client:
                try:
                    headers = self._get_headers()
                    await client.delete(
                        f"{self.base_url}/session",
                        headers=headers,
                        timeout=10.0
                    )
                except:
                    pass

        self.is_connected = False
        self.security_token = None
        self.cst_token = None
        return True

    async def test_connection(self) -> Dict[str, Any]:
        async with httpx.AsyncClient() as client:
            try:
                headers = {
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                    "VERSION": "2",
                    "X-IG-API-KEY": self.api_key
                }

                auth_data = {
                    "identifier": self.username,
                    "password": self.password
                }

                response = await client.post(
                    f"{self.base_url}/session",
                    headers=headers,
                    json=auth_data,
                    timeout=10.0
                )
                response.raise_for_status()

                self.cst_token = response.headers.get('CST')
                self.security_token = response.headers.get('X-SECURITY-TOKEN')

                data = response.json()
                self.account_id = data.get('currentAccountId', self.account_id)

                return {
                    "success": True,
                    "message": "Connection successful",
                    "account_id": self.account_id
                }

            except httpx.HTTPStatusError as e:
                return {
                    "success": False,
                    "message": f"HTTP error: {e.response.status_code}",
                    "details": e.response.text
                }
            except Exception as e:
                return {
                    "success": False,
                    "message": str(e)
                }

    def _get_headers(self) -> Dict[str, str]:
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "VERSION": "2",
            "X-IG-API-KEY": self.api_key
        }

        if self.cst_token:
            headers["CST"] = self.cst_token
        if self.security_token:
            headers["X-SECURITY-TOKEN"] = self.security_token

        return headers

    async def place_order(self, order: OrderCreate) -> OrderResponse:
        self._validate_order(order)

        if not self.cst_token:
            await self.test_connection()

        ig_order = {
            "epic": order.symbol,
            "direction": "BUY" if order.side == OrderSide.BUY else "SELL",
            "size": str(order.quantity),
            "orderType": self._map_order_type_to_ig(order.order_type),
            "timeInForce": "GOOD_TILL_CANCELLED" if order.time_in_force.value == "gtc" else "FILL_OR_KILL",
            "guaranteedStop": False,
            "forceOpen": True
        }

        if order.limit_price:
            ig_order["level"] = str(order.limit_price)

        if order.stop_loss_price:
            ig_order["stopLevel"] = str(order.stop_loss_price)

        if order.take_profit_price:
            ig_order["limitLevel"] = str(order.take_profit_price)

        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    f"{self.base_url}/positions/otc",
                    headers=self._get_headers(),
                    json=ig_order,
                    timeout=30.0
                )
                response.raise_for_status()
                ig_response = response.json()

                deal_reference = ig_response.get('dealReference')

                await asyncio.sleep(1)
                order_status = await self._get_deal_confirmation(deal_reference)

                return self._map_ig_order_to_response(order_status, order)

            except httpx.HTTPStatusError as e:
                error_detail = e.response.json() if e.response.content else {}
                raise Exception(f"IG Markets order failed: {error_detail.get('errorCode', str(e))}")
            except Exception as e:
                raise Exception(f"Error placing order: {str(e)}")

    async def _get_deal_confirmation(self, deal_reference: str) -> Dict[str, Any]:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/confirms/{deal_reference}",
                    headers=self._get_headers(),
                    timeout=10.0
                )
                response.raise_for_status()
                return response.json()
            except:
                return {}

    async def modify_order(self, broker_order_id: str, updates: OrderUpdate) -> OrderResponse:
        if not self.cst_token:
            await self.test_connection()

        ig_updates = {}

        if updates.limit_price:
            ig_updates["limitLevel"] = str(updates.limit_price)
        if updates.stop_price:
            ig_updates["stopLevel"] = str(updates.stop_price)

        async with httpx.AsyncClient() as client:
            try:
                response = await client.put(
                    f"{self.base_url}/positions/otc/{broker_order_id}",
                    headers=self._get_headers(),
                    json=ig_updates,
                    timeout=30.0
                )
                response.raise_for_status()

                return await self.get_order(broker_order_id)

            except httpx.HTTPStatusError as e:
                error_detail = e.response.json() if e.response.content else {}
                raise Exception(f"Order modification failed: {error_detail.get('errorCode', str(e))}")

    async def cancel_order(self, broker_order_id: str) -> bool:
        if not self.cst_token:
            await self.test_connection()

        async with httpx.AsyncClient() as client:
            try:
                response = await client.delete(
                    f"{self.base_url}/positions/otc",
                    headers=self._get_headers(),
                    json={"dealId": broker_order_id},
                    timeout=30.0
                )
                response.raise_for_status()
                return True
            except Exception as e:
                raise Exception(f"Order cancellation failed: {str(e)}")

    async def get_order(self, broker_order_id: str) -> OrderResponse:
        if not self.cst_token:
            await self.test_connection()

        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/positions/{broker_order_id}",
                    headers=self._get_headers(),
                    timeout=10.0
                )
                response.raise_for_status()
                ig_order = response.json()
                return self._map_ig_order_to_response(ig_order)
            except Exception as e:
                raise Exception(f"Failed to get order: {str(e)}")

    async def get_orders(
        self,
        status: Optional[str] = None,
        limit: int = 100,
        after: Optional[datetime] = None
    ) -> List[OrderResponse]:
        if not self.cst_token:
            await self.test_connection()

        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/workingorders",
                    headers=self._get_headers(),
                    timeout=10.0
                )
                response.raise_for_status()
                ig_orders = response.json().get('workingOrders', [])

                return [self._map_ig_order_to_response(order) for order in ig_orders[:limit]]

            except Exception as e:
                raise Exception(f"Failed to get orders: {str(e)}")

    async def get_positions(self) -> List[PositionResponse]:
        if not self.cst_token:
            await self.test_connection()

        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/positions",
                    headers=self._get_headers(),
                    timeout=10.0
                )
                response.raise_for_status()
                ig_positions = response.json().get('positions', [])

                return [self._map_ig_position_to_response(pos) for pos in ig_positions]

            except Exception as e:
                raise Exception(f"Failed to get positions: {str(e)}")

    async def get_position(self, symbol: str) -> Optional[PositionResponse]:
        positions = await self.get_positions()

        for position in positions:
            if position.symbol == symbol:
                return position

        return None

    async def close_position(self, symbol: str, quantity: Optional[float] = None) -> OrderResponse:
        position = await self.get_position(symbol)

        if not position:
            raise Exception(f"No position found for {symbol}")

        async with httpx.AsyncClient() as client:
            try:
                close_order = {
                    "dealId": position.id,
                    "direction": "SELL" if position.quantity > 0 else "BUY",
                    "size": str(quantity if quantity else abs(position.quantity)),
                    "orderType": "MARKET"
                }

                response = await client.delete(
                    f"{self.base_url}/positions/otc",
                    headers=self._get_headers(),
                    json=close_order,
                    timeout=30.0
                )
                response.raise_for_status()

                return OrderResponse(
                    id=str(uuid.uuid4()),
                    user_id="",
                    connection_id="",
                    broker_order_id=response.json().get('dealReference'),
                    client_order_id=str(uuid.uuid4()),
                    symbol=symbol,
                    asset_type=AssetType(position.asset_type),
                    side=OrderSide.SELL if position.quantity > 0 else OrderSide.BUY,
                    order_type="market",
                    time_in_force="ioc",
                    quantity=quantity if quantity else abs(position.quantity),
                    filled_quantity=0,
                    remaining_quantity=0,
                    status=OrderStatus.SUBMITTED,
                    created_at=datetime.now(),
                    updated_at=datetime.now()
                )

            except Exception as e:
                raise Exception(f"Failed to close position: {str(e)}")

    async def get_account(self) -> AccountSnapshot:
        if not self.cst_token:
            await self.test_connection()

        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/accounts",
                    headers=self._get_headers(),
                    timeout=10.0
                )
                response.raise_for_status()
                accounts = response.json().get('accounts', [])

                current_account = None
                for acc in accounts:
                    if acc.get('accountId') == self.account_id:
                        current_account = acc
                        break

                if not current_account and accounts:
                    current_account = accounts[0]

                return self._map_ig_account_to_snapshot(current_account or {})

            except Exception as e:
                raise Exception(f"Failed to get account: {str(e)}")

    async def get_quote(self, symbol: str) -> MarketQuote:
        if not self.cst_token:
            await self.test_connection()

        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/markets/{symbol}",
                    headers=self._get_headers(),
                    timeout=10.0
                )
                response.raise_for_status()
                data = response.json()

                snapshot = data.get('snapshot', {})

                return MarketQuote(
                    symbol=symbol,
                    asset_type="forex",
                    bid_price=snapshot.get('bid'),
                    ask_price=snapshot.get('offer'),
                    mid_price=(snapshot.get('bid', 0) + snapshot.get('offer', 0)) / 2,
                    last_price=snapshot.get('bid'),
                    volume=snapshot.get('volume'),
                    daily_change=snapshot.get('netChange'),
                    daily_change_percent=snapshot.get('percentageChange'),
                    quote_time=datetime.now()
                )

            except Exception as e:
                raise Exception(f"Failed to get quote: {str(e)}")

    async def get_quotes(self, symbols: List[str]) -> List[MarketQuote]:
        quotes = []
        for symbol in symbols:
            try:
                quote = await self.get_quote(symbol)
                quotes.append(quote)
            except:
                continue
        return quotes

    async def get_historical_data(
        self,
        symbol: str,
        timeframe: str,
        start: datetime,
        end: Optional[datetime] = None,
        limit: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        if not self.cst_token:
            await self.test_connection()

        resolution = self._map_timeframe_to_ig(timeframe)

        async with httpx.AsyncClient() as client:
            try:
                params = {
                    "resolution": resolution,
                    "from": start.isoformat(),
                    "to": end.isoformat() if end else datetime.now().isoformat()
                }

                response = await client.get(
                    f"{self.base_url}/prices/{symbol}",
                    headers=self._get_headers(),
                    params=params,
                    timeout=30.0
                )
                response.raise_for_status()
                data = response.json()

                prices = data.get('prices', [])
                return [
                    {
                        "timestamp": price['snapshotTime'],
                        "open": price['openPrice']['bid'],
                        "high": price['highPrice']['bid'],
                        "low": price['lowPrice']['bid'],
                        "close": price['closePrice']['bid'],
                        "volume": price.get('lastTradedVolume', 0)
                    }
                    for price in prices
                ]

            except Exception as e:
                raise Exception(f"Failed to get historical data: {str(e)}")

    async def get_trades(
        self,
        limit: int = 100,
        after: Optional[datetime] = None
    ) -> List[TradeResponse]:
        raise NotImplementedError("IG Markets trades endpoint not yet implemented")

    async def subscribe_to_quotes(self, symbols: List[str], callback) -> bool:
        raise NotImplementedError("WebSocket streaming requires separate implementation")

    async def unsubscribe_from_quotes(self, symbols: List[str]) -> bool:
        raise NotImplementedError("WebSocket streaming requires separate implementation")

    def _map_order_type_to_ig(self, order_type: str) -> str:
        mapping = {
            'market': 'MARKET',
            'limit': 'LIMIT',
            'stop': 'STOP'
        }
        return mapping.get(order_type, 'MARKET')

    def _map_timeframe_to_ig(self, timeframe: str) -> str:
        mapping = {
            '1Min': 'MINUTE',
            '5Min': 'MINUTE_5',
            '1Hour': 'HOUR',
            '1Day': 'DAY',
            '1Week': 'WEEK'
        }
        return mapping.get(timeframe, 'DAY')

    def _map_ig_order_to_response(self, ig_order: Dict, original_order: Optional[OrderCreate] = None) -> OrderResponse:
        market = ig_order.get('market', {})
        position = ig_order.get('position', {})

        direction = position.get('direction', 'BUY')
        side = OrderSide.BUY if direction == 'BUY' else OrderSide.SELL

        status = OrderStatus.SUBMITTED
        if ig_order.get('status') == 'OPEN':
            status = OrderStatus.FILLED
        elif ig_order.get('dealStatus') == 'REJECTED':
            status = OrderStatus.REJECTED

        return OrderResponse(
            id=str(uuid.uuid4()),
            user_id="",
            connection_id="",
            broker_order_id=ig_order.get('dealId', str(uuid.uuid4())),
            client_order_id=str(uuid.uuid4()),
            symbol=market.get('epic', ''),
            asset_type=AssetType.FOREX,
            side=side,
            order_type=ig_order.get('orderType', 'MARKET').lower(),
            time_in_force="gtc",
            quantity=float(position.get('dealSize', 0)),
            filled_quantity=float(position.get('dealSize', 0)),
            remaining_quantity=0,
            limit_price=float(position.get('limitLevel')) if position.get('limitLevel') else None,
            stop_price=float(position.get('stopLevel')) if position.get('stopLevel') else None,
            average_fill_price=float(position.get('level', 0)),
            status=status,
            metadata=ig_order,
            created_at=datetime.now(),
            updated_at=datetime.now()
        )

    def _map_ig_position_to_response(self, ig_position: Dict) -> PositionResponse:
        market = ig_position.get('market', {})
        position = ig_position.get('position', {})

        contract_size = float(position.get('contractSize', 1))
        size = float(position.get('dealSize', 0))
        direction = position.get('direction', 'BUY')
        quantity = size * contract_size if direction == 'BUY' else -size * contract_size

        return PositionResponse(
            id=ig_position.get('position', {}).get('dealId', str(uuid.uuid4())),
            user_id="",
            connection_id="",
            symbol=market.get('epic', ''),
            asset_type="forex",
            quantity=quantity,
            available_quantity=quantity,
            average_entry_price=float(position.get('level', 0)),
            current_price=float(market.get('bid', 0)),
            unrealized_pnl=float(position.get('profit', 0)),
            unrealized_pnl_percent=float(position.get('profitPercentage', 0)),
            realized_pnl=0.0,
            total_pnl=float(position.get('profit', 0)),
            total_cost=float(position.get('level', 0)) * abs(quantity),
            market_value=None,
            created_at=datetime.now(),
            updated_at=datetime.now()
        )

    def _map_ig_account_to_snapshot(self, ig_account: Dict) -> AccountSnapshot:
        balance = ig_account.get('balance', {})

        return AccountSnapshot(
            id=str(uuid.uuid4()),
            user_id="",
            connection_id="",
            cash_balance=float(balance.get('balance', 0)),
            equity=float(balance.get('available', 0)),
            portfolio_value=float(balance.get('balance', 0)),
            buying_power=float(balance.get('available', 0)),
            margin_used=float(balance.get('deposit', 0)),
            margin_available=float(balance.get('available', 0)),
            unrealized_pnl=float(balance.get('profitLoss', 0)),
            realized_pnl_today=0.0,
            realized_pnl_total=0.0,
            total_positions_count=0,
            total_open_orders_count=0,
            long_exposure=0.0,
            short_exposure=0.0,
            net_exposure=0.0,
            snapshot_at=datetime.now(),
            created_at=datetime.now()
        )


import asyncio
