import httpx
from typing import Dict, Any, List, Optional
from datetime import datetime
import uuid
from app.brokers.base_adapter import BrokerAdapter
from app.schemas.broker_schemas import (
    OrderCreate, OrderResponse, OrderUpdate,
    PositionResponse, AccountSnapshot, MarketQuote, TradeResponse,
    OrderStatus, OrderSide, AssetType
)


class FXCMAdapter(BrokerAdapter):
    SUPPORTED_ASSETS = ['forex', 'cfd']
    SUPPORTED_ORDER_TYPES = ['market', 'limit', 'stop', 'stop_limit']

    def __init__(self, credentials: Dict[str, Any], environment: str = "demo"):
        super().__init__(credentials, environment)
        self.access_token = credentials.get('access_token')
        self.account_id = credentials.get('account_id')

        if not self.access_token:
            raise ValueError("access_token is required for FXCM")

        self.base_url = self.get_base_url()
        self.headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }

    def get_base_url(self) -> str:
        if self.environment == "live":
            return "https://api.fxcm.com/v1"
        return "https://api-demo.fxcm.com/v1"

    def get_websocket_url(self) -> str:
        if self.environment == "live":
            return "wss://stream.fxcm.com"
        return "wss://stream-demo.fxcm.com"

    def supports_asset_type(self, asset_type: str) -> bool:
        return asset_type in self.SUPPORTED_ASSETS

    def supports_order_type(self, order_type: str) -> bool:
        return order_type in self.SUPPORTED_ORDER_TYPES

    async def connect(self) -> bool:
        try:
            result = await self.test_connection()
            self.is_connected = result.get('success', False)
            return self.is_connected
        except Exception as e:
            self.is_connected = False
            raise Exception(f"Failed to connect to FXCM: {str(e)}")

    async def disconnect(self) -> bool:
        self.is_connected = False
        return True

    async def test_connection(self) -> Dict[str, Any]:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/accounts",
                    headers=self.headers,
                    timeout=10.0
                )
                response.raise_for_status()
                accounts = response.json().get('data', [])

                if accounts:
                    self.account_id = accounts[0].get('accountId') if not self.account_id else self.account_id

                return {
                    "success": True,
                    "message": "Connection successful",
                    "account_id": self.account_id
                }
            except httpx.HTTPStatusError as e:
                return {
                    "success": False,
                    "message": f"HTTP error: {e.response.status_code}",
                    "details": e.response.text
                }
            except Exception as e:
                return {
                    "success": False,
                    "message": str(e)
                }

    async def place_order(self, order: OrderCreate) -> OrderResponse:
        self._validate_order(order)

        fxcm_order = {
            "symbol": order.symbol.replace('/', ''),
            "side": "buy" if order.side == OrderSide.BUY else "sell",
            "type": self._map_order_type_to_fxcm(order.order_type),
            "quantity": int(order.quantity),
            "timeInForce": self._map_time_in_force(order.time_in_force)
        }

        if order.limit_price:
            fxcm_order["price"] = order.limit_price

        if order.stop_price:
            fxcm_order["stopPrice"] = order.stop_price

        if order.stop_loss_price:
            fxcm_order["stopLoss"] = order.stop_loss_price

        if order.take_profit_price:
            fxcm_order["takeProfit"] = order.take_profit_price

        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    f"{self.base_url}/trading/open_trade",
                    headers=self.headers,
                    json=fxcm_order,
                    timeout=30.0
                )
                response.raise_for_status()
                fxcm_response = response.json()

                return self._map_fxcm_order_to_response(fxcm_response.get('data', {}), order)

            except httpx.HTTPStatusError as e:
                error_detail = e.response.json() if e.response.content else {}
                raise Exception(f"FXCM order failed: {error_detail.get('message', str(e))}")
            except Exception as e:
                raise Exception(f"Error placing order: {str(e)}")

    async def modify_order(self, broker_order_id: str, updates: OrderUpdate) -> OrderResponse:
        fxcm_updates = {"orderId": broker_order_id}

        if updates.quantity:
            fxcm_updates["quantity"] = int(updates.quantity)
        if updates.limit_price:
            fxcm_updates["price"] = updates.limit_price
        if updates.stop_price:
            fxcm_updates["stopPrice"] = updates.stop_price

        async with httpx.AsyncClient() as client:
            try:
                response = await client.put(
                    f"{self.base_url}/trading/change_order",
                    headers=self.headers,
                    json=fxcm_updates,
                    timeout=30.0
                )
                response.raise_for_status()

                return await self.get_order(broker_order_id)

            except httpx.HTTPStatusError as e:
                error_detail = e.response.json() if e.response.content else {}
                raise Exception(f"Order modification failed: {error_detail.get('message', str(e))}")

    async def cancel_order(self, broker_order_id: str) -> bool:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.delete(
                    f"{self.base_url}/trading/close_trade",
                    headers=self.headers,
                    json={"orderId": broker_order_id},
                    timeout=30.0
                )
                response.raise_for_status()
                return True
            except Exception as e:
                raise Exception(f"Order cancellation failed: {str(e)}")

    async def get_order(self, broker_order_id: str) -> OrderResponse:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/trading/get_model",
                    headers=self.headers,
                    params={"models": "Order", "orderId": broker_order_id},
                    timeout=10.0
                )
                response.raise_for_status()
                fxcm_order = response.json().get('data', {})
                return self._map_fxcm_order_to_response(fxcm_order)
            except Exception as e:
                raise Exception(f"Failed to get order: {str(e)}")

    async def get_orders(
        self,
        status: Optional[str] = None,
        limit: int = 100,
        after: Optional[datetime] = None
    ) -> List[OrderResponse]:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/trading/get_model",
                    headers=self.headers,
                    params={"models": "Order"},
                    timeout=10.0
                )
                response.raise_for_status()
                fxcm_orders = response.json().get('data', {}).get('orders', [])

                return [self._map_fxcm_order_to_response(order) for order in fxcm_orders[:limit]]

            except Exception as e:
                raise Exception(f"Failed to get orders: {str(e)}")

    async def get_positions(self) -> List[PositionResponse]:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/trading/get_model",
                    headers=self.headers,
                    params={"models": "OpenPosition"},
                    timeout=10.0
                )
                response.raise_for_status()
                fxcm_positions = response.json().get('data', {}).get('open_positions', [])

                return [self._map_fxcm_position_to_response(pos) for pos in fxcm_positions]

            except Exception as e:
                raise Exception(f"Failed to get positions: {str(e)}")

    async def get_position(self, symbol: str) -> Optional[PositionResponse]:
        positions = await self.get_positions()

        for position in positions:
            if position.symbol == symbol:
                return position

        return None

    async def close_position(self, symbol: str, quantity: Optional[float] = None) -> OrderResponse:
        position = await self.get_position(symbol)

        if not position:
            raise Exception(f"No position found for {symbol}")

        async with httpx.AsyncClient() as client:
            try:
                close_order = {
                    "tradeId": position.id,
                    "quantity": int(quantity) if quantity else int(abs(position.quantity))
                }

                response = await client.post(
                    f"{self.base_url}/trading/close_trade",
                    headers=self.headers,
                    json=close_order,
                    timeout=30.0
                )
                response.raise_for_status()

                return OrderResponse(
                    id=str(uuid.uuid4()),
                    user_id="",
                    connection_id="",
                    broker_order_id=response.json().get('data', {}).get('orderId', str(uuid.uuid4())),
                    client_order_id=str(uuid.uuid4()),
                    symbol=symbol,
                    asset_type=AssetType(position.asset_type),
                    side=OrderSide.SELL if position.quantity > 0 else OrderSide.BUY,
                    order_type="market",
                    time_in_force="ioc",
                    quantity=quantity if quantity else abs(position.quantity),
                    filled_quantity=0,
                    remaining_quantity=0,
                    status=OrderStatus.SUBMITTED,
                    created_at=datetime.now(),
                    updated_at=datetime.now()
                )

            except Exception as e:
                raise Exception(f"Failed to close position: {str(e)}")

    async def get_account(self) -> AccountSnapshot:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/trading/get_model",
                    headers=self.headers,
                    params={"models": "Account"},
                    timeout=10.0
                )
                response.raise_for_status()
                fxcm_accounts = response.json().get('data', {}).get('accounts', [])

                current_account = None
                for acc in fxcm_accounts:
                    if self.account_id and acc.get('accountId') == self.account_id:
                        current_account = acc
                        break

                if not current_account and fxcm_accounts:
                    current_account = fxcm_accounts[0]

                return self._map_fxcm_account_to_snapshot(current_account or {})

            except Exception as e:
                raise Exception(f"Failed to get account: {str(e)}")

    async def get_quote(self, symbol: str) -> MarketQuote:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/subscribe/pricing",
                    headers=self.headers,
                    params={"pairs": symbol.replace('/', '')},
                    timeout=10.0
                )
                response.raise_for_status()
                data = response.json().get('data', {})

                rates = data.get('rates', [])
                if not rates:
                    raise Exception(f"No quote data for {symbol}")

                rate = rates[0]

                return MarketQuote(
                    symbol=symbol,
                    asset_type="forex",
                    bid_price=rate.get('Bid'),
                    ask_price=rate.get('Ask'),
                    mid_price=(rate.get('Bid', 0) + rate.get('Ask', 0)) / 2,
                    last_price=rate.get('Bid'),
                    volume=rate.get('Volume'),
                    quote_time=datetime.now()
                )

            except Exception as e:
                raise Exception(f"Failed to get quote: {str(e)}")

    async def get_quotes(self, symbols: List[str]) -> List[MarketQuote]:
        pairs = ','.join([s.replace('/', '') for s in symbols])

        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/subscribe/pricing",
                    headers=self.headers,
                    params={"pairs": pairs},
                    timeout=10.0
                )
                response.raise_for_status()
                data = response.json().get('data', {})
                rates = data.get('rates', [])

                quotes = []
                for rate in rates:
                    quotes.append(MarketQuote(
                        symbol=rate.get('Symbol', ''),
                        asset_type="forex",
                        bid_price=rate.get('Bid'),
                        ask_price=rate.get('Ask'),
                        mid_price=(rate.get('Bid', 0) + rate.get('Ask', 0)) / 2,
                        last_price=rate.get('Bid'),
                        volume=rate.get('Volume'),
                        quote_time=datetime.now()
                    ))

                return quotes

            except Exception as e:
                raise Exception(f"Failed to get quotes: {str(e)}")

    async def get_historical_data(
        self,
        symbol: str,
        timeframe: str,
        start: datetime,
        end: Optional[datetime] = None,
        limit: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        async with httpx.AsyncClient() as client:
            try:
                params = {
                    "symbol": symbol.replace('/', ''),
                    "period": self._map_timeframe(timeframe),
                    "from": int(start.timestamp()),
                    "to": int(end.timestamp() if end else datetime.now().timestamp())
                }

                response = await client.get(
                    f"{self.base_url}/candles",
                    headers=self.headers,
                    params=params,
                    timeout=30.0
                )
                response.raise_for_status()
                data = response.json()

                candles = data.get('data', {}).get('candles', [])
                return [
                    {
                        "timestamp": datetime.fromtimestamp(candle['timestamp']).isoformat(),
                        "open": candle['open'],
                        "high": candle['high'],
                        "low": candle['low'],
                        "close": candle['close'],
                        "volume": candle.get('volume', 0)
                    }
                    for candle in candles
                ]

            except Exception as e:
                raise Exception(f"Failed to get historical data: {str(e)}")

    async def get_trades(
        self,
        limit: int = 100,
        after: Optional[datetime] = None
    ) -> List[TradeResponse]:
        raise NotImplementedError("FXCM trades endpoint not yet implemented")

    async def subscribe_to_quotes(self, symbols: List[str], callback) -> bool:
        raise NotImplementedError("WebSocket streaming requires separate implementation")

    async def unsubscribe_from_quotes(self, symbols: List[str]) -> bool:
        raise NotImplementedError("WebSocket streaming requires separate implementation")

    def _map_order_type_to_fxcm(self, order_type: str) -> str:
        mapping = {
            'market': 'AtMarket',
            'limit': 'Entry',
            'stop': 'StopEntry',
            'stop_limit': 'LimitEntry'
        }
        return mapping.get(order_type, 'AtMarket')

    def _map_time_in_force(self, tif: str) -> str:
        mapping = {
            'day': 'DAY',
            'gtc': 'GTC',
            'ioc': 'IOC',
            'fok': 'FOK'
        }
        return mapping.get(tif, 'GTC')

    def _map_timeframe(self, timeframe: str) -> str:
        mapping = {
            '1Min': 'm1',
            '5Min': 'm5',
            '15Min': 'm15',
            '1Hour': 'H1',
            '4Hour': 'H4',
            '1Day': 'D1',
        }
        return mapping.get(timeframe, 'D1')

    def _map_fxcm_order_to_response(
        self,
        fxcm_order: Dict,
        original_order: Optional[OrderCreate] = None
    ) -> OrderResponse:
        is_buy = fxcm_order.get('isBuy', True)
        side = OrderSide.BUY if is_buy else OrderSide.SELL

        status = OrderStatus.SUBMITTED
        if fxcm_order.get('status') == 'executed':
            status = OrderStatus.FILLED
        elif fxcm_order.get('status') == 'canceled':
            status = OrderStatus.CANCELLED
        elif fxcm_order.get('status') == 'rejected':
            status = OrderStatus.REJECTED

        return OrderResponse(
            id=str(uuid.uuid4()),
            user_id="",
            connection_id="",
            broker_order_id=str(fxcm_order.get('orderId', uuid.uuid4())),
            client_order_id=str(uuid.uuid4()),
            symbol=fxcm_order.get('currency', ''),
            asset_type=AssetType.FOREX,
            side=side,
            order_type=fxcm_order.get('type', 'AtMarket').lower(),
            time_in_force="gtc",
            quantity=float(fxcm_order.get('amountK', 0)) * 1000,
            filled_quantity=float(fxcm_order.get('amountK', 0)) * 1000 if status == OrderStatus.FILLED else 0,
            remaining_quantity=0 if status == OrderStatus.FILLED else float(fxcm_order.get('amountK', 0)) * 1000,
            limit_price=float(fxcm_order['rate']) if fxcm_order.get('rate') else None,
            stop_price=float(fxcm_order['stop']) if fxcm_order.get('stop') else None,
            average_fill_price=float(fxcm_order.get('open', 0)) if fxcm_order.get('open') else None,
            status=status,
            metadata=fxcm_order,
            created_at=datetime.now(),
            updated_at=datetime.now()
        )

    def _map_fxcm_position_to_response(self, fxcm_position: Dict) -> PositionResponse:
        is_buy = fxcm_position.get('isBuy', True)
        quantity = float(fxcm_position.get('amountK', 0)) * 1000

        if not is_buy:
            quantity = -quantity

        return PositionResponse(
            id=str(fxcm_position.get('tradeId', uuid.uuid4())),
            user_id="",
            connection_id="",
            symbol=fxcm_position.get('currency', ''),
            asset_type="forex",
            quantity=quantity,
            available_quantity=quantity,
            average_entry_price=float(fxcm_position.get('open', 0)),
            current_price=float(fxcm_position.get('close', 0)),
            unrealized_pnl=float(fxcm_position.get('grossPL', 0)),
            unrealized_pnl_percent=(float(fxcm_position.get('grossPL', 0)) / (abs(quantity) * float(fxcm_position.get('open', 1))) * 100),
            realized_pnl=0.0,
            total_pnl=float(fxcm_position.get('grossPL', 0)),
            total_cost=abs(quantity) * float(fxcm_position.get('open', 0)),
            market_value=None,
            created_at=datetime.now(),
            updated_at=datetime.now()
        )

    def _map_fxcm_account_to_snapshot(self, fxcm_account: Dict) -> AccountSnapshot:
        return AccountSnapshot(
            id=str(uuid.uuid4()),
            user_id="",
            connection_id="",
            cash_balance=float(fxcm_account.get('balance', 0)),
            equity=float(fxcm_account.get('equity', 0)),
            portfolio_value=float(fxcm_account.get('equity', 0)),
            buying_power=float(fxcm_account.get('usableMargin', 0)),
            margin_used=float(fxcm_account.get('usdMr', 0)),
            margin_available=float(fxcm_account.get('usableMargin', 0)),
            unrealized_pnl=float(fxcm_account.get('grossPL', 0)),
            realized_pnl_today=float(fxcm_account.get('dayPL', 0)),
            realized_pnl_total=0.0,
            total_positions_count=0,
            total_open_orders_count=0,
            long_exposure=0.0,
            short_exposure=0.0,
            net_exposure=0.0,
            snapshot_at=datetime.now(),
            created_at=datetime.now()
        )
