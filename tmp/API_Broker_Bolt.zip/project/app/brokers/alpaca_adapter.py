import httpx
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
import uuid
from app.brokers.base_adapter import BrokerAdapter
from app.schemas.broker_schemas import (
    OrderCreate, OrderResponse, OrderUpdate,
    PositionResponse, AccountSnapshot, MarketQuote, TradeResponse,
    OrderStatus, OrderSide, AssetType
)


class AlpacaAdapter(BrokerAdapter):
    SUPPORTED_ASSETS = ['stock', 'etf', 'crypto']
    SUPPORTED_ORDER_TYPES = ['market', 'limit', 'stop', 'stop_limit', 'trailing_stop']

    def __init__(self, credentials: Dict[str, Any], environment: str = "demo"):
        super().__init__(credentials, environment)
        self.api_key = credentials.get('api_key')
        self.api_secret = credentials.get('api_secret')

        if not self.api_key or not self.api_secret:
            raise ValueError("api_key and api_secret are required for Alpaca")

        self.base_url = self.get_base_url()
        self.data_url = "https://data.alpaca.markets"
        self.headers = {
            "APCA-API-KEY-ID": self.api_key,
            "APCA-API-SECRET-KEY": self.api_secret,
            "Content-Type": "application/json"
        }

    def get_base_url(self) -> str:
        if self.environment == "live":
            return "https://api.alpaca.markets"
        return "https://paper-api.alpaca.markets"

    def get_websocket_url(self) -> str:
        return "wss://stream.data.alpaca.markets"

    def supports_asset_type(self, asset_type: str) -> bool:
        return asset_type in self.SUPPORTED_ASSETS

    def supports_order_type(self, order_type: str) -> bool:
        return order_type in self.SUPPORTED_ORDER_TYPES

    async def connect(self) -> bool:
        try:
            result = await self.test_connection()
            self.is_connected = result.get('success', False)
            return self.is_connected
        except Exception as e:
            self.is_connected = False
            raise Exception(f"Failed to connect to Alpaca: {str(e)}")

    async def disconnect(self) -> bool:
        self.is_connected = False
        return True

    async def test_connection(self) -> Dict[str, Any]:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/v2/account",
                    headers=self.headers,
                    timeout=10.0
                )
                response.raise_for_status()
                return {
                    "success": True,
                    "message": "Connection successful",
                    "account_id": response.json().get('id')
                }
            except httpx.HTTPStatusError as e:
                return {
                    "success": False,
                    "message": f"HTTP error: {e.response.status_code}",
                    "details": e.response.text
                }
            except Exception as e:
                return {
                    "success": False,
                    "message": str(e)
                }

    async def place_order(self, order: OrderCreate) -> OrderResponse:
        self._validate_order(order)

        alpaca_order = {
            "symbol": order.symbol.upper(),
            "qty": str(order.quantity),
            "side": order.side.value,
            "type": order.order_type.value,
            "time_in_force": order.time_in_force.value,
        }

        if order.limit_price:
            alpaca_order["limit_price"] = str(order.limit_price)

        if order.stop_price:
            alpaca_order["stop_price"] = str(order.stop_price)

        if order.trailing_percent:
            alpaca_order["trail_percent"] = str(order.trailing_percent)
        elif order.trailing_amount:
            alpaca_order["trail_price"] = str(order.trailing_amount)

        if order.take_profit_price or order.stop_loss_price:
            alpaca_order["order_class"] = "bracket"
            if order.take_profit_price:
                alpaca_order["take_profit"] = {"limit_price": str(order.take_profit_price)}
            if order.stop_loss_price:
                alpaca_order["stop_loss"] = {"stop_price": str(order.stop_loss_price)}

        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    f"{self.base_url}/v2/orders",
                    headers=self.headers,
                    json=alpaca_order,
                    timeout=30.0
                )
                response.raise_for_status()
                alpaca_response = response.json()

                return self._map_alpaca_order_to_response(alpaca_response, order)

            except httpx.HTTPStatusError as e:
                error_detail = e.response.json() if e.response.content else {}
                raise Exception(f"Alpaca order failed: {error_detail.get('message', str(e))}")
            except Exception as e:
                raise Exception(f"Error placing order: {str(e)}")

    async def modify_order(self, broker_order_id: str, updates: OrderUpdate) -> OrderResponse:
        alpaca_updates = {}

        if updates.quantity:
            alpaca_updates["qty"] = str(updates.quantity)
        if updates.limit_price:
            alpaca_updates["limit_price"] = str(updates.limit_price)
        if updates.stop_price:
            alpaca_updates["stop_price"] = str(updates.stop_price)
        if updates.time_in_force:
            alpaca_updates["time_in_force"] = updates.time_in_force.value
        if updates.trailing_percent:
            alpaca_updates["trail"] = str(updates.trailing_percent)

        async with httpx.AsyncClient() as client:
            try:
                response = await client.patch(
                    f"{self.base_url}/v2/orders/{broker_order_id}",
                    headers=self.headers,
                    json=alpaca_updates,
                    timeout=30.0
                )
                response.raise_for_status()
                alpaca_response = response.json()

                return self._map_alpaca_order_to_response(alpaca_response)

            except httpx.HTTPStatusError as e:
                error_detail = e.response.json() if e.response.content else {}
                raise Exception(f"Order modification failed: {error_detail.get('message', str(e))}")

    async def cancel_order(self, broker_order_id: str) -> bool:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.delete(
                    f"{self.base_url}/v2/orders/{broker_order_id}",
                    headers=self.headers,
                    timeout=30.0
                )
                response.raise_for_status()
                return True
            except Exception as e:
                raise Exception(f"Order cancellation failed: {str(e)}")

    async def get_order(self, broker_order_id: str) -> OrderResponse:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/v2/orders/{broker_order_id}",
                    headers=self.headers,
                    timeout=10.0
                )
                response.raise_for_status()
                alpaca_order = response.json()
                return self._map_alpaca_order_to_response(alpaca_order)
            except Exception as e:
                raise Exception(f"Failed to get order: {str(e)}")

    async def get_orders(
        self,
        status: Optional[str] = None,
        limit: int = 100,
        after: Optional[datetime] = None
    ) -> List[OrderResponse]:
        params = {"limit": min(limit, 500)}

        if status:
            status_map = {
                'pending': 'pending_new',
                'accepted': 'accepted',
                'filled': 'filled',
                'cancelled': 'canceled',
                'rejected': 'rejected'
            }
            params["status"] = status_map.get(status, status)

        if after:
            params["after"] = after.isoformat()

        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/v2/orders",
                    headers=self.headers,
                    params=params,
                    timeout=10.0
                )
                response.raise_for_status()
                alpaca_orders = response.json()

                return [self._map_alpaca_order_to_response(order) for order in alpaca_orders]

            except Exception as e:
                raise Exception(f"Failed to get orders: {str(e)}")

    async def get_positions(self) -> List[PositionResponse]:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/v2/positions",
                    headers=self.headers,
                    timeout=10.0
                )
                response.raise_for_status()
                alpaca_positions = response.json()

                return [self._map_alpaca_position_to_response(pos) for pos in alpaca_positions]

            except Exception as e:
                raise Exception(f"Failed to get positions: {str(e)}")

    async def get_position(self, symbol: str) -> Optional[PositionResponse]:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/v2/positions/{symbol.upper()}",
                    headers=self.headers,
                    timeout=10.0
                )
                response.raise_for_status()
                alpaca_position = response.json()

                return self._map_alpaca_position_to_response(alpaca_position)

            except httpx.HTTPStatusError as e:
                if e.response.status_code == 404:
                    return None
                raise Exception(f"Failed to get position: {str(e)}")

    async def close_position(self, symbol: str, quantity: Optional[float] = None) -> OrderResponse:
        params = {}
        if quantity:
            params["qty"] = str(quantity)

        async with httpx.AsyncClient() as client:
            try:
                response = await client.delete(
                    f"{self.base_url}/v2/positions/{symbol.upper()}",
                    headers=self.headers,
                    params=params,
                    timeout=30.0
                )
                response.raise_for_status()
                alpaca_order = response.json()

                return self._map_alpaca_order_to_response(alpaca_order)

            except Exception as e:
                raise Exception(f"Failed to close position: {str(e)}")

    async def get_account(self) -> AccountSnapshot:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/v2/account",
                    headers=self.headers,
                    timeout=10.0
                )
                response.raise_for_status()
                alpaca_account = response.json()

                return self._map_alpaca_account_to_snapshot(alpaca_account)

            except Exception as e:
                raise Exception(f"Failed to get account: {str(e)}")

    async def get_quote(self, symbol: str) -> MarketQuote:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.data_url}/v2/stocks/{symbol.upper()}/quotes/latest",
                    headers=self.headers,
                    timeout=10.0
                )
                response.raise_for_status()
                data = response.json()
                quote = data.get('quote', {})

                return MarketQuote(
                    symbol=symbol.upper(),
                    asset_type="stock",
                    bid_price=quote.get('bp'),
                    ask_price=quote.get('ap'),
                    last_price=(quote.get('bp', 0) + quote.get('ap', 0)) / 2 if quote.get('bp') and quote.get('ap') else None,
                    volume=quote.get('bs'),
                    quote_time=datetime.fromisoformat(quote.get('t', datetime.now().isoformat()).replace('Z', '+00:00'))
                )

            except Exception as e:
                raise Exception(f"Failed to get quote: {str(e)}")

    async def get_quotes(self, symbols: List[str]) -> List[MarketQuote]:
        quotes = []
        for symbol in symbols:
            try:
                quote = await self.get_quote(symbol)
                quotes.append(quote)
            except:
                continue
        return quotes

    async def get_historical_data(
        self,
        symbol: str,
        timeframe: str,
        start: datetime,
        end: Optional[datetime] = None,
        limit: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        if not end:
            end = datetime.now()

        params = {
            "start": start.isoformat(),
            "end": end.isoformat(),
            "timeframe": timeframe,
            "limit": limit or 10000
        }

        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.data_url}/v2/stocks/{symbol.upper()}/bars",
                    headers=self.headers,
                    params=params,
                    timeout=30.0
                )
                response.raise_for_status()
                data = response.json()

                bars = data.get('bars', [])
                return [
                    {
                        "timestamp": bar['t'],
                        "open": bar['o'],
                        "high": bar['h'],
                        "low": bar['l'],
                        "close": bar['c'],
                        "volume": bar['v']
                    }
                    for bar in bars
                ]

            except Exception as e:
                raise Exception(f"Failed to get historical data: {str(e)}")

    async def get_trades(
        self,
        limit: int = 100,
        after: Optional[datetime] = None
    ) -> List[TradeResponse]:
        raise NotImplementedError("Alpaca trades are embedded in order fills")

    async def subscribe_to_quotes(self, symbols: List[str], callback) -> bool:
        raise NotImplementedError("WebSocket streaming requires separate implementation")

    async def unsubscribe_from_quotes(self, symbols: List[str]) -> bool:
        raise NotImplementedError("WebSocket streaming requires separate implementation")

    def _map_alpaca_order_to_response(self, alpaca_order: Dict, original_order: Optional[OrderCreate] = None) -> OrderResponse:
        status_map = {
            'pending_new': OrderStatus.PENDING,
            'accepted': OrderStatus.ACCEPTED,
            'new': OrderStatus.SUBMITTED,
            'partially_filled': OrderStatus.PARTIAL_FILL,
            'filled': OrderStatus.FILLED,
            'canceled': OrderStatus.CANCELLED,
            'rejected': OrderStatus.REJECTED,
            'expired': OrderStatus.EXPIRED,
            'replaced': OrderStatus.REPLACED
        }

        return OrderResponse(
            id=str(uuid.uuid4()),
            user_id="",
            connection_id="",
            broker_order_id=alpaca_order.get('id'),
            client_order_id=alpaca_order.get('client_order_id', str(uuid.uuid4())),
            symbol=alpaca_order['symbol'],
            asset_type=AssetType.STOCK,
            side=OrderSide(alpaca_order['side']),
            order_type=alpaca_order['type'],
            time_in_force=alpaca_order.get('time_in_force', 'gtc'),
            quantity=float(alpaca_order.get('qty', 0)),
            filled_quantity=float(alpaca_order.get('filled_qty', 0)),
            remaining_quantity=float(alpaca_order.get('qty', 0)) - float(alpaca_order.get('filled_qty', 0)),
            limit_price=float(alpaca_order['limit_price']) if alpaca_order.get('limit_price') else None,
            stop_price=float(alpaca_order['stop_price']) if alpaca_order.get('stop_price') else None,
            average_fill_price=float(alpaca_order['filled_avg_price']) if alpaca_order.get('filled_avg_price') else None,
            status=status_map.get(alpaca_order.get('status'), OrderStatus.PENDING),
            submitted_at=datetime.fromisoformat(alpaca_order['submitted_at'].replace('Z', '+00:00')) if alpaca_order.get('submitted_at') else None,
            filled_at=datetime.fromisoformat(alpaca_order['filled_at'].replace('Z', '+00:00')) if alpaca_order.get('filled_at') else None,
            cancelled_at=datetime.fromisoformat(alpaca_order['cancelled_at'].replace('Z', '+00:00')) if alpaca_order.get('cancelled_at') else None,
            expires_at=datetime.fromisoformat(alpaca_order['expired_at'].replace('Z', '+00:00')) if alpaca_order.get('expired_at') else None,
            metadata=alpaca_order,
            created_at=datetime.now(),
            updated_at=datetime.now()
        )

    def _map_alpaca_position_to_response(self, alpaca_position: Dict) -> PositionResponse:
        quantity = float(alpaca_position.get('qty', 0))
        avg_price = float(alpaca_position.get('avg_entry_price', 0))
        current_price = float(alpaca_position.get('current_price', 0))
        unrealized_pnl = float(alpaca_position.get('unrealized_pl', 0))

        return PositionResponse(
            id=str(uuid.uuid4()),
            user_id="",
            connection_id="",
            symbol=alpaca_position['symbol'],
            asset_type="stock",
            quantity=quantity,
            available_quantity=quantity,
            average_entry_price=avg_price,
            current_price=current_price,
            last_price_update_at=datetime.now(),
            unrealized_pnl=unrealized_pnl,
            unrealized_pnl_percent=float(alpaca_position.get('unrealized_plpc', 0)) * 100,
            realized_pnl=0.0,
            total_pnl=unrealized_pnl,
            total_cost=quantity * avg_price,
            market_value=float(alpaca_position.get('market_value', 0)),
            created_at=datetime.now(),
            updated_at=datetime.now()
        )

    def _map_alpaca_account_to_snapshot(self, alpaca_account: Dict) -> AccountSnapshot:
        return AccountSnapshot(
            id=str(uuid.uuid4()),
            user_id="",
            connection_id="",
            cash_balance=float(alpaca_account.get('cash', 0)),
            equity=float(alpaca_account.get('equity', 0)),
            portfolio_value=float(alpaca_account.get('portfolio_value', 0)),
            buying_power=float(alpaca_account.get('buying_power', 0)),
            margin_used=0.0,
            margin_available=float(alpaca_account.get('buying_power', 0)),
            unrealized_pnl=float(alpaca_account.get('unrealized_pl', 0)),
            realized_pnl_today=float(alpaca_account.get('realized_pl', 0)),
            realized_pnl_total=0.0,
            total_positions_count=0,
            total_open_orders_count=0,
            long_exposure=float(alpaca_account.get('long_market_value', 0)),
            short_exposure=abs(float(alpaca_account.get('short_market_value', 0))),
            net_exposure=float(alpaca_account.get('long_market_value', 0)) - abs(float(alpaca_account.get('short_market_value', 0))),
            snapshot_at=datetime.now(),
            created_at=datetime.now()
        )
