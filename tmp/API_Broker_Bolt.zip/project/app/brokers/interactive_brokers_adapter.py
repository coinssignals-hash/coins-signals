import httpx
from typing import Dict, Any, List, Optional
from datetime import datetime
import uuid
from app.brokers.base_adapter import BrokerAdapter
from app.schemas.broker_schemas import (
    OrderCreate, OrderResponse, OrderUpdate,
    PositionResponse, AccountSnapshot, MarketQuote, TradeResponse,
    OrderStatus, OrderSide, AssetType
)


class InteractiveBrokersAdapter(BrokerAdapter):
    SUPPORTED_ASSETS = ['stock', 'option', 'future', 'forex', 'bond', 'fund']
    SUPPORTED_ORDER_TYPES = ['market', 'limit', 'stop', 'stop_limit', 'trailing_stop']

    def __init__(self, credentials: Dict[str, Any], environment: str = "demo"):
        super().__init__(credentials, environment)
        self.base_url = credentials.get('base_url', 'https://localhost:5000/v1/api')
        self.account_id = credentials.get('account_id')

        if not self.account_id:
            raise ValueError("account_id is required for Interactive Brokers")

        self.session = None

    def get_base_url(self) -> str:
        return self.base_url

    def get_websocket_url(self) -> str:
        return self.base_url.replace('https://', 'wss://').replace('http://', 'ws://')

    def supports_asset_type(self, asset_type: str) -> bool:
        return asset_type in self.SUPPORTED_ASSETS

    def supports_order_type(self, order_type: str) -> bool:
        return order_type in self.SUPPORTED_ORDER_TYPES

    async def connect(self) -> bool:
        try:
            result = await self.test_connection()
            self.is_connected = result.get('success', False)
            return self.is_connected
        except Exception as e:
            self.is_connected = False
            raise Exception(f"Failed to connect to Interactive Brokers: {str(e)}")

    async def disconnect(self) -> bool:
        if self.session:
            async with httpx.AsyncClient(verify=False) as client:
                try:
                    await client.post(f"{self.base_url}/logout", timeout=10.0)
                except:
                    pass

        self.is_connected = False
        self.session = None
        return True

    async def test_connection(self) -> Dict[str, Any]:
        async with httpx.AsyncClient(verify=False) as client:
            try:
                response = await client.get(
                    f"{self.base_url}/iserver/auth/status",
                    timeout=10.0
                )
                response.raise_for_status()
                data = response.json()

                authenticated = data.get('authenticated', False)
                connected = data.get('connected', False)

                if authenticated and connected:
                    return {
                        "success": True,
                        "message": "Connection successful",
                        "account_id": self.account_id
                    }
                else:
                    return {
                        "success": False,
                        "message": "Not authenticated or not connected to IB Gateway",
                        "details": data
                    }

            except httpx.HTTPStatusError as e:
                return {
                    "success": False,
                    "message": f"HTTP error: {e.response.status_code}",
                    "details": e.response.text
                }
            except Exception as e:
                return {
                    "success": False,
                    "message": str(e)
                }

    async def place_order(self, order: OrderCreate) -> OrderResponse:
        self._validate_order(order)

        ib_order = {
            "acctId": self.account_id,
            "conid": await self._get_contract_id(order.symbol),
            "orderType": self._map_order_type_to_ib(order.order_type),
            "side": "BUY" if order.side == OrderSide.BUY else "SELL",
            "quantity": order.quantity,
            "tif": self._map_time_in_force_to_ib(order.time_in_force),
        }

        if order.limit_price:
            ib_order["price"] = order.limit_price

        if order.stop_price:
            ib_order["auxPrice"] = order.stop_price

        if order.trailing_percent:
            ib_order["trailingPercent"] = order.trailing_percent
        elif order.trailing_amount:
            ib_order["trailingAmt"] = order.trailing_amount

        orders_payload = {"orders": [ib_order]}

        async with httpx.AsyncClient(verify=False) as client:
            try:
                response = await client.post(
                    f"{self.base_url}/iserver/account/{self.account_id}/orders",
                    json=orders_payload,
                    timeout=30.0
                )
                response.raise_for_status()
                ib_response = response.json()

                if isinstance(ib_response, list) and len(ib_response) > 0:
                    order_info = ib_response[0]

                    if order_info.get('id'):
                        return await self.get_order(order_info['id'])

                raise Exception(f"Unexpected IB response: {ib_response}")

            except httpx.HTTPStatusError as e:
                error_detail = e.response.json() if e.response.content else {}
                raise Exception(f"IB order failed: {error_detail.get('error', str(e))}")
            except Exception as e:
                raise Exception(f"Error placing order: {str(e)}")

    async def modify_order(self, broker_order_id: str, updates: OrderUpdate) -> OrderResponse:
        ib_updates = {"orderId": broker_order_id}

        if updates.quantity:
            ib_updates["quantity"] = updates.quantity
        if updates.limit_price:
            ib_updates["price"] = updates.limit_price
        if updates.stop_price:
            ib_updates["auxPrice"] = updates.stop_price

        async with httpx.AsyncClient(verify=False) as client:
            try:
                response = await client.post(
                    f"{self.base_url}/iserver/account/{self.account_id}/order/{broker_order_id}",
                    json=ib_updates,
                    timeout=30.0
                )
                response.raise_for_status()
                return await self.get_order(broker_order_id)

            except httpx.HTTPStatusError as e:
                error_detail = e.response.json() if e.response.content else {}
                raise Exception(f"Order modification failed: {error_detail.get('error', str(e))}")

    async def cancel_order(self, broker_order_id: str) -> bool:
        async with httpx.AsyncClient(verify=False) as client:
            try:
                response = await client.delete(
                    f"{self.base_url}/iserver/account/{self.account_id}/order/{broker_order_id}",
                    timeout=30.0
                )
                response.raise_for_status()
                return True
            except Exception as e:
                raise Exception(f"Order cancellation failed: {str(e)}")

    async def get_order(self, broker_order_id: str) -> OrderResponse:
        async with httpx.AsyncClient(verify=False) as client:
            try:
                response = await client.get(
                    f"{self.base_url}/iserver/account/order/status/{broker_order_id}",
                    timeout=10.0
                )
                response.raise_for_status()
                ib_order = response.json()
                return self._map_ib_order_to_response(ib_order)
            except Exception as e:
                raise Exception(f"Failed to get order: {str(e)}")

    async def get_orders(
        self,
        status: Optional[str] = None,
        limit: int = 100,
        after: Optional[datetime] = None
    ) -> List[OrderResponse]:
        async with httpx.AsyncClient(verify=False) as client:
            try:
                response = await client.get(
                    f"{self.base_url}/iserver/account/orders",
                    timeout=10.0
                )
                response.raise_for_status()
                ib_orders = response.json().get('orders', [])

                orders = [self._map_ib_order_to_response(order) for order in ib_orders]

                if status:
                    orders = [o for o in orders if o.status.value == status]

                return orders[:limit]

            except Exception as e:
                raise Exception(f"Failed to get orders: {str(e)}")

    async def get_positions(self) -> List[PositionResponse]:
        async with httpx.AsyncClient(verify=False) as client:
            try:
                response = await client.get(
                    f"{self.base_url}/portfolio/{self.account_id}/positions/0",
                    timeout=10.0
                )
                response.raise_for_status()
                ib_positions = response.json()

                return [self._map_ib_position_to_response(pos) for pos in ib_positions]

            except Exception as e:
                raise Exception(f"Failed to get positions: {str(e)}")

    async def get_position(self, symbol: str) -> Optional[PositionResponse]:
        positions = await self.get_positions()

        for position in positions:
            if position.symbol == symbol:
                return position

        return None

    async def close_position(self, symbol: str, quantity: Optional[float] = None) -> OrderResponse:
        position = await self.get_position(symbol)

        if not position:
            raise Exception(f"No position found for {symbol}")

        close_side = OrderSide.SELL if position.quantity > 0 else OrderSide.BUY
        close_qty = quantity if quantity else abs(position.quantity)

        close_order = OrderCreate(
            connection_id="",
            symbol=symbol,
            asset_type=AssetType(position.asset_type),
            side=close_side,
            order_type="market",
            quantity=close_qty,
            time_in_force="day"
        )

        return await self.place_order(close_order)

    async def get_account(self) -> AccountSnapshot:
        async with httpx.AsyncClient(verify=False) as client:
            try:
                response = await client.get(
                    f"{self.base_url}/portfolio/{self.account_id}/summary",
                    timeout=10.0
                )
                response.raise_for_status()
                ib_account = response.json()

                return self._map_ib_account_to_snapshot(ib_account)

            except Exception as e:
                raise Exception(f"Failed to get account: {str(e)}")

    async def get_quote(self, symbol: str) -> MarketQuote:
        conid = await self._get_contract_id(symbol)

        async with httpx.AsyncClient(verify=False) as client:
            try:
                response = await client.get(
                    f"{self.base_url}/iserver/marketdata/snapshot",
                    params={"conids": conid, "fields": "31,84,85,86"},
                    timeout=10.0
                )
                response.raise_for_status()
                data = response.json()

                if not data:
                    raise Exception(f"No quote data for {symbol}")

                quote = data[0] if isinstance(data, list) else data

                return MarketQuote(
                    symbol=symbol,
                    asset_type="stock",
                    bid_price=quote.get('84'),
                    ask_price=quote.get('85'),
                    last_price=quote.get('31'),
                    volume=quote.get('87'),
                    quote_time=datetime.now()
                )

            except Exception as e:
                raise Exception(f"Failed to get quote: {str(e)}")

    async def get_quotes(self, symbols: List[str]) -> List[MarketQuote]:
        quotes = []
        for symbol in symbols:
            try:
                quote = await self.get_quote(symbol)
                quotes.append(quote)
            except:
                continue
        return quotes

    async def get_historical_data(
        self,
        symbol: str,
        timeframe: str,
        start: datetime,
        end: Optional[datetime] = None,
        limit: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        conid = await self._get_contract_id(symbol)

        period = self._map_timeframe_to_ib(timeframe)
        bar = self._map_timeframe_to_ib_bar(timeframe)

        async with httpx.AsyncClient(verify=False) as client:
            try:
                response = await client.get(
                    f"{self.base_url}/iserver/marketdata/history",
                    params={
                        "conid": conid,
                        "period": period,
                        "bar": bar
                    },
                    timeout=30.0
                )
                response.raise_for_status()
                data = response.json()

                bars = data.get('data', [])
                return [
                    {
                        "timestamp": bar['t'],
                        "open": bar['o'],
                        "high": bar['h'],
                        "low": bar['l'],
                        "close": bar['c'],
                        "volume": bar.get('v', 0)
                    }
                    for bar in bars
                ]

            except Exception as e:
                raise Exception(f"Failed to get historical data: {str(e)}")

    async def get_trades(
        self,
        limit: int = 100,
        after: Optional[datetime] = None
    ) -> List[TradeResponse]:
        raise NotImplementedError("IB trades endpoint not yet implemented")

    async def subscribe_to_quotes(self, symbols: List[str], callback) -> bool:
        raise NotImplementedError("WebSocket streaming requires separate implementation")

    async def unsubscribe_from_quotes(self, symbols: List[str]) -> bool:
        raise NotImplementedError("WebSocket streaming requires separate implementation")

    async def _get_contract_id(self, symbol: str) -> int:
        async with httpx.AsyncClient(verify=False) as client:
            try:
                response = await client.get(
                    f"{self.base_url}/iserver/secdef/search",
                    params={"symbol": symbol},
                    timeout=10.0
                )
                response.raise_for_status()
                results = response.json()

                if results and len(results) > 0:
                    return results[0].get('conid')

                raise Exception(f"No contract found for symbol {symbol}")

            except Exception as e:
                raise Exception(f"Failed to get contract ID: {str(e)}")

    def _map_order_type_to_ib(self, order_type: str) -> str:
        mapping = {
            'market': 'MKT',
            'limit': 'LMT',
            'stop': 'STP',
            'stop_limit': 'STP LMT',
            'trailing_stop': 'TRAIL'
        }
        return mapping.get(order_type, 'MKT')

    def _map_time_in_force_to_ib(self, tif: str) -> str:
        mapping = {
            'day': 'DAY',
            'gtc': 'GTC',
            'ioc': 'IOC',
            'fok': 'FOK'
        }
        return mapping.get(tif, 'DAY')

    def _map_timeframe_to_ib(self, timeframe: str) -> str:
        mapping = {
            '1Min': '1min',
            '5Min': '5min',
            '1Hour': '1h',
            '1Day': '1d',
            '1Week': '1w',
            '1Month': '1M'
        }
        return mapping.get(timeframe, '1d')

    def _map_timeframe_to_ib_bar(self, timeframe: str) -> str:
        mapping = {
            '1Min': '1min',
            '5Min': '5min',
            '1Hour': '1h',
            '1Day': '1d',
            '1Week': '1w',
            '1Month': '1M'
        }
        return mapping.get(timeframe, '1d')

    def _map_ib_order_to_response(self, ib_order: Dict) -> OrderResponse:
        status_map = {
            'PendingSubmit': OrderStatus.PENDING,
            'PreSubmitted': OrderStatus.SUBMITTED,
            'Submitted': OrderStatus.ACCEPTED,
            'Filled': OrderStatus.FILLED,
            'Cancelled': OrderStatus.CANCELLED,
            'Inactive': OrderStatus.REJECTED
        }

        side_map = {'BUY': OrderSide.BUY, 'SELL': OrderSide.SELL}

        return OrderResponse(
            id=str(uuid.uuid4()),
            user_id="",
            connection_id="",
            broker_order_id=str(ib_order.get('orderId')),
            client_order_id=str(uuid.uuid4()),
            symbol=ib_order.get('ticker', ''),
            asset_type=AssetType.STOCK,
            side=side_map.get(ib_order.get('side', 'BUY'), OrderSide.BUY),
            order_type=ib_order.get('orderType', 'MKT').lower(),
            time_in_force=ib_order.get('timeInForce', 'DAY').lower(),
            quantity=float(ib_order.get('totalSize', 0)),
            filled_quantity=float(ib_order.get('filledQuantity', 0)),
            remaining_quantity=float(ib_order.get('remainingQuantity', 0)),
            limit_price=float(ib_order['price']) if ib_order.get('price') else None,
            average_fill_price=float(ib_order['avgPrice']) if ib_order.get('avgPrice') else None,
            status=status_map.get(ib_order.get('status'), OrderStatus.PENDING),
            metadata=ib_order,
            created_at=datetime.now(),
            updated_at=datetime.now()
        )

    def _map_ib_position_to_response(self, ib_position: Dict) -> PositionResponse:
        quantity = float(ib_position.get('position', 0))
        avg_price = float(ib_position.get('avgPrice', 0))
        current_price = float(ib_position.get('mktPrice', 0))
        unrealized_pnl = float(ib_position.get('unrealizedPnl', 0))

        return PositionResponse(
            id=str(uuid.uuid4()),
            user_id="",
            connection_id="",
            symbol=ib_position.get('contractDesc', ''),
            asset_type=ib_position.get('assetClass', 'STK').lower(),
            quantity=quantity,
            available_quantity=quantity,
            average_entry_price=avg_price,
            current_price=current_price,
            unrealized_pnl=unrealized_pnl,
            unrealized_pnl_percent=(unrealized_pnl / (abs(quantity) * avg_price) * 100) if avg_price and quantity else 0,
            realized_pnl=float(ib_position.get('realizedPnl', 0)),
            total_pnl=unrealized_pnl + float(ib_position.get('realizedPnl', 0)),
            total_cost=abs(quantity) * avg_price,
            market_value=float(ib_position.get('mktValue', 0)),
            created_at=datetime.now(),
            updated_at=datetime.now()
        )

    def _map_ib_account_to_snapshot(self, ib_account: Dict) -> AccountSnapshot:
        cash_balance = 0
        equity = 0
        buying_power = 0

        for item in ib_account:
            if item.get('key') == 'TotalCashValue':
                cash_balance = float(item.get('value', 0))
            elif item.get('key') == 'NetLiquidation':
                equity = float(item.get('value', 0))
            elif item.get('key') == 'BuyingPower':
                buying_power = float(item.get('value', 0))

        return AccountSnapshot(
            id=str(uuid.uuid4()),
            user_id="",
            connection_id="",
            cash_balance=cash_balance,
            equity=equity,
            portfolio_value=equity,
            buying_power=buying_power,
            margin_used=0.0,
            margin_available=buying_power,
            unrealized_pnl=0.0,
            realized_pnl_today=0.0,
            realized_pnl_total=0.0,
            total_positions_count=0,
            total_open_orders_count=0,
            long_exposure=0.0,
            short_exposure=0.0,
            net_exposure=0.0,
            snapshot_at=datetime.now(),
            created_at=datetime.now()
        )
