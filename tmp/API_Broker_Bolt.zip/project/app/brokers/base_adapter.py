from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from datetime import datetime
from app.schemas.broker_schemas import (
    OrderCreate, OrderResponse, OrderUpdate,
    PositionResponse, AccountSnapshot, MarketQuote, TradeResponse
)


class BrokerAdapter(ABC):
    def __init__(self, credentials: Dict[str, Any], environment: str = "demo"):
        self.credentials = credentials
        self.environment = environment
        self.is_connected = False

    @abstractmethod
    async def connect(self) -> bool:
        pass

    @abstractmethod
    async def disconnect(self) -> bool:
        pass

    @abstractmethod
    async def test_connection(self) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def place_order(self, order: OrderCreate) -> OrderResponse:
        pass

    @abstractmethod
    async def modify_order(self, broker_order_id: str, updates: OrderUpdate) -> OrderResponse:
        pass

    @abstractmethod
    async def cancel_order(self, broker_order_id: str) -> bool:
        pass

    @abstractmethod
    async def get_order(self, broker_order_id: str) -> OrderResponse:
        pass

    @abstractmethod
    async def get_orders(
        self,
        status: Optional[str] = None,
        limit: int = 100,
        after: Optional[datetime] = None
    ) -> List[OrderResponse]:
        pass

    @abstractmethod
    async def get_positions(self) -> List[PositionResponse]:
        pass

    @abstractmethod
    async def get_position(self, symbol: str) -> Optional[PositionResponse]:
        pass

    @abstractmethod
    async def close_position(self, symbol: str, quantity: Optional[float] = None) -> OrderResponse:
        pass

    @abstractmethod
    async def get_account(self) -> AccountSnapshot:
        pass

    @abstractmethod
    async def get_quote(self, symbol: str) -> MarketQuote:
        pass

    @abstractmethod
    async def get_quotes(self, symbols: List[str]) -> List[MarketQuote]:
        pass

    @abstractmethod
    async def get_historical_data(
        self,
        symbol: str,
        timeframe: str,
        start: datetime,
        end: Optional[datetime] = None,
        limit: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        pass

    @abstractmethod
    async def get_trades(
        self,
        limit: int = 100,
        after: Optional[datetime] = None
    ) -> List[TradeResponse]:
        pass

    @abstractmethod
    def supports_asset_type(self, asset_type: str) -> bool:
        pass

    @abstractmethod
    def supports_order_type(self, order_type: str) -> bool:
        pass

    @abstractmethod
    async def subscribe_to_quotes(self, symbols: List[str], callback) -> bool:
        pass

    @abstractmethod
    async def unsubscribe_from_quotes(self, symbols: List[str]) -> bool:
        pass

    def _validate_order(self, order: OrderCreate) -> None:
        if not self.supports_asset_type(order.asset_type):
            raise ValueError(f"Asset type {order.asset_type} not supported by this broker")

        if not self.supports_order_type(order.order_type):
            raise ValueError(f"Order type {order.order_type} not supported by this broker")

    def get_base_url(self) -> str:
        raise NotImplementedError("Subclasses must implement get_base_url")

    def get_websocket_url(self) -> str:
        raise NotImplementedError("Subclasses must implement get_websocket_url")
