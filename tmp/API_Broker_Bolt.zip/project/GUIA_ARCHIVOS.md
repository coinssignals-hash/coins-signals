# Guía Completa de Archivos del Proyecto

Esta guía explica QUÉ ES y PARA QUÉ SIRVE cada archivo del proyecto.

## 📂 Estructura Visual

```
trading-news-api/
│
├── 📁 app/                          # Código principal de la aplicación
│   ├── 📄 __init__.py              # Marca carpeta como paquete Python
│   ├── 📄 main.py                  # ⭐ Aplicación FastAPI principal
│   │
│   ├── 📁 api/                     # Endpoints de la API
│   │   ├── 📄 __init__.py
│   │   ├── 📄 news_endpoints.py   # Endpoints para app móvil
│   │   └── 📄 admin_endpoints.py  # Endpoints administrativos
│   │
│   ├── 📁 core/                    # Configuración central
│   │   ├── 📄 __init__.py
│   │   └── 📄 config.py           # Variables y settings
│   │
│   ├── 📁 db/                      # Base de datos
│   │   ├── 📄 __init__.py
│   │   └── 📄 supabase_client.py  # Cliente de Supabase
│   │
│   ├── 📁 schemas/                 # Modelos de datos
│   │   ├── 📄 __init__.py
│   │   └── 📄 news_schemas.py     # Estructuras JSON
│   │
│   └── 📁 services/                # Lógica de negocio
│       ├── 📄 __init__.py
│       ├── 📄 scraper_service.py  # Web scraping
│       ├── 📄 ai_analysis_service.py  # Análisis con IA
│       ├── 📄 historical_service.py   # Datos históricos
│       └── 📄 utils.py            # Funciones auxiliares
│
├── 📁 scripts/                     # Scripts auxiliares
│   ├── 📄 __init__.py
│   └── 📄 init_sources.py         # Inicializar fuentes
│
├── 📄 .env.example                # ⭐ Plantilla variables entorno
├── 📄 .env                        # ⚠️ TUS credenciales (NO compartir)
├── 📄 .gitignore                  # Archivos ignorados por Git
├── 📄 Dockerfile                  # Configuración Docker
├── 📄 docker-compose.yml          # Docker Compose
├── 📄 requirements.txt            # ⭐ Dependencias Python
├── 📄 run.py                      # ⭐ Script para ejecutar servidor
├── 📄 supabase_migration.sql     # ⭐ Script SQL crear tablas
│
└── 📁 Documentación/
    ├── 📄 README.md               # ⭐ Documentación completa
    ├── 📄 QUICKSTART.md           # ⭐ Inicio rápido
    ├── 📄 EXAMPLES.md             # Ejemplos JSON
    ├── 📄 INSTRUCCIONES_DESCARGA.md  # Esta guía de descarga
    └── 📄 GUIA_ARCHIVOS.md        # Este archivo
```

---

## 🔥 Archivos CRÍTICOS (Debes entender)

### 1. `.env` - Variables de Entorno
**Tipo:** Archivo de configuración
**Formato:** Texto plano con formato `CLAVE=valor`

**Qué contiene:**
```env
SUPABASE_URL=https://tu-proyecto.supabase.co
SUPABASE_KEY=tu-key
OPENAI_API_KEY=sk-proj-tu-key
```

**Para qué sirve:**
- Guarda tus credenciales de forma segura
- NO se sube a Git (protegido por .gitignore)
- El código lee estas variables automáticamente

**Cómo crearlo:**
1. Copiar `.env.example` y renombrar a `.env`
2. Reemplazar los valores de ejemplo con tus credenciales reales
3. Guardar en la carpeta raíz del proyecto

---

### 2. `requirements.txt` - Dependencias
**Tipo:** Lista de librerías Python
**Formato:** Texto plano con nombre y versión

**Qué contiene:**
```txt
fastapi==0.109.0
uvicorn==0.27.0
supabase==2.3.4
openai==1.10.0
```

**Para qué sirve:**
- Lista todas las librerías que el proyecto necesita
- pip las instala automáticamente con `pip install -r requirements.txt`

**No necesitas editarlo** - Solo instalarlo:
```bash
pip install -r requirements.txt
```

---

### 3. `run.py` - Ejecutar Servidor
**Tipo:** Script Python
**Formato:** Código Python

**Qué hace:**
```python
# Lee la configuración de .env
# Inicia el servidor FastAPI
# Puerto 8000 por defecto
```

**Para qué sirve:**
- Forma fácil de ejecutar el servidor
- Simplifica el comando uvicorn

**Cómo usarlo:**
```bash
python run.py
```

---

### 4. `supabase_migration.sql` - Crear Tablas
**Tipo:** Script SQL
**Formato:** Lenguaje SQL

**Qué hace:**
```sql
CREATE TABLE news_sources (...);
CREATE TABLE news_articles (...);
CREATE TABLE news_analysis (...);
-- etc.
```

**Para qué sirve:**
- Crea las 5 tablas necesarias en Supabase
- Configura índices y relaciones
- Habilita seguridad (RLS)

**Cómo usarlo:**
1. Abrir Supabase Dashboard
2. Ir a SQL Editor
3. Copiar y pegar el contenido completo
4. Ejecutar (Run)

---

### 5. `app/main.py` - Aplicación Principal
**Tipo:** Código Python
**Formato:** Archivo Python

**Qué hace:**
```python
# Crea la aplicación FastAPI
# Configura CORS
# Registra los endpoints
# Inicia el scheduler automático
```

**Para qué sirve:**
- Punto de entrada de la aplicación
- Define la API y sus rutas
- Configura el procesamiento automático

**No necesitas editarlo** - Funciona tal cual

---

## 📚 Archivos de DOCUMENTACIÓN

### `README.md` - Documentación Completa
- Guía detallada de todo el proyecto
- Arquitectura, instalación, uso
- **Léelo primero** para entender el proyecto completo

### `QUICKSTART.md` - Inicio Rápido
- Guía paso a paso para principiantes
- De 0 a servidor funcionando en minutos
- **Úsalo para empezar** si eres nuevo

### `EXAMPLES.md` - Ejemplos JSON
- Respuestas reales de la API
- Ejemplos de cada endpoint
- **Úsalo como referencia** al desarrollar tu app

### `INSTRUCCIONES_DESCARGA.md` - Descarga
- Cómo descargar el proyecto
- Verificar estructura
- Este archivo que leíste primero

### `GUIA_ARCHIVOS.md` - Este Archivo
- Explica cada archivo del proyecto
- Tipos y formatos
- **Léelo para entender** la estructura

---

## 🐍 Archivos de CÓDIGO PYTHON

### Carpeta `app/api/` - Endpoints

#### `news_endpoints.py`
**Qué hace:** Define los endpoints para tu app móvil
```python
GET /api/v1/news/list
GET /api/v1/news/{id}
GET /api/v1/news/currencies
GET /api/v1/news/categories
```

#### `admin_endpoints.py`
**Qué hace:** Define endpoints administrativos
```python
POST /api/v1/admin/scrape
POST /api/v1/admin/analyze
GET /api/v1/admin/stats
```

---

### Carpeta `app/services/` - Lógica de Negocio

#### `scraper_service.py`
**Qué hace:**
- Extrae noticias de sitios web
- Filtra noticias relevantes para forex
- Guarda en la base de datos

#### `ai_analysis_service.py`
**Qué hace:**
- Conecta con OpenAI GPT-4
- Genera resúmenes y análisis
- Calcula impacto por divisa

#### `historical_service.py`
**Qué hace:**
- Genera 12 meses de datos históricos
- Crea puntos para gráficos
- Asocia eventos a fechas

#### `utils.py`
**Qué hace:**
- Funciones auxiliares
- Calcular "time ago"
- Categorizar noticias
- Extraer divisas mencionadas

---

### Carpeta `app/schemas/` - Modelos de Datos

#### `news_schemas.py`
**Qué hace:**
- Define la estructura de los JSON
- Validación automática con Pydantic
- Documentación en Swagger

**Ejemplo:**
```python
class NewsListItem:
    id: str
    title: str
    published_at: datetime
    # etc.
```

---

### Carpeta `app/core/` - Configuración

#### `config.py`
**Qué hace:**
- Lee variables del archivo `.env`
- Configura la aplicación
- Define constantes (divisas, categorías)

---

### Carpeta `app/db/` - Base de Datos

#### `supabase_client.py`
**Qué hace:**
- Crea conexión a Supabase
- Proporciona cliente singleton
- Gestiona la conexión

---

### Carpeta `scripts/` - Scripts Auxiliares

#### `init_sources.py`
**Qué hace:**
- Añade 15 fuentes de noticias predefinidas
- Reuters, Bloomberg, FT, etc.
- Se ejecuta una sola vez al inicio

**Cómo usarlo:**
```bash
python scripts/init_sources.py
```

---

## 🐳 Archivos de DOCKER

### `Dockerfile`
**Qué es:** Receta para crear imagen Docker
**Para qué sirve:** Empaquetar la app en contenedor

**Cómo usarlo:**
```bash
docker build -t trading-news-api .
docker run -p 8000:8000 trading-news-api
```

### `docker-compose.yml`
**Qué es:** Orquestación de contenedores
**Para qué sirve:** Desarrollo local con Docker

**Cómo usarlo:**
```bash
docker-compose up
```

---

## ⚙️ Archivos de CONFIGURACIÓN

### `.gitignore`
**Qué hace:**
- Lista archivos que Git debe ignorar
- Protege `.env` para que no se suba
- Ignora `__pycache__`, `venv`, etc.

**No necesitas editarlo**

### `__init__.py`
**Qué es:** Archivos vacíos en cada carpeta
**Para qué sirve:** Marca carpetas como paquetes Python

**Por qué existen:**
- Python requiere estos archivos para importar módulos
- Pueden estar vacíos
- **No los borres**

---

## 📊 Resumen de Tipos de Archivos

| Extensión | Tipo | Propósito | Editar |
|-----------|------|-----------|--------|
| `.py` | Python | Código fuente | ❌ No |
| `.md` | Markdown | Documentación | ✅ Leer |
| `.txt` | Texto | Dependencias | ❌ No |
| `.sql` | SQL | Base de datos | ✅ Usar |
| `.env` | Texto | Credenciales | ✅✅✅ SÍ |
| `.yml` | YAML | Configuración Docker | ❌ No |
| `Dockerfile` | Docker | Imagen Docker | ❌ No |

---

## ✅ Checklist de Archivos Obligatorios

Antes de ejecutar el proyecto, asegúrate de tener:

- [ ] ✅ Carpeta `app/` completa con todos los .py
- [ ] ✅ Carpeta `scripts/` con init_sources.py
- [ ] ✅ Archivo `requirements.txt`
- [ ] ✅ Archivo `run.py`
- [ ] ✅ Archivo `.env` (creado por ti desde .env.example)
- [ ] ✅ Archivo `supabase_migration.sql`
- [ ] ✅ Archivos de documentación .md

**Total:** ~30 archivos

---

## 🚫 Archivos que NO Debes Modificar

A menos que sepas exactamente lo que haces:

- ❌ Todos los archivos `.py` en `app/`
- ❌ `requirements.txt`
- ❌ `Dockerfile` y `docker-compose.yml`
- ❌ `.gitignore`
- ❌ Archivos `__init__.py`

---

## ✏️ Archivos que SÍ Puedes/Debes Modificar

- ✅ `.env` - **DEBES crearlo y editarlo con tus credenciales**
- ✅ Archivos `.md` - Puedes añadir notas personales
- ✅ `scripts/init_sources.py` - Puedes añadir más fuentes

---

## 🔄 Flujo de Ejecución

```
1. Leer .env
   ↓
2. Cargar config.py
   ↓
3. Conectar a Supabase (supabase_client.py)
   ↓
4. Iniciar FastAPI (main.py)
   ↓
5. Registrar endpoints (news_endpoints.py, admin_endpoints.py)
   ↓
6. Iniciar scheduler automático
   ↓
7. Ejecutar scraping cada 30 min (scraper_service.py)
   ↓
8. Analizar con IA (ai_analysis_service.py)
   ↓
9. Generar históricos (historical_service.py)
   ↓
10. Servir datos via API
```

---

## 💡 Preguntas Frecuentes

### ¿Puedo borrar los archivos .md?
Sí, pero perderás la documentación. Recomendado: déjalos.

### ¿Qué pasa si borro un __init__.py?
Python no reconocerá la carpeta como paquete. Error de importación.

### ¿Necesito editar el código Python?
No, el proyecto funciona sin modificaciones. Solo edita `.env`.

### ¿Dónde están las credenciales?
En `.env` (que debes crear desde `.env.example`).

### ¿Qué archivo ejecuto para iniciar?
`run.py` con el comando: `python run.py`

### ¿Necesito Docker?
No, es opcional. Puedes ejecutar directamente con Python.

---

## 📖 Orden de Lectura Recomendado

1. **INSTRUCCIONES_DESCARGA.md** (para descargar)
2. **Este archivo (GUIA_ARCHIVOS.md)** (para entender estructura)
3. **QUICKSTART.md** (para instalar y ejecutar)
4. **README.md** (documentación completa)
5. **EXAMPLES.md** (cuando desarrolles tu app)

---

## 🎯 Lo Mínimo que Necesitas Saber

Si solo quieres que funcione rápido:

1. **Crea el archivo `.env`** con tus credenciales
2. **Instala dependencias:** `pip install -r requirements.txt`
3. **Ejecuta SQL:** Copia `supabase_migration.sql` en Supabase
4. **Inicializa fuentes:** `python scripts/init_sources.py`
5. **Ejecuta servidor:** `python run.py`
6. **Abre navegador:** http://localhost:8000/docs

¡Listo! 🚀

---

**Recuerda:** No necesitas entender todo el código Python para usar el proyecto. Solo necesitas:
- Crear `.env` con credenciales
- Ejecutar los comandos indicados
- Consumir la API desde tu app móvil

El código ya está completo y funcional tal como está.
