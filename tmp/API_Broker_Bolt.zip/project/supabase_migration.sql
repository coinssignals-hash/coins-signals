/*
  # Trading News API - Database Schema

  Este script crea todas las tablas necesarias para la Trading News API.

  ## Tablas creadas:
  1. news_sources - Fuentes de noticias
  2. news_articles - Artículos de noticias
  3. news_analysis - Análisis con IA
  4. currency_impact - Impacto por divisa
  5. historical_analysis - Datos históricos para gráficos

  ## Seguridad:
  - RLS habilitado en todas las tablas
  - Políticas restrictivas por defecto
  - Solo lectura pública para datos analizados
*/

-- Extensiones necesarias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ========================================
-- Tabla: news_sources
-- ========================================

CREATE TABLE IF NOT EXISTS news_sources (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name text NOT NULL,
  url text UNIQUE NOT NULL,
  is_active boolean DEFAULT true,
  scrape_frequency_minutes int DEFAULT 30,
  last_scraped_at timestamptz,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_news_sources_active ON news_sources(is_active);
CREATE INDEX IF NOT EXISTS idx_news_sources_url ON news_sources(url);

ALTER TABLE news_sources ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow public read access to active sources" ON news_sources;
CREATE POLICY "Allow public read access to active sources"
  ON news_sources FOR SELECT
  TO public
  USING (is_active = true);

-- ========================================
-- Tabla: news_articles
-- ========================================

CREATE TABLE IF NOT EXISTS news_articles (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  source_id uuid REFERENCES news_sources(id) ON DELETE CASCADE,
  analysis_id uuid,
  title text NOT NULL,
  content text NOT NULL,
  url text NOT NULL,
  image_url text,
  published_at timestamptz DEFAULT now(),
  is_relevant boolean DEFAULT false,
  economic_category text,
  affected_currencies text[] DEFAULT ARRAY[]::text[],
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_news_articles_source ON news_articles(source_id);
CREATE INDEX IF NOT EXISTS idx_news_articles_published ON news_articles(published_at DESC);
CREATE INDEX IF NOT EXISTS idx_news_articles_relevant ON news_articles(is_relevant);
CREATE INDEX IF NOT EXISTS idx_news_articles_analysis ON news_articles(analysis_id);
CREATE INDEX IF NOT EXISTS idx_news_articles_category ON news_articles(economic_category);
CREATE INDEX IF NOT EXISTS idx_news_articles_currencies ON news_articles USING GIN(affected_currencies);
CREATE INDEX IF NOT EXISTS idx_news_articles_title ON news_articles(title);

ALTER TABLE news_articles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow public read access to relevant articles" ON news_articles;
CREATE POLICY "Allow public read access to relevant articles"
  ON news_articles FOR SELECT
  TO public
  USING (is_relevant = true);

-- ========================================
-- Tabla: news_analysis
-- ========================================

CREATE TABLE IF NOT EXISTS news_analysis (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  article_id uuid REFERENCES news_articles(id) ON DELETE CASCADE,
  ai_summary text NOT NULL,
  key_points text[] DEFAULT ARRAY[]::text[],
  trader_conclusion text NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_news_analysis_article ON news_analysis(article_id);

ALTER TABLE news_analysis ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow public read access to analysis" ON news_analysis;
CREATE POLICY "Allow public read access to analysis"
  ON news_analysis FOR SELECT
  TO public
  USING (true);

-- ========================================
-- Agregar FK de news_articles a news_analysis
-- ========================================

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'news_articles_analysis_id_fkey'
  ) THEN
    ALTER TABLE news_articles
    ADD CONSTRAINT news_articles_analysis_id_fkey
    FOREIGN KEY (analysis_id) REFERENCES news_analysis(id) ON DELETE SET NULL;
  END IF;
END $$;

-- ========================================
-- Tabla: currency_impact
-- ========================================

CREATE TABLE IF NOT EXISTS currency_impact (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  article_id uuid REFERENCES news_articles(id) ON DELETE CASCADE,
  currency_code text NOT NULL,
  positive_percent float DEFAULT 0,
  negative_percent float DEFAULT 0,
  neutral_percent float DEFAULT 0,
  overall_sentiment text NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_currency_impact_article ON currency_impact(article_id);
CREATE INDEX IF NOT EXISTS idx_currency_impact_currency ON currency_impact(currency_code);
CREATE INDEX IF NOT EXISTS idx_currency_impact_sentiment ON currency_impact(overall_sentiment);

ALTER TABLE currency_impact ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow public read access to currency impact" ON currency_impact;
CREATE POLICY "Allow public read access to currency impact"
  ON currency_impact FOR SELECT
  TO public
  USING (true);

-- ========================================
-- Tabla: historical_analysis
-- ========================================

CREATE TABLE IF NOT EXISTS historical_analysis (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  article_id uuid REFERENCES news_articles(id) ON DELETE CASCADE,
  currency_code text NOT NULL,
  date text NOT NULL,
  impact_value float NOT NULL,
  event_description text NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_historical_article ON historical_analysis(article_id);
CREATE INDEX IF NOT EXISTS idx_historical_currency ON historical_analysis(currency_code);
CREATE INDEX IF NOT EXISTS idx_historical_date ON historical_analysis(date);

ALTER TABLE historical_analysis ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow public read access to historical data" ON historical_analysis;
CREATE POLICY "Allow public read access to historical data"
  ON historical_analysis FOR SELECT
  TO public
  USING (true);

-- ========================================
-- Verificación final
-- ========================================

-- Mostrar todas las tablas creadas
SELECT tablename FROM pg_tables WHERE schemaname = 'public' AND tablename LIKE 'news%' OR tablename LIKE '%impact%' OR tablename LIKE 'historical%';

-- Mensaje de éxito
DO $$
BEGIN
  RAISE NOTICE 'Database schema created successfully!';
  RAISE NOTICE 'Tables: news_sources, news_articles, news_analysis, currency_impact, historical_analysis';
  RAISE NOTICE 'All tables have RLS enabled';
  RAISE NOTICE 'Indexes created for optimal query performance';
END $$;
