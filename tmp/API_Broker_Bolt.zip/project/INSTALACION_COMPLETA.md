# 📦 Guía de Instalación Completa - Trading API Multi-Broker

## 🎯 Lo que incluye este proyecto

**7 Brokers Implementados:**
- ✅ Alpaca (Stocks, Crypto)
- ✅ OANDA (Forex, CFDs)
- ✅ Interactive Brokers (Stocks, Forex, Options, Futures)
- ✅ IG Markets (Stocks, Forex, CFDs, Options, Futures)
- ✅ FOREX.com (Forex, CFDs, Crypto)
- ✅ FXCM (Forex, CFDs)
- ✅ Pepperstone (Stocks, Forex, CFDs, Crypto)

---

## 🚀 Instalación Paso a Paso

### 1. Descomprimir el archivo

```bash
unzip trading-api-multi-broker.zip
cd project
```

### 2. Crear entorno virtual (recomendado)

```bash
# Python 3.8+
python -m venv venv

# Activar entorno virtual
# En Linux/Mac:
source venv/bin/activate

# En Windows:
venv\Scripts\activate
```

### 3. Instalar dependencias

```bash
pip install -r requirements.txt
```

### 4. Configurar variables de entorno

```bash
# Copiar archivo de ejemplo
cp .env.example .env

# Editar .env con tus credenciales
nano .env
```

**Variables requeridas en `.env`:**

```env
# Supabase
SUPABASE_URL=tu_supabase_url
SUPABASE_SERVICE_KEY=tu_supabase_service_key

# Seguridad
ENCRYPTION_KEY=generar_con_script

# OpenAI (opcional para análisis AI)
OPENAI_API_KEY=tu_openai_key
```

### 5. Generar clave de cifrado

```bash
python generate_encryption_key.py
```

Este script generará una clave de cifrado AES y la guardará automáticamente en `.env`.

### 6. Crear base de datos en Supabase

**Opción A: Migración automática (recomendado)**

El archivo de migración está en: `supabase/migrations/20260102235421_create_trading_broker_system.sql`

Si usas Supabase CLI:
```bash
supabase db push
```

**Opción B: Ejecución manual**

1. Abre tu proyecto en [Supabase Dashboard](https://app.supabase.com)
2. Ve a SQL Editor
3. Copia y pega el contenido de `supabase_migration.sql`
4. Ejecuta el script

### 7. Inicializar datos de brokers

```bash
python scripts/init_sources.py
```

Este script insertará los 7 brokers en la base de datos.

### 8. Iniciar el servidor

```bash
python run.py
```

La API estará disponible en: **http://localhost:8000**

---

## 📖 Documentación

Una vez iniciado el servidor, accede a:

- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

### Documentación incluida:

1. **BROKER_API_README.md** - Visión general del proyecto
2. **TRADING_QUICKSTART.md** - Guía de inicio rápido
3. **TRADING_API_DOCS.md** - Documentación completa de la API
4. **GUIA_ARCHIVOS.md** - Estructura del proyecto
5. **EXAMPLES.md** - Ejemplos de uso

---

## 🔐 Configurar Credenciales de Brokers

### Paso 1: Crear conexión con broker

```bash
POST /api/brokers/connections
```

**Ejemplo para Alpaca:**
```json
{
  "broker_id": "uuid-del-broker-alpaca",
  "connection_name": "Mi Cuenta Alpaca",
  "environment": "demo",
  "credentials": {
    "api_key": "tu_alpaca_api_key",
    "api_secret": "tu_alpaca_api_secret"
  }
}
```

### Credenciales requeridas por broker:

#### Alpaca
```json
{
  "api_key": "your-api-key",
  "api_secret": "your-api-secret"
}
```

#### OANDA
```json
{
  "api_key": "your-api-token",
  "account_id": "your-account-id"
}
```

#### Interactive Brokers
```json
{
  "base_url": "https://localhost:5000/v1/api",
  "account_id": "your-account-id"
}
```
*Nota: Requiere IB Gateway o TWS corriendo localmente*

#### IG Markets
```json
{
  "api_key": "your-ig-api-key",
  "username": "your-username",
  "password": "your-password",
  "account_id": "your-account-id"
}
```

#### FOREX.com
```json
{
  "api_token": "your-forex-api-token",
  "account_id": "your-account-id"
}
```

#### FXCM
```json
{
  "access_token": "your-fxcm-access-token",
  "account_id": "your-account-id"
}
```

#### Pepperstone
```json
{
  "api_key": "your-pepperstone-api-key",
  "account_id": "your-account-id"
}
```

---

## 🎯 Primeros Pasos

### 1. Listar brokers disponibles

```bash
curl http://localhost:8000/api/brokers/
```

### 2. Crear conexión con un broker

```bash
curl -X POST http://localhost:8000/api/brokers/connections \
  -H "Content-Type: application/json" \
  -d '{
    "broker_id": "uuid-del-broker",
    "connection_name": "Mi Cuenta Demo",
    "environment": "demo",
    "credentials": {
      "api_key": "your-key",
      "api_secret": "your-secret"
    }
  }'
```

### 3. Colocar una orden

```bash
curl -X POST http://localhost:8000/api/trading/orders \
  -H "Content-Type: application/json" \
  -d '{
    "connection_id": "uuid-de-tu-conexion",
    "symbol": "AAPL",
    "asset_type": "stock",
    "side": "buy",
    "order_type": "market",
    "quantity": 10
  }'
```

### 4. Ver tus posiciones

```bash
curl http://localhost:8000/api/trading/positions?connection_id=uuid-de-tu-conexion
```

### 5. Ver tu balance

```bash
curl http://localhost:8000/api/trading/account?connection_id=uuid-de-tu-conexion
```

---

## 🐳 Docker (Opcional)

### Construir imagen

```bash
docker build -t trading-api .
```

### Ejecutar con Docker

```bash
docker run -p 8000:8000 --env-file .env trading-api
```

### Docker Compose

```bash
docker-compose up -d
```

---

## 🔧 Estructura del Proyecto

```
project/
├── app/
│   ├── api/              # Endpoints de la API
│   │   ├── broker_endpoints.py
│   │   ├── trading_endpoints.py
│   │   ├── news_endpoints.py
│   │   └── admin_endpoints.py
│   ├── brokers/          # Adaptadores de brokers
│   │   ├── alpaca_adapter.py
│   │   ├── oanda_adapter.py
│   │   ├── interactive_brokers_adapter.py
│   │   ├── ig_markets_adapter.py
│   │   ├── forex_com_adapter.py
│   │   ├── fxcm_adapter.py
│   │   ├── pepperstone_adapter.py
│   │   ├── base_adapter.py
│   │   ├── broker_factory.py
│   │   └── registry.py
│   ├── core/             # Configuración
│   ├── db/               # Cliente Supabase
│   ├── schemas/          # Modelos Pydantic
│   ├── services/         # Lógica de negocio
│   └── main.py           # App principal FastAPI
├── scripts/              # Scripts de inicialización
├── supabase/            # Migraciones de base de datos
├── requirements.txt      # Dependencias Python
├── run.py               # Script de inicio
├── Dockerfile           # Imagen Docker
├── docker-compose.yml   # Orquestación Docker
└── *.md                 # Documentación
```

---

## 📚 Funcionalidades Principales

### 🔄 Órdenes de Trading
- Market, Limit, Stop, Stop-Limit, Trailing Stop
- Take Profit y Stop Loss automáticos
- Órdenes simultáneas en múltiples brokers
- Modificación y cancelación de órdenes

### 📊 Market Data
- Cotizaciones en tiempo real
- Datos históricos (OHLCV)
- Múltiples timeframes (1m, 5m, 1h, 1d, etc.)

### 💼 Portfolio Management
- Balance y equity en tiempo real
- Posiciones abiertas con P&L
- Historial de trades
- Métricas de exposición

### 🔐 Seguridad
- Cifrado AES-128 de credenciales
- Row Level Security (RLS) en base de datos
- Auditoría completa de operaciones
- Políticas de acceso granulares

### 🤖 Análisis AI (Opcional)
- Análisis de noticias con OpenAI
- Sentiment analysis
- Detección de eventos importantes

---

## 🧪 Testing

### Test de conexión

```python
import requests

# Verificar que la API está corriendo
response = requests.get("http://localhost:8000/health")
print(response.json())

# Listar brokers
brokers = requests.get("http://localhost:8000/api/brokers/")
print(brokers.json())
```

---

## ⚠️ Consideraciones Importantes

1. **Cuentas Demo**: Siempre prueba primero con cuentas demo
2. **Credenciales**: NUNCA subas tu archivo `.env` a Git
3. **Rate Limits**: Respeta los límites de cada broker
4. **Gestión de Riesgo**: Configura stop loss en todas tus órdenes
5. **Actualizaciones**: Mantén tus dependencias actualizadas

---

## 🆘 Resolución de Problemas

### Error: "Module not found"
```bash
pip install -r requirements.txt
```

### Error: "Database connection failed"
Verifica que las credenciales de Supabase en `.env` sean correctas.

### Error: "Encryption key missing"
```bash
python generate_encryption_key.py
```

### Error: "Broker not registered"
```bash
python scripts/init_sources.py
```

### Puerto 8000 ocupado
Modifica el puerto en `run.py`:
```python
uvicorn.run(app, host="0.0.0.0", port=8001)
```

---

## 📞 Soporte

Para preguntas o problemas:
- Consulta la documentación en `/docs`
- Revisa los ejemplos en `EXAMPLES.md`
- Lee la guía completa en `TRADING_API_DOCS.md`

---

## 📄 Licencia

Este proyecto incluye integraciones con brokers regulados. Asegúrate de cumplir con:
- Términos y condiciones de cada broker
- Regulaciones financieras de tu jurisdicción
- Políticas de uso de APIs

---

## ✨ Características Destacadas

- ✅ **7 brokers integrados** (Alpaca, OANDA, IB, IG, FOREX.com, FXCM, Pepperstone)
- ✅ **Multi-asset** (Stocks, Forex, Crypto, Options, Futures, CFDs)
- ✅ **API REST unificada** con FastAPI
- ✅ **Seguridad enterprise** (cifrado, RLS, auditoría)
- ✅ **Documentación interactiva** con Swagger UI
- ✅ **Docker support** para deployment fácil
- ✅ **Base de datos Supabase** con migraciones
- ✅ **Código modular** y extensible

---

**¡Disfruta del trading con múltiples brokers! 🚀📈**
